<?php
/**
 * Configuração do Painel Web Quantum.
 *
 * Preencha com os MESMOS dados de MySQL usados no sync_config.php (da pasta
 * api_php_servidor). É o banco onde o sistema Quantum espelha os dados.
 *
 * Proteja este arquivo (já há um .htaccess bloqueando acesso direto a ele).
 */

// ----- Banco MySQL da hospedagem (mesmos dados do sync_config.php) -----
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_PORT', 3306);
define('DB_NAME', 'if0_XXXXXXXX_banco');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'SUA_SENHA_DO_MYSQL');
define('DB_CHARSET', 'utf8mb4');

// ----- Aparência / sessão -----
define('APP_NOME', 'Quantum • Painel Web');
define('SESSION_NOME', 'QUANTUMPAINEL');

// Tempo de inatividade até deslogar (segundos). 0 = sem expiração por inatividade.
define('SESSION_TIMEOUT', 3600);
