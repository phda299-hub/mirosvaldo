<?php
require_once __DIR__ . '/auth.php';
q_logout();
header('Location: login.php');
exit;
