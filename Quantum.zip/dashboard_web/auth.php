<?php
require_once __DIR__ . '/db.php';

/** Inicia a sessão com parâmetros seguros. */
function q_session_start() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
    session_name(SESSION_NOME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $https,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/** Token CSRF (gera e guarda na sessão). */
function q_csrf_token() {
    q_session_start();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function q_csrf_check($token) {
    q_session_start();
    return !empty($_SESSION['csrf']) && is_string($token) && hash_equals($_SESSION['csrf'], $token);
}

/**
 * Autentica um login/senha contra a tabela `usuarios` (mesma do Quantum).
 * Retorna o array do usuário em caso de sucesso, ou null.
 */
function q_autenticar($login, $senha) {
    $login = trim((string)$login);
    if ($login === '') {
        return null;
    }
    $pdo = q_pdo();
    $cols = q_table_columns($pdo, 'usuarios');

    // Monta SELECT compatível com o esquema (username e/ou usuario).
    $where = [];
    $params = [];
    $lower = mb_strtolower($login, 'UTF-8');
    if (isset($cols['username'])) {
        $where[] = 'LOWER(username) = ?';
        $params[] = $lower;
    }
    if (isset($cols['usuario'])) {
        $where[] = 'LOWER(usuario) = ?';
        $params[] = $lower;
    }
    if (!$where) {
        return null;
    }
    $sqlAtivo = isset($cols['ativo']) ? ' AND (ativo = 1 OR ativo IS NULL)' : '';
    $sql = 'SELECT * FROM usuarios WHERE (' . implode(' OR ', $where) . ')' . $sqlAtivo . ' LIMIT 1';
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    if (!$row) {
        return null;
    }

    $hash = '';
    if (isset($row['password_hash']) && $row['password_hash'] !== '') {
        $hash = $row['password_hash'];
    } elseif (isset($row['senha']) && $row['senha'] !== '') {
        $hash = $row['senha'];
    }
    if (!q_verify_password($senha, $hash)) {
        return null;
    }

    return [
        'id'    => isset($row['id']) ? $row['id'] : null,
        'login' => isset($row['username']) && $row['username'] !== '' ? $row['username'] : ($row['usuario'] ?? $login),
        'nome'  => $row['nome'] ?? ($row['usuario'] ?? $login),
        'nivel' => $row['nivel_acesso'] ?? ($row['nivel'] ?? 'caixa'),
    ];
}

/** Marca a sessão como logada. */
function q_login_sessao($user) {
    q_session_start();
    session_regenerate_id(true);
    $_SESSION['user'] = $user;
    $_SESSION['login_at'] = time();
    $_SESSION['last_seen'] = time();
}

/** Exige login; redireciona para login.php se não autenticado. */
function q_require_login() {
    q_session_start();
    $logged = !empty($_SESSION['user']);
    if ($logged && SESSION_TIMEOUT > 0) {
        $last = isset($_SESSION['last_seen']) ? (int)$_SESSION['last_seen'] : 0;
        if ($last && (time() - $last) > SESSION_TIMEOUT) {
            q_logout();
            $logged = false;
        }
    }
    if (!$logged) {
        header('Location: login.php?expirado=1');
        exit;
    }
    $_SESSION['last_seen'] = time();
    return $_SESSION['user'];
}

function q_current_user() {
    q_session_start();
    return $_SESSION['user'] ?? null;
}

function q_logout() {
    q_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}


/**
 * Lista os usuários ativos para o dropdown da tela de login.
 * Retorna [['login' => ..., 'nome' => ...], ...] ordenado por nome.
 * Em caso de erro/banco indisponível, retorna [] (login cai para campo de texto).
 */
function q_listar_usuarios() {
    try {
        $pdo = q_pdo();
        if (!q_table_exists($pdo, 'usuarios')) {
            return [];
        }
        $cols = q_table_columns($pdo, 'usuarios');
        $sel = [];
        $sel[] = isset($cols['username']) ? '`username`' : "'' AS username";
        $sel[] = isset($cols['usuario'])  ? '`usuario`'  : "'' AS usuario";
        $sel[] = isset($cols['nome'])     ? '`nome`'     : "'' AS nome";
        $whereAtivo = isset($cols['ativo']) ? ' WHERE (`ativo` = 1 OR `ativo` IS NULL)' : '';
        $sql = 'SELECT ' . implode(', ', $sel) . ' FROM usuarios' . $whereAtivo;
        $st = $pdo->query($sql);
        $out = [];
        $vistos = [];
        foreach ($st->fetchAll() as $r) {
            $login = trim((string)(($r['username'] ?? '') !== '' ? $r['username'] : ($r['usuario'] ?? '')));
            if ($login === '') {
                continue;
            }
            $k = mb_strtolower($login, 'UTF-8');
            if (isset($vistos[$k])) {
                continue;
            }
            $vistos[$k] = true;
            $nome = trim((string)(($r['nome'] ?? '') !== '' ? $r['nome'] : $login));
            $out[] = ['login' => $login, 'nome' => $nome];
        }
        usort($out, function ($a, $b) {
            return strcasecmp($a['nome'], $b['nome']);
        });
        return $out;
    } catch (Exception $e) {
        return [];
    }
}
