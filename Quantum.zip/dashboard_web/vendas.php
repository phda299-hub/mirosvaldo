<?php
/**
 * SISTEMA QUANTUM - GESTÃO DE VENDAS ELITE
 * Versão: 3.3.1 "Prosperity Master Document - Hotfix"
 * Nível: Sênior / Enterprise / Ultra-High-End
 * Descrição: Arquivo definitivo e unificado. Contém todas as lógicas originais, interface futurista, 
 *           modal de inteligência de dados e relatório de impressão formal de prestígio.
 */

// --- DEBUG & ERROR REPORTING (SÊNIOR) ---
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// O erro de sessão no InfinityFree ocorre no auth.php. 
// Vamos apenas garantir que o vendas.php continue a execução.

/** Teste de Integridade de Dependências */
if (!file_exists(__DIR__ . '/auth.php')) {
    die("<div style='padding:20px; background:#fee2e2; color:#991b1b; font-family:sans-serif; border-radius:8px; border:1px solid #ef4444;'><b>ERRO CRÍTICO:</b> O arquivo 'auth.php' não foi encontrado. Verifique se ele está no mesmo diretório.</div>");
}

require_once __DIR__ . '/auth.php';

try {
    $user = q_require_login();
    $pdo = q_pdo();
    if (!$pdo) throw new Exception("Falha ao inicializar a conexão PDO via q_pdo().");
} catch (Throwable $e) {
    die("<div style='padding:20px; background:#fff7ed; color:#9a3412; font-family:sans-serif; border-radius:8px; border:1px solid #f97316;'><b>ERRO DE AMBIENTE:</b> " . htmlspecialchars($e->getMessage()) . "<br><small>Verifique as configurações de banco de dados e autenticação.</small></div>");
}

// Verificação de Integridade do Banco de Dados
$existe = q_table_exists($pdo, 'vendas');
$cols = $existe ? q_table_columns($pdo, 'vendas') : [];

$colFormasJson = isset($cols['formas_pagamento']); // JSON: {forma: valor, Desconto:..., ...}
$colFormaStr   = isset($cols['forma_pagamento']);  // string simples

// --- HELPER FUNCTIONS (CORE & ROBUSTNESS) ---

function vcol($cols, $name, $default) {
    return isset($cols[strtolower($name)]) ? ('v.`' . $name . '`') : $default;
}

function vval($cols, $cands) {
    $p = [];
    foreach ($cands as $c) { if (isset($cols[strtolower($c)])) { $p[] = "NULLIF(v.`$c`,0)"; } }
    return $p ? ('COALESCE(' . implode(',', $p) . ',0)') : '0';
}

/** Sanitização Avançada de Output (Prevenção de Conflito) */
if (!function_exists('h')) {
    function h($str) { return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8'); }
}

/** Tradução de Status para Classes Visuais Modernas (Prevenção de Conflito) */
if (!function_exists('venda_status_class')) {
    function venda_status_class($s) {
        $s = strtolower(trim((string)$s));
        if ($s === '') return 'status-neutral';
        foreach (['cancel','estorn','devolv','atras'] as $k) { if (strpos($s, $k) !== false) return 'status-danger'; }
        foreach (['pend','aberto','aguard'] as $k) { if (strpos($s, $k) !== false) return 'status-warning'; }
        foreach (['pago','final','conclu','quit','aprov'] as $k) { if (strpos($s, $k) !== false) return 'status-success'; }
        return 'status-neutral';
    }
}

/** Formatação de Data Brasileira com Suporte a Timestamp (Prevenção de Conflito) */
if (!function_exists('data_br')) {
    function data_br($ymd) {
        $ymd = trim((string)$ymd);
        if ($ymd === '' || substr($ymd,0,10) === '0000-00-00') return '';
        $p = explode('-', substr($ymd, 0, 10));
        return (count($p) === 3) ? "$p[2]/$p[1]/$p[0]" : $ymd;
    }
}

/** Extrai as formas de pagamento reais (e seus valores) do JSON formas_pagamento. */
function parse_formas($json) {
    $out = [];
    if (!$json) return $out;
    
    $json = trim((string)$json);
    
    // Tenta decodificar o JSON normalmente primeiro
    $d = json_decode($json, true);
    
    // Se falhar (JSON truncado como na Venda #2 do SQL), usamos um extrator via Regex Ultra-Robusto
    if (!is_array($d)) {
        // Padrão para capturar "Chave": Valor em strings que parecem JSON mesmo que quebradas
        preg_match_all('/"([^"]+)":\s*([0-9.]+)/', $json, $matches, PREG_SET_ORDER);
        if ($matches) {
            $d = [];
            foreach ($matches as $m) {
                $d[$m[1]] = $m[2];
            }
        } else {
            // Se não for JSON nem tiver padrão, trata como string simples (fallback)
            if ($json !== '' && strpos($json, '{') === false) {
                return [['forma' => $json, 'valor' => 0]]; 
            }
            return $out;
        }
    }

    // Mapeamento de exclusão de metadados
    $metadados = ['bandeira', 'id', 'taxa', 'acrescimo', 'original', 'parcela', 'autoriz', 'nsu', 'observ', 'taxa_valor'];

    foreach ($d as $k => $v) {
        $kl = mb_strtolower(trim((string)$k), 'UTF-8');
        
        // Pula chaves de sistema e metadados
        $skip = false;
        foreach ($metadados as $meta) { if (strpos($kl, $meta) !== false) { $skip = true; break; } }
        if ($skip) continue;

        // Filtra campos de estrutura da venda que podem estar no JSON
        if (in_array($kl, ['total', 'subtotal', 'troco', 'desconto', 'cliente_id', 'is_delivery'])) continue;

        if (is_numeric($v)) {
            $val = (float)$v;
            if ($val > 0) {
                $nome = (string)$k;
                $nomesAmigaveis = [
                    'Dinheiro' => 'Dinheiro',
                    'CartaoDebito' => 'Cartão de Débito',
                    'CartaoCredito' => 'Cartão de Crédito',
                    'PIX' => 'PIX', 'Pix' => 'PIX',
                    'Boleto' => 'Boleto'
                ];
                $out[] = [
                    'forma' => $nomesAmigaveis[$nome] ?? $nome,
                    'valor' => $val
                ];
            }
        }
    }
    return $out;
}

/** Extrai os itens da venda quando estão num JSON (coluna `itens` da tabela vendas). */
function parse_itens_json($json) {
    $out = [];
    if (!$json) return $out;
    $d = json_decode($json, true);
    if (!is_array($d)) return $out;
    $lista = $d;
    $isAssoc = array_keys($d) !== range(0, count($d) - 1);
    if ($isAssoc) {
        if (isset($d['nome']) || isset($d['produto']) || isset($d['preco'])) { $lista = [$d]; }
        else { $lista = array_values($d); }
    }
    foreach ($lista as $it) {
        if (!is_array($it)) continue;
        $nome   = $it['nome'] ?? ($it['produto'] ?? ($it['descricao'] ?? 'Item sem nome'));
        $barras = $it['codigo_barras'] ?? ($it['codigo'] ?? ($it['ean'] ?? ($it['barras'] ?? '')));
        $pid    = $it['produto_id'] ?? ($it['id'] ?? '');
        $qtd    = $it['quantidade_peso'] ?? ($it['quantidade'] ?? ($it['qtd'] ?? ($it['quant'] ?? ($it['qtde'] ?? 0))));
        $unit   = $it['preco_unitario'] ?? ($it['preco'] ?? ($it['preco_unit'] ?? ($it['valor_unitario'] ?? ($it['valor'] ?? 0))));
        $sub    = $it['subtotal'] ?? ($it['total_item'] ?? ($it['total'] ?? null));
        $qn = (float)$qtd; $un = (float)$unit;
        $sn = ($sub === null || $sub === '') ? ($qn * $un) : (float)$sub;
        if ($qn == 0 && $un > 0 && $sn > 0) { $qn = $sn / $un; }
        if ($nome === '' && $un == 0 && $sn == 0) continue;
        $out[] = ['barras'=>(string)$barras, 'produto'=>(string)$nome, 'qtd'=>q_qtd($qn),
                  'unit'=>q_money($un), 'subtotal'=>q_money($sn), '_pid'=>(string)$pid];
    }
    return $out;
}

// Prioriza created_at para ter data e hora, depois tenta timestamp e por fim data
$dataCol = isset($cols['created_at']) ? 'v.`created_at`' : (isset($cols['timestamp']) ? 'v.`timestamp`' : (isset($cols['data']) ? 'v.`data`' : null));
$totalExpr = vval($cols, ['subtotal', 'total']);
$geralExpr = vval($cols, ['total', 'subtotal']);

// ---------- Detalhe de uma venda (AJAX API) ----------
if (isset($_GET['det'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $id = (int)$_GET['det'];
    $resp = ['ok' => false, 'itens' => [], 'venda' => null];
    if ($existe) {
        try {
            $st = $pdo->prepare("SELECT * FROM vendas WHERE `id` = ? LIMIT 1");
            $st->execute([$id]);
            $vd = $st->fetch();
            if ($vd) {
                $dt = isset($vd['created_at']) ? $vd['created_at'] : (isset($vd['timestamp']) ? $vd['timestamp'] : ($vd['data'] ?? ''));
                $pagsRaw = parse_formas($vd['formas_pagamento'] ?? '');
                $pags = [];
                foreach ($pagsRaw as $pp) { $pags[] = ['forma' => $pp['forma'], 'valor' => q_money($pp['valor'])]; }
                if (!$pags && !empty($vd['forma_pagamento'])) { $pags[] = ['forma' => $vd['forma_pagamento'], 'valor' => '']; }
                $resp['venda'] = [
                    'id' => $vd['id'] ?? $id,
                    'cliente' => $vd['cliente_nome'] ?? 'Consumidor Final',
                    'usuario' => $vd['usuario'] ?? 'Sistema',
                    'status' => $vd['status'] ?? 'Pendente',
                    'data' => data_br(substr((string)$dt, 0, 10)),
                    'hora' => (strlen((string)$dt) > 10) ? substr((string)$dt, 11, 5) : '--:--',
                    'subtotal' => q_money($vd['subtotal'] ?? 0),
                    'desconto' => q_money($vd['desconto'] ?? 0),
                    'acrescimo' => q_money($vd['acrescimo'] ?? 0),
                    'taxa' => q_money($vd['taxa_entrega'] ?? 0),
                    'troco' => q_money($vd['troco'] ?? 0),
                    'total' => q_money($vd['total'] ?? ($vd['subtotal'] ?? 0)),
                    'pagamentos' => $pags,
                ];
                $tItens = q_table_exists($pdo, 'vendas_itens') ? 'vendas_itens'
                        : (q_table_exists($pdo, 'itens_venda') ? 'itens_venda' : null);
                if ($tItens) {
                    $ic = q_table_columns($pdo, $tItens);
                    $prodExpr = isset($ic['produto']) ? 'i.`produto`' : (isset($ic['descricao']) ? 'i.`descricao`' : "''");
                    $codItem = isset($ic['codigo_barras']) ? 'i.`codigo_barras`' : (isset($ic['codigo']) ? 'i.`codigo`' : "''");
                    $joinProd = '';
                    $barrasExpr = $codItem;
                    if (isset($ic['produto_id']) && q_table_exists($pdo, 'produtos')) {
                        $pc = q_table_columns($pdo, 'produtos');
                        if (isset($pc['codigo_barras'])) {
                            $joinProd = ' LEFT JOIN produtos p ON p.`id` = i.`produto_id`';
                            $barrasExpr = "COALESCE(NULLIF(p.`codigo_barras`,''), NULLIF($codItem,''), '')";
                        }
                    }
                    $sti = $pdo->prepare("SELECT $prodExpr product, $barrasExpr barras,
                        " . (isset($ic['quantidade']) ? 'i.`quantidade`' : '0') . " quantidade,
                        " . (isset($ic['preco_unitario']) ? 'i.`preco_unitario`' : '0') . " preco_unitario,
                        " . (isset($ic['subtotal']) ? 'i.`subtotal`' : '0') . " subtotal
                        FROM `$tItens` i$joinProd WHERE i.`venda_id` = ?");
                    $sti->execute([$id]);
                    foreach ($sti->fetchAll() as $it) {
                        $resp['itens'][] = [
                            'barras' => (string)$it['barras'],
                            'produto' => (string)$it['product'], 'qtd' => q_qtd($it['quantidade']),
                            'unit' => q_money($it['preco_unitario']), 'subtotal' => q_money($it['subtotal']),
                        ];
                    }
                }
                if (empty($resp['itens']) && isset($vd['itens'])) {
                    $resp['itens'] = parse_itens_json($vd['itens']);
                }
                // Completa o código de barras a partir da tabela produtos (por id ou nome) quando faltar
                if (!empty($resp['itens']) && q_table_exists($pdo, 'produtos')) {
                    $pc = q_table_columns($pdo, 'produtos');
                    if (isset($pc['codigo_barras'])) {
                        $byId = isset($pc['id']) ? $pdo->prepare("SELECT codigo_barras FROM produtos WHERE id=? LIMIT 1") : null;
                        $byNome = isset($pc['nome']) ? $pdo->prepare("SELECT codigo_barras FROM produtos WHERE nome=? AND codigo_barras<>'' LIMIT 1") : null;
                        foreach ($resp['itens'] as $ix => $it2) {
                            if (($it2['barras'] ?? '') === '') {
                                $b = '';
                                if ($byId && !empty($it2['_pid'])) { $byId->execute([$it2['_pid']]); $rb = $byId->fetch(); if ($rb) { $b = (string)$rb['codigo_barras']; } }
                                if ($b === '' && $byNome && !empty($it2['produto'])) { $byNome->execute([$it2['produto']]); $rb = $byNome->fetch(); if ($rb) { $b = (string)$rb['codigo_barras']; } }
                                $resp['itens'][$ix]['barras'] = $b;
                            }
                        }
                    }
                }
                foreach ($resp['itens'] as $ix => $it2) { unset($resp['itens'][$ix]['_pid']); }
                $resp['ok'] = true;
            }
        } catch (Exception $e) { $resp['erro'] = 'Falha ao carregar a venda.'; }
    }
    echo json_encode($resp, JSON_UNESCAPED_UNICODE);
    exit;
}

$ehAjax = isset($_GET['ajax']);

$f = [
    'q'=>trim($_GET['q']??''), 'qm'=>trim($_GET['qm']??''), 'di'=>trim($_GET['di']??''),
    'df'=>trim($_GET['df']??''), 'fp'=>trim($_GET['fp']??''), 'stt'=>trim($_GET['stt']??''),
];
$pg = max(1, (int)($_GET['pg'] ?? 1));
$porPagina = 200;
if (isset($_GET['print'])) { $pg = 1; $porPagina = 100000; }

function montar_busca_vendas($cols, $colFormasJson, $colFormaStr, $dataCol, $f, &$params) {
    $w = [];
    $busca = function ($termo) use ($cols, &$params) {
        $campos = [];
        foreach (['cliente_nome','forma_pagamento','formas_pagamento','usuario','status'] as $c) {
            if (isset($cols[$c])) { $campos[] = "v.`$c` LIKE ?"; }
        }
        $campos[] = "CAST(v.`id` AS CHAR) LIKE ?";
        foreach ($campos as $_) { $params[] = '%' . $termo . '%'; }
        return '(' . implode(' OR ', $campos) . ')';
    };
    if ($f['q'] !== '')  { $w[] = $busca($f['q']); }
    if ($f['qm'] !== '') { $w[] = $busca($f['qm']); }
    if ($dataCol && $f['di'] !== '') { $w[] = "DATE($dataCol) >= ?"; $params[] = $f['di']; }
    if ($dataCol && $f['df'] !== '') { $w[] = "DATE($dataCol) <= ?"; $params[] = $f['df']; }
    if ($f['fp'] !== '') {
        $c = [];
        if ($colFormaStr)   { $c[] = 'v.`forma_pagamento` = ?';  $params[] = $f['fp']; }
        if ($colFormasJson) { $c[] = 'v.`formas_pagamento` LIKE ?'; $params[] = '%"' . $f['fp'] . '"%'; }
        if ($c) { $w[] = '(' . implode(' OR ', $c) . ')'; }
    }
    if ($f['stt'] !== '' && isset($cols['status'])) { $w[] = 'v.`status` = ?'; $params[] = $f['stt']; }
    return $w;
}

$rows = []; $totalFiltrado = 0; $totalPaginas = 1;
$kpi = ['n'=>0,'geral'=>0.0,'total'=>0.0,'ticket'=>0.0];
$erro_tabela = $existe ? '' : 'A tabela "vendas" ainda não existe no banco. Faça a sincronização no sistema Quantum.';

if ($existe) {
    $params = [];
    $where = montar_busca_vendas($cols, $colFormasJson, $colFormaStr, $dataCol, $f, $params);
    $whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

    $stK = $pdo->prepare("SELECT COUNT(*) n, COALESCE(SUM($geralExpr),0) g, COALESCE(SUM($totalExpr),0) t FROM vendas v$whereSql");
    $stK->execute($params);
    if ($rk = $stK->fetch()) {
        $kpi['n']=(int)$rk['n']; $kpi['geral']=(float)$rk['g']; $kpi['total']=(float)$rk['t'];
        $kpi['ticket']=$kpi['n']>0?($kpi['geral']/$kpi['n']):0.0;
    }
    $totalFiltrado=$kpi['n'];
    $totalPaginas=max(1,(int)ceil($totalFiltrado/$porPagina));
    if ($pg>$totalPaginas) $pg=$totalPaginas;
    $offset=($pg-1)*$porPagina;

    $ordem = $dataCol ? "$dataCol DESC, v.`id` DESC" : 'v.`id` DESC';
    $sql = "SELECT v.`id` id,
        " . ($colFormaStr ? "v.`forma_pagamento`" : "''") . " forma,
        " . ($colFormasJson ? "v.`formas_pagamento`" : "''") . " fjson,
        " . vcol($cols,'cliente_nome',"''") . " cliente,
        " . ($dataCol ? $dataCol : "''") . " ddt,
        $totalExpr vtotal, $geralExpr vgeral,
        " . vcol($cols,'status',"''") . " status,
        " . vcol($cols,'usuario',"'Sistema'") . " usuario
        FROM vendas v$whereSql ORDER BY $ordem LIMIT $porPagina OFFSET $offset";
    $stL = $pdo->prepare($sql);
    $stL->execute($params);
    $rows = $stL->fetchAll();
}

function fmt_venda($r) {
    $formasRaw = parse_formas($r['fjson'] ?? '');
    $formas = [];
    foreach ($formasRaw as $x) { $formas[] = ['forma'=>$x['forma'], 'valor'=>round($x['valor'],2), 'v'=>q_money($x['valor'])]; }

    $ddt = (string)$r['ddt'];
    $data = data_br(substr($ddt, 0, 10));
    $hora = (strlen($ddt) > 10) ? substr($ddt, 11, 5) : '';

    return [
        'id'=>(string)$r['id'],
        'forma'=>(string)$r['forma'], 'formas'=>$formas,
        'cliente'=>(string)$r['cliente'], 'data'=>$data,
        'hora'=>$hora,
        'total'=>q_money($r['vtotal']), 'geral'=>q_money($r['vgeral']),
        'status'=>(string)$r['status'], 'cls'=>venda_status_class($r['status']),
        'ngeral'=>round(q_num($r['vgeral']),2),
        'usuario'=>(string)$r['usuario']
    ];
}
$linhas = array_map('fmt_venda', $rows);

$ftMap = [];
if ($existe) {
    // Cálculo Global de Totais por Forma de Pagamento (Baseado nos filtros aplicados)
    // Buscamos todas as formas_pagamento (JSON) e forma_pagamento (String) de TODAS as vendas que batem com o filtro
    $sqlFT = "SELECT " . ($colFormasJson ? "v.`formas_pagamento`" : "''") . " fjson, " . ($colFormaStr ? "v.`forma_pagamento`" : "''") . " forma FROM vendas v$whereSql";
    $stFT = $pdo->prepare($sqlFT);
    $stFT->execute($params);
    while ($rFT = $stFT->fetch()) {
        $formasVenda = parse_formas($rFT['fjson'] ?? '');
        if (empty($formasVenda) && !empty($rFT['forma'])) {
            // Fallback para coluna string se o JSON estiver vazio
            // Como não temos o valor individual na coluna string, usamos o total da venda (ou 0 se não houver)
            // Mas para ser mais preciso, tentamos pegar o valor total daquela linha específica
            // Aqui, por simplicidade e precisão, focamos no que o parse_formas extrai do JSON.
        }
        foreach ($formasVenda as $fv) {
            $ftMap[$fv['forma']] = ($ftMap[$fv['forma']] ?? 0) + $fv['valor'];
        }
    }
}
$formasTotais = [];
foreach ($ftMap as $fm => $soma) { $formasTotais[] = ['forma'=>$fm, 'total'=>q_money($soma), 'raw'=>round($soma,2)]; }
usort($formasTotais, function($a,$b){ return $b['raw'] <=> $a['raw']; });

function forma_cell_html($formas, $fallback) {
    if (count($formas) > 1) {
        $s = '';
        foreach ($formas as $fp) { 
            $s .= '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.75rem; border-bottom:1px solid #f1f5f9; padding:2px 0;">';
            $s .= '<span style="color:#64748b;">'.h($fp['forma']).'</span>';
            $s .= '<b style="color:#1e293b;">'.h($fp['v']).'</b>';
            $s .= '</div>'; 
        }
        return '<div style="min-width:140px;">'.$s.'</div>';
    }
    if (count($formas) === 1) {
        return '<div style="font-weight:600; color:#1e293b;">'.h($formas[0]['forma']).'</div>';
    }
    return '<div style="color:#64748b;">'.h($fallback ?: 'Não informado').'</div>';
}

if ($ehAjax) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'ok'=>$erro_tabela==='', 'erro'=>$erro_tabela, 'hora'=>date('H:i:s'),
        'total'=>$totalFiltrado, 'paginas'=>$totalPaginas, 'pg'=>$pg,
        'kpi'=>['n'=>$kpi['n'],'geral'=>$kpi['geral'],'total'=>$kpi['total'],'ticket'=>$kpi['ticket']],
        'formasTotais'=>$formasTotais,
        'rows'=>$linhas,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$statusOpts = []; 
$formaOpts  = [];

if ($existe) {
    // Busca Status Dinâmicos
    if (isset($cols['status'])) { 
        $st2 = $pdo->query("SELECT DISTINCT `status` FROM vendas WHERE `status` IS NOT NULL AND `status` <> '' ORDER BY `status` LIMIT 50"); 
        $statusOpts = $st2 ? $st2->fetchAll(\PDO::FETCH_COLUMN) : []; 
    }
    
    // Busca Formas de Pagamento Dinâmicas (Coluna String e JSON)
    $fSet = [];
    if ($colFormaStr) { 
        $st3 = $pdo->query("SELECT DISTINCT `forma_pagamento` FROM vendas WHERE `forma_pagamento` IS NOT NULL AND `forma_pagamento` <> '' LIMIT 100"); 
        if ($st3) { foreach($st3->fetchAll(\PDO::FETCH_COLUMN) as $v) { $fSet[trim($v)] = true; } }
    }
    
    // Extração Completa do JSON de formas_pagamento (Varredura total para garantir que nada falte)
    if ($colFormasJson) {
        $st4 = $pdo->query("SELECT DISTINCT formas_pagamento FROM vendas WHERE formas_pagamento IS NOT NULL AND formas_pagamento <> ''");
        if ($st4) {
            foreach($st4->fetchAll(\PDO::FETCH_COLUMN) as $json) {
                $p = parse_formas($json);
                foreach($p as $pp) { $fSet[trim($pp['forma'])] = true; }
            }
        }
    }
    $formaOpts = array_keys($fSet);
    sort($formaOpts);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quantum | Gestão de Vendas Elite</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
/* ===== Reset / Base ===== */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Inter', Arial, sans-serif; font-size: 14px; background: #f4f7fa; color: #334155; line-height: 1.5; -webkit-font-smoothing: antialiased; }
a { color: inherit; text-decoration: none; }

/* ===== Layout ===== */
.page-wrap { max-width: 1600px; margin: 0 auto; padding: 2rem; }
.page-header { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 2rem; animation: slideDown 0.5s ease; }
.page-title { font-size: 1.875rem; font-weight: 800; color: #1e293b; letter-spacing: -0.025em; }
.page-subtitle { color: #64748b; font-size: 0.875rem; display: block; }

/* ===== Botões ===== */
.btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.625rem 1.25rem; border-radius: 0.5rem; font-size: 0.875rem; font-weight: 600; cursor: pointer; border: none; transition: all 0.2s; }
.btn-primary { background: #3b82f6; color: #fff; }
.btn-primary:hover { background: #2563eb; }
.btn-secondary { background: #ffffff; color: #334155; border: 1px solid #e2e8f0; }
.btn-secondary:hover { background: #f8fafc; }
.btn-print { background: #1e293b; color: #fff; }
.btn-print:hover { background: #0f172a; }

/* ===== KPIs ===== */
.kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
.kpi-card { background: #fff; border-radius: 1rem; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); border: 1px solid #e2e8f0; border-left: 4px solid #3b82f6; transition: transform 0.2s; }
.kpi-card:hover { transform: translateY(-4px); }
.kpi-card.kpi-geral { border-left-color: #10b981; }
.kpi-card.kpi-ticket { border-left-color: #f59e0b; }
.kpi-label { font-size: 0.875rem; font-weight: 600; color: #64748b; text-transform: uppercase; margin-bottom: 0.5rem; }
.kpi-val   { font-size: 1.5rem; font-weight: 700; color: #1e293b; }

/* ===== Filtros ===== */
.filtros-form { background: #fff; border-radius: 1rem; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); border: 1px solid #e2e8f0; margin-bottom: 2rem; }
.filtros-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; align-items: end; }
.filtros-grid label { display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.75rem; color: #64748b; font-weight: 700; text-transform: uppercase; }
.filtros-grid input, .filtros-grid select { padding: 0.625rem; border: 1px solid #e2e8f0; border-radius: 0.5rem; font-size: 0.875rem; background: #f8fafc; font-family: inherit; transition: all 0.2s; }
.filtros-grid input:focus, .filtros-grid select:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2); background: #fff; }

/* ===== Formas totais ===== */
.formas-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 1.5rem; }
.fp-tag { background: #fff; border: 1px solid #e2e8f0; border-radius: 9999px; padding: 0.25rem 1rem; font-size: 0.82rem; color: #334155; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
.fp-tag b { color: #10b981; margin-left: 0.5rem; font-weight: 700; }

/* ===== Tabela Principal ===== */
.table-wrap { background: #fff; border-radius: 1rem; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); border: 1px solid #e2e8f0; overflow: hidden; }
table { width: 100%; border-collapse: collapse; }
thead th { background: #1e293b; color: #fff; padding: 1rem; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; text-align: left; }
tbody tr.sale-row { border-bottom: 1px solid #e2e8f0; transition: background 0.2s; cursor: pointer; }
tbody tr.sale-row:hover { background: #f8fafc; }
tbody td { padding: 1rem; vertical-align: middle; }
.col-id   { font-weight: 700; color: #3b82f6; width: 80px; }
.col-data-hora { white-space: nowrap; font-weight: 600; }
.txt-hora { font-size: 0.75rem; color: #64748b; display: block; font-weight: 400; }
.col-valor { text-align: right; font-weight: 700; white-space: nowrap; }

/* Status badges */
.badge { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700; }
.status-success .badge { background: #dcfce7; color: #166534; }
.status-danger .badge { background: #fee2e2; color: #991b1b; }
.status-warning .badge { background: #fef9c3; color: #854d0e; }
.status-neutral .badge { background: #f1f5f9; color: #475569; }

/* ===== Sub-tabela de Itens (Segregada) ===== */
.item-row { background: #f1f5f9 !important; animation: fadeIn 0.3s ease; display: none; }
.item-table-wrapper { padding: 1rem 2rem 2rem 4rem; }
.item-title { font-size: 0.75rem; font-weight: 800; color: #64748b; text-transform: uppercase; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem; }
.item-table { width: 100%; background: #fff; border-radius: 0.75rem; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
.item-table th { background: #475569; color: #fff; padding: 0.75rem 1rem; font-size: 0.7rem; }
.item-table td { padding: 0.75rem 1rem; font-size: 0.8rem; border-bottom: 1px solid #f1f5f9; }
.item-table tr:last-child td { border-bottom: none; }
.item-table tr:hover { background: transparent; }

/* ===== Paginação ===== */
.paginacao { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding: 1.5rem; font-size: 0.875rem; color: #64748b; border-top: 1px solid #e2e8f0; }
.pag-btns { display: flex; gap: 0.25rem; }
.pag-btn { padding: 0.5rem 1rem; border-radius: 0.5rem; border: 1px solid #e2e8f0; background: #fff; cursor: pointer; font-weight: 600; color: #334155; transition: all 0.2s; }
.pag-btn:hover { background: #f8fafc; border-color: #3b82f6; color: #3b82f6; }
.pag-btn.ativo { background: #3b82f6; color: #fff; border-color: #3b82f6; pointer-events: none; }

/* ===== Modal detalhe (Duplo Clique) ===== */
.modal-bg { display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.75); z-index: 1000; align-items: center; justify-content: center; padding: 1rem; backdrop-filter: blur(4px); }
.modal-bg.aberto { display: flex; }
.modal { background: #fff; border-radius: 1.5rem; width: 100%; max-width: 800px; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25); animation: zoomIn 0.3s ease; }
.modal-header { display: flex; align-items: center; justify-content: space-between; padding: 1.5rem 2rem; background: #1e293b; color: #fff; }
.modal-header h2 { font-size: 1.25rem; font-weight: 800; }
.modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #94a3b8; line-height: 1; transition: color 0.2s; }
.modal-close:hover { color: #fff; }
.modal-body { padding: 2rem; }
.det-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem; }
.det-item label { font-size: 0.75rem; color: #64748b; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 0.25rem; }
.det-item span  { font-size: 1.1rem; font-weight: 700; color: #1e293b; }
.det-financeiro { background: #f8fafc; padding: 1.5rem; border-radius: 1rem; margin-bottom: 2rem; border: 1px solid #e2e8f0; }
.det-fin-row { display: flex; justify-content: space-between; margin-bottom: 0.5rem; font-weight: 500; }
.det-fin-total { display: flex; justify-content: space-between; margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #e2e8f0; font-size: 1.5rem; font-weight: 800; color: #1e293b; }

/* ===== Animações ===== */
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes zoomIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }

/* ===== PRINT: ELITE DOCUMENT DESIGN ===== */
@media print {
    /* Ocultar elementos de UI */
    .filtros-form, .paginacao, .btn, .page-header div:last-child, .modal-bg { display: none !important; }
    
    body { background: #fff; color: #000; padding: 0; margin: 0; font-size: 10pt; }
    .page-wrap { max-width: 100%; padding: 0; margin: 0; }

    /* Cabeçalho Timbrado Formal */
    .page-header {
        display: block !important;
        text-align: center;
        border-bottom: 2px solid #000;
        padding-bottom: 10pt;
        margin-bottom: 20pt;
    }
    .page-title { font-size: 24pt; font-weight: 900; margin-bottom: 5pt; text-transform: uppercase; }
    .page-header::after {
        content: "RELATÓRIO FORMAL DE MOVIMENTAÇÃO DE VENDAS | EMITIDO EM: <?= date('d/m/Y H:i:s') ?>";
        display: block;
        font-size: 8pt;
        font-weight: 600;
        color: #444;
        margin-top: 5pt;
    }

    /* Resumo Executivo (KPIs em Print) */
    .kpi-row {
        display: flex !important;
        grid-template-columns: none;
        justify-content: space-between;
        margin-bottom: 20pt;
        border: 1px solid #000;
        padding: 10pt;
        background: #f9f9f9 !important;
        -webkit-print-color-adjust: exact;
    }
    .kpi-card {
        border: none;
        box-shadow: none;
        padding: 0;
        margin: 0;
        text-align: center;
        flex: 1;
    }
    .kpi-label { font-size: 7pt; color: #000; margin-bottom: 2pt; }
    .kpi-val { font-size: 14pt; font-weight: 900; color: #000; }

    /* Tabela de Dados Master */
    .table-wrap { border: 1px solid #000; border-radius: 0; box-shadow: none; }
    table { width: 100%; border-collapse: collapse; }
    thead th {
        background: #000 !important;
        color: #fff !important;
        padding: 8pt 5pt;
        font-size: 8pt;
        border: 1px solid #000;
        -webkit-print-color-adjust: exact;
    }
    tbody td {
        padding: 6pt 5pt;
        border: 1px solid #ddd;
        font-size: 8pt;
    }
    .sale-row { background: #fff !important; }
    .sale-row:nth-child(4n+1) { background: #f2f2f2 !important; -webkit-print-color-adjust: exact; }

    /* Sub-tabela de Itens (Expansão no Print) */
    .item-row {
        display: table-row !important;
        background: #fff !important;
    }
    .item-table-wrapper {
        padding: 5pt 10pt 15pt 30pt;
    }
    .item-title {
        font-size: 7pt;
        font-weight: 900;
        color: #000;
        border-bottom: 1px solid #000;
        margin-bottom: 5pt;
        padding-bottom: 2pt;
    }
    .item-table {
        border: 1px solid #000;
        border-radius: 0;
    }
    .item-table th {
        background: #eee !important;
        color: #000 !important;
        border: 1px solid #000;
        padding: 4pt;
        font-size: 7pt;
        -webkit-print-color-adjust: exact;
    }
    .item-table td {
        border: 1px solid #eee;
        padding: 3pt 5pt;
        font-size: 7pt;
    }

    /* Rodapé de Página e Assinatura */
    body::after {
        content: "__________________________________________________\A ASSINATURA DO RESPONSÁVEL OPERACIONAL";
        display: block;
        text-align: center;
        margin-top: 50pt;
        font-size: 8pt;
        font-weight: 700;
        white-space: pre;
    }

    @page { margin: 1.5cm; size: A4 portrait; }
}
</style>
</head>
<body>

<div class="page-wrap">

  <!-- Cabeçalho -->
  <div class="page-header">
    <div>
        <h1 class="page-title">Quantum <span style="color:#3b82f6">Prosperity</span></h1>
        <span class="page-subtitle">Gestão de Vendas Inteligente & Futurista</span>
    </div>
    <div style="display:flex; gap:0.5rem; align-items: center;">
        <button class="btn btn-secondary" onclick="window.history.back()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Voltar
        </button>
        <button class="btn btn-print" onclick="window.print()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
            Imprimir Relatório
        </button>
        <div style="display:flex; align-items:center; gap:0.5rem; background:#fff; padding:0.625rem; border-radius:0.5rem; border:1px solid #e2e8f0;">
            <div id="js-live-indicator" style="width:8px; height:8px; background:#10b981; border-radius:50%; animation: pulse 1.5s infinite;"></div>
            <span style="font-size:0.75rem; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.05em;">Live</span>
            <span id="js-hora" style="font-weight:700; color:#1e293b; font-family:monospace; margin-left:5px; border-left:1px solid #e2e8f0; padding-left:10px;"></span>
        </div>
    </div>
  </div>

<style>
@keyframes pulse {
    0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
    70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
    100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}
</style>

  <?php if ($erro_tabela): ?>
  <div style="background:#fef9c3; border:1px solid #f59e0b; padding:1rem; border-radius:0.5rem; color:#854d0e; margin-bottom:2rem; font-weight:600;"><?= h($erro_tabela) ?></div>
  <?php endif; ?>

  <!-- KPIs -->
  <div class="kpi-row" id="js-kpis">
    <div class="kpi-card">
      <div class="kpi-label">Volume de Vendas</div>
      <div class="kpi-val" id="kpi-n"><?= h($kpi['n']) ?></div>
    </div>
    <div class="kpi-card kpi-geral">
      <div class="kpi-label">Faturamento Total</div>
      <div class="kpi-val" id="kpi-geral"><?= h(q_money($kpi['geral'])) ?></div>
    </div>
    <div class="kpi-card kpi-ticket">
      <div class="kpi-label">Ticket Médio</div>
      <div class="kpi-val" id="kpi-ticket"><?= h(q_money($kpi['ticket'])) ?></div>
    </div>
  </div>

  <!-- Filtros -->
  <form class="filtros-form" id="js-form" method="get" action="">
    <div class="filtros-grid">
      <label>Busca Inteligente
        <input type="text" name="q" value="<?= h($f['q']) ?>" placeholder="Cliente, ID, Operador...">
      </label>
      <?php if ($dataCol): ?>
      <label>Data Inicial
        <input type="date" name="di" value="<?= h($f['di']) ?>">
      </label>
      <label>Data Final
        <input type="date" name="df" value="<?= h($f['df']) ?>">
      </label>
      <?php endif; ?>
      <label>Forma de Pagamento
        <select name="fp">
          <option value="">Todas as Formas</option>
          <?php foreach ($formaOpts as $fo): ?>
          <option value="<?= h($fo) ?>" <?= $f['fp']===$fo?'selected':'' ?>><?= h($fo) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <?php if ($statusOpts): ?>
      <label>Status
        <select name="stt">
          <option value="">Todos</option>
          <?php foreach ($statusOpts as $so): ?>
          <option value="<?= h($so) ?>" <?= $f['stt']===$so?'selected':'' ?>><?= h($so) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <?php endif; ?>
      <div style="display:flex; gap:0.5rem;">
        <button type="submit" class="btn btn-primary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            Filtrar
        </button>
        <a href="?" class="btn btn-secondary">Limpar</a>
      </div>
    </div>
  </form>

  <!-- Totais por forma de pagamento -->
  <?php if ($formasTotais): ?>
  <div class="formas-bar" id="js-formas-bar">
    <?php foreach ($formasTotais as $ft): ?>
    <span class="fp-tag"><?= h($ft['forma']) ?><b><?= h($ft['total']) ?></b></span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Tabela de vendas -->
  <div class="table-wrap">
    <table id="js-tabela">
      <thead>
        <tr>
          <th class="col-id"># ID</th>
          <?php if ($dataCol): ?><th>Data / Hora</th><?php endif; ?>
          <th>Cliente / Operador</th>
          <th>Forma de Pagamento</th>
          <?php if (isset($cols['status'])): ?><th>Status</th><?php endif; ?>
          <th class="col-valor">Subtotal</th>
          <th class="col-valor">Total Final</th>
        </tr>
      </thead>
      <tbody id="js-tbody">
        <?php if (empty($linhas)): ?>
        <tr><td colspan="7" style="text-align:center; padding:3rem; color:#64748b; font-weight:500;">Nenhum registro encontrado para os filtros aplicados.</td></tr>
        <?php else: ?>
        <?php 
        $tItens = q_table_exists($pdo, 'vendas_itens') ? 'vendas_itens' : (q_table_exists($pdo, 'itens_venda') ? 'itens_venda' : null);
        foreach ($linhas as $l): 
            $vendaId = (int)$l['id'];
            $itensArray = [];
            if ($tItens) {
                try {
                    $ic = q_table_columns($pdo, $tItens);
                    $prodExpr = isset($ic['produto']) ? 'i.`produto`' : (isset($ic['descricao']) ? 'i.`descricao`' : "''");
                    $codItem = isset($ic['codigo_barras']) ? 'i.`codigo_barras`' : (isset($ic['codigo']) ? 'i.`codigo`' : "''");
                    $joinProd = ''; $barrasExpr = $codItem;
                    if (isset($ic['produto_id']) && q_table_exists($pdo, 'produtos')) {
                        $pc = q_table_columns($pdo, 'produtos');
                        if (isset($pc['codigo_barras'])) {
                            $joinProd = ' LEFT JOIN produtos p ON p.`id` = i.`produto_id`';
                            $barrasExpr = "COALESCE(NULLIF(p.`codigo_barras`,''), NULLIF($codItem,''), '')";
                        }
                    }
                    $sti = $pdo->prepare("SELECT $prodExpr product, $barrasExpr barras, " . (isset($ic['quantidade']) ? 'i.`quantidade`' : '0') . " quantidade, " . (isset($ic['preco_unitario']) ? 'i.`preco_unitario`' : '0') . " preco_unitario, " . (isset($ic['subtotal']) ? 'i.`subtotal`' : '0') . " subtotal FROM `$tItens` i$joinProd WHERE i.`venda_id` = ?");
                    $sti->execute([$vendaId]);
                    foreach ($sti->fetchAll() as $it) {
                        $itensArray[] = ['barras'=>(string)$it['barras'],'produto'=>(string)$it['product'],'qtd'=>q_qtd($it['quantidade']),'unit'=>q_money($it['preco_unitario']),'subtotal'=>q_money($it['subtotal'])];
                    }
                } catch (Exception $e) { }
            }
            if (empty($itensArray)) {
                $stv = $pdo->prepare("SELECT itens FROM vendas WHERE id = ? LIMIT 1");
                $stv->execute([$vendaId]);
                if ($vd = $stv->fetch()) { if (isset($vd['itens'])) { $itensArray = parse_itens_json($vd['itens']); } }
            }
        ?>
        <tr class="sale-row <?= h($l['cls']) ?>" data-id="<?= h($l['id']) ?>" onclick="toggleItems(<?= h($l['id']) ?>)">
          <td class="col-id"><?= h($l['id']) ?></td>
          <?php if ($dataCol): ?>
          <td class="col-data-hora">
            <?= h($l['data']) ?>
            <?php if ($l['hora']): ?><span class="txt-hora"><?= h($l['hora']) ?></span><?php endif; ?>
          </td>
          <?php endif; ?>
          <td>
            <div style="font-weight:600; color:#1e293b;"><?= h($l['cliente']) ?: 'Consumidor Final' ?></div>
            <div style="font-size:0.75rem; color:#64748b;">Op: <?= h($l['usuario'] ?? 'Sistema') ?></div>
          </td>
          <td><?= forma_cell_html($l['formas'], $l['forma']) ?></td>
          <?php if (isset($cols['status'])): ?>
          <td class="col-status"><span class="badge"><?= h($l['status']) ?></span></td>
          <?php endif; ?>
          <td class="col-valor" style="color:#64748b;"><?= h($l['total']) ?></td>
          <td class="col-valor" style="color:#1e293b; font-weight:800;"><?= h($l['geral']) ?></td>
        </tr>
        
        <?php if (!empty($itensArray)): ?>
        <tr id="items-<?= h($l['id']) ?>" class="item-row">
            <td colspan="7">
                <div class="item-table-wrapper">
                    <div class="item-title">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
                        Itens da Venda #<?= h($l['id']) ?>
                    </div>
                    <table class="item-table">
                        <thead>
                            <tr>
                                <th style="width:50%">Produto / Descrição</th>
	                                <th style="width:10%; text-align:right;">Qtd</th>
	                                <th style="width:20%; text-align:right;">Unitário</th>
	                                <th style="width:20%; text-align:right;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($itensArray as $it): ?>
                            <tr>
	                                <td style='font-weight:600;'><?= h($it['produto']) ?></td>
	                                <td style='text-align:right;'><?= h($it['qtd']) ?></td>
	                                <td style='text-align:right;'><?= h($it['unit']) ?></td>
	                                <td style='text-align:right; font-weight:700; color:#3b82f6;'><?= h($it['subtotal']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <!-- Paginação -->
    <?php if ($totalPaginas > 1): ?>
    <div class="paginacao" id="js-paginacao">
      <span style="font-weight:600;">
        Página <?= $pg ?> de <?= $totalPaginas ?> &mdash; <span style="color:#1e293b;"><?= $totalFiltrado ?> registros</span>
      </span>
      <div class="pag-btns">
        <?php
        $urlBase = '?' . http_build_query(array_merge($f, ['pg'=>'__PG__']));
        $inicio = max(1, $pg - 3);
        $fim    = min($totalPaginas, $pg + 3);
        if ($pg > 1): ?>
        <a href="<?= str_replace('__PG__', $pg-1, $urlBase) ?>" class="pag-btn">&laquo;</a>
        <?php endif; ?>
        <?php for ($i = $inicio; $i <= $fim; $i++): ?>
        <a href="<?= str_replace('__PG__', $i, $urlBase) ?>" class="pag-btn <?= $i===$pg?'ativo':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($pg < $totalPaginas): ?>
        <a href="<?= str_replace('__PG__', $pg+1, $urlBase) ?>" class="pag-btn">&raquo;</a>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Modal detalhe da venda (Duplo Clique) -->
<div class="modal-bg" id="js-modal" role="dialog" aria-modal="true">
  <div class="modal">
    <div class="modal-header">
      <h2 id="js-modal-titulo">Painel de Inteligência da Venda</h2>
      <button class="modal-close" id="js-modal-fechar" aria-label="Fechar">&times;</button>
    </div>
    <div class="modal-body" id="js-modal-body">
      <div style="text-align:center; padding:3rem; color:#64748b;">Processando dados...</div>
    </div>
  </div>
</div>

<script>
(function () {
  'use strict';

  // --- MOTOR DE ATUALIZAÇÃO ATÔMICA EM TEMPO REAL ---
  let lastSaleId = <?= count($linhas) > 0 ? (int)$linhas[0]['id'] : 0 ?>;
  let isUpdating = false;

  function atualizarHora() {
    var el = document.getElementById('js-hora');
    if (el) { el.textContent = new Date().toLocaleTimeString('pt-BR'); }
  }
  atualizarHora();
  setInterval(atualizarHora, 1000);

  /** 
   * Sincronização Atômica: Verifica novas vendas e atualiza KPIs/Tabela instantaneamente
   */
  async function syncAtomic() {
    if (isUpdating) return;
    isUpdating = true;

    try {
        const params = new URLSearchParams(window.location.search);
        params.set('ajax', '1');
        
        const response = await fetch('?' + params.toString());
        const data = await response.json();

        if (data.ok && data.rows && data.rows.length > 0) {
            const latestId = parseInt(data.rows[0].id);
            
            // Se detectarmos uma nova venda (ID maior que o último registrado)
            if (latestId > lastSaleId) {
                renderAtomicTable(data.rows);
                updateKPIsAtomic(data.kpi, data.formasTotais);
                lastSaleId = latestId;
                console.log('Quantum Prosperity: Sincronização Atômica Concluída. Nova venda detectada.');
            }
        }
    } catch (err) {
        console.error('Falha na sincronização atômica:', err);
    } finally {
        isUpdating = false;
    }
  }

  function renderAtomicTable(rows) {
    const tbody = document.getElementById('js-tbody');
    if (!tbody) return;

    // Preservamos a lógica de clique e classes originais
    let html = '';
    rows.forEach(l => {
        html += `
        <tr class="sale-row ${l.cls}" data-id="${l.id}" onclick="toggleItems(${l.id})">
          <td class="col-id">${l.id}</td>
          <td class="col-data-hora">
            ${l.data}
            ${l.hora ? `<span class="txt-hora">${l.hora}</span>` : ''}
          </td>
          <td>
            <div style="font-weight:600; color:#1e293b;">${l.cliente || 'Consumidor Final'}</div>
            <div style="font-size:0.75rem; color:#64748b;">Op: ${l.usuario || 'Sistema'}</div>
          </td>
          <td>
            ${l.formas && l.formas.length > 1 
                ? `<div style="min-width:140px;">${l.formas.map(f => `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.75rem; border-bottom:1px solid #f1f5f9; padding:2px 0;"><span style="color:#64748b;">${f.forma}</span><b style="color:#1e293b;">${f.v}</b></div>`).join('')}</div>`
                : `<div style="font-weight:600; color:#1e293b;">${l.forma || 'Não informado'}</div>`
            }
          </td>
          <td class="col-status"><span class="badge">${l.status}</span></td>
          <td class="col-valor" style="color:#64748b;">${l.total}</td>
          <td class="col-valor" style="color:#1e293b; font-weight:800;">${l.geral}</td>
        </tr>
        <tr id="items-${l.id}" class="item-row">
            <td colspan="7">
                <div class="item-table-wrapper">
                    <div class="item-title">Buscando itens em tempo real...</div>
                </div>
            </td>
        </tr>`;
    });
    tbody.innerHTML = html;
    
    // Reatribui eventos de duplo clique
    document.querySelectorAll('.sale-row').forEach(row => {
        row.addEventListener('dblclick', function(e) {
            e.preventDefault();
            abrirDetalhe(this.dataset.id);
        });
    });
  }

  function updateKPIsAtomic(kpi, formasTotais) {
    const n = document.getElementById('kpi-n');
    const g = document.getElementById('kpi-geral');
    const t = document.getElementById('kpi-ticket');
    const fBar = document.getElementById('js-formas-bar');

    if (n) n.textContent = kpi.n;
    if (g) g.textContent = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(kpi.geral);
    if (t) t.textContent = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(kpi.ticket);

    if (fBar && formasTotais) {
        let fHtml = '';
        formasTotais.forEach(ft => {
            fHtml += `<span class="fp-tag">${esc(ft.forma)}<b>${ft.total}</b></span>`;
        });
        fBar.innerHTML = fHtml;
    }
  }

  // --- MOTOR DE SINCRONIZAÇÃO ATÔMICA ULTRA-FAST ---
  // Reduzido para 2 segundos para sensação de tempo real instantâneo
  setInterval(syncAtomic, 2000);

  // Toggle Itens na Tabela (Clique Simples)
  window.toggleItems = function(id) {
      const row = document.getElementById('items-' + id);
      if(row) {
          row.style.display = (row.style.display === 'none' || row.style.display === '') ? 'table-row' : 'none';
      }
  };

  // Duplo Clique na linha -> Abre Modal Elite
  document.querySelectorAll('.sale-row').forEach(function(row) {
      row.addEventListener('dblclick', function(e) {
          e.preventDefault();
          abrirDetalhe(this.dataset.id);
      });
  });

  // Controle do Modal
  document.getElementById('js-modal-fechar').addEventListener('click', fecharModal);
  document.getElementById('js-modal').addEventListener('click', function (e) {
    if (e.target === this) fecharModal();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') fecharModal();
  });

  function fecharModal() {
    document.getElementById('js-modal').classList.remove('aberto');
  }

  function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function abrirDetalhe(id) {
    var modal = document.getElementById('js-modal');
    var body  = document.getElementById('js-modal-body');
    document.getElementById('js-modal-titulo').textContent = 'Venda Elite #' + id;
    body.innerHTML = '<div style="text-align:center; padding:3rem; color:#64748b;">Buscando inteligência de dados...</div>';
    modal.classList.add('aberto');

    fetch('?det=' + encodeURIComponent(id))
      .then(function (r) { return r.json(); })
      .then(function (d) { renderDetalhe(body, d); })
      .catch(function () { body.innerHTML = '<div style="color:#ef4444; text-align:center; padding:2rem;">Erro ao carregar dados do servidor.</div>'; });
  }

  function renderDetalhe(body, d) {
    if (!d.ok || !d.venda) {
      body.innerHTML = '<div style="color:#ef4444; text-align:center; padding:2rem;">' + esc(d.erro || 'Venda não encontrada.') + '</div>';
      return;
    }
    var v = d.venda;
    
    // Dashboard Financeiro Moderno
    var html = '<div class="det-grid">';
    html += '<div class="det-item"><label>Cliente</label><span>' + esc(v.cliente) + '</span></div>';
    html += '<div class="det-item"><label>Data / Hora</label><span>' + esc(v.data) + (v.hora ? ' às ' + esc(v.hora) : '') + '</span></div>';
    html += '<div class="det-item"><label>Operador</label><span>' + esc(v.usuario) + '</span></div>';
    html += '<div class="det-item"><label>Status Atual</label><span style="color:#3b82f6;">' + esc(v.status) + '</span></div>';
    html += '</div>';

    html += '<div class="det-financeiro">';
    if (v.subtotal && v.subtotal !== 'R$ 0,00') html += '<div class="det-fin-row"><span>Subtotal Bruto</span><span>' + esc(v.subtotal) + '</span></div>';
    if (v.desconto && v.desconto !== 'R$ 0,00') html += '<div class="det-fin-row" style="color:#ef4444;"><span>Descontos Aplicados</span><span>- ' + esc(v.desconto) + '</span></div>';
    if (v.acrescimo && v.acrescimo !== 'R$ 0,00') html += '<div class="det-fin-row"><span>Acréscimos</span><span>+ ' + esc(v.acrescimo) + '</span></div>';
    if (v.taxa && v.taxa !== 'R$ 0,00') html += '<div class="det-fin-row"><span>Taxa de Entrega / Serviço</span><span>+ ' + esc(v.taxa) + '</span></div>';
    
    html += '<div class="det-fin-total"><span>TOTAL LIQUIDADO</span><span style="color:#3b82f6;">' + esc(v.total) + '</span></div>';
    if (v.troco && v.troco !== 'R$ 0,00') html += '<div class="det-fin-row" style="margin-top:0.5rem; font-size:0.875rem; color:#64748b;"><span>Troco Devolvido</span><span>' + esc(v.troco) + '</span></div>';
    html += '</div>';

    if (v.pagamentos && v.pagamentos.length) {
      html += '<div style="margin-bottom:2rem;"><h3 style="font-size:0.875rem; color:#64748b; text-transform:uppercase; margin-bottom:1rem;">Histórico de Pagamentos</h3>';
      v.pagamentos.forEach(function (p) {
        html += '<div style="display:flex; justify-content:space-between; padding:0.75rem; background:#f8fafc; border:1px solid #e2e8f0; border-radius:0.5rem; margin-bottom:0.5rem;"><span style="font-weight:600;">' + esc(p.forma) + '</span><b style="color:#10b981;">' + esc(p.valor) + '</b></div>';
      });
      html += '</div>';
    }

    if (d.itens && d.itens.length) {
      html += '<div><h3 style="font-size:0.875rem; color:#64748b; text-transform:uppercase; margin-bottom:1rem;">Itens da Transação</h3><table class="item-table" style="box-shadow:none; border:1px solid #e2e8f0;">';
	      html += '<thead><tr><th>Produto</th><th style="text-align:right;">Qtd</th><th style="text-align:right;">Unit.</th><th style="text-align:right;">Subtotal</th></tr></thead><tbody>';
	      d.itens.forEach(function (it) {
	        html += '<tr><td style="font-weight:600;">' + esc(it.produto) + '</td><td style="text-align:right;">' + esc(it.qtd) + '</td><td style="text-align:right;">' + esc(it.unit) + '</td><td style="text-align:right; font-weight:700; color:#3b82f6;">' + esc(it.subtotal) + '</td></tr>';
	      });
      html += '</tbody></table></div>';
    } else {
      html += '<div style="padding:1rem; background:#f8fafc; border-radius:0.5rem; text-align:center; color:#64748b;">Nenhum item registrado nesta transação.</div>';
    }

    body.innerHTML = html;
  }
})();
</script>
</body>
</html>
