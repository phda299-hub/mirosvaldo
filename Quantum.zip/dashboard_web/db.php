<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

/** Conexão PDO única (singleton) com o MySQL da hospedagem. */
function q_pdo() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES ' . DB_CHARSET,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        die('Falha ao conectar no banco de dados. Verifique os dados em config.php.');
    }
    return $pdo;
}

/** Verifica se uma tabela existe no banco atual. */
function q_table_exists($pdo, $table) {
    $st = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1");
    $st->execute([DB_NAME, $table]);
    return (bool)$st->fetch();
}

/** Lista as colunas existentes de uma tabela (em minúsculas). */
function q_table_columns($pdo, $table) {
    $st = $pdo->prepare("SELECT column_name FROM information_schema.columns WHERE table_schema = ? AND table_name = ?");
    $st->execute([DB_NAME, $table]);
    $cols = [];
    foreach ($st->fetchAll() as $r) {
        $cols[strtolower($r['column_name'])] = true;
    }
    return $cols;
}
