<?php
require_once __DIR__ . '/auth.php';
$user = q_require_login();
$pdo = q_pdo();

$ehAjax = isset($_GET['ajax']);

$existeProdutos = q_table_exists($pdo, 'produtos');
$cols = $existeProdutos ? q_table_columns($pdo, 'produtos') : [];
$temEstoque = isset($cols['estoque']) && isset($cols['estoque_minimo']);
$catJoin = isset($cols['categoria_id']) && q_table_exists($pdo, 'categorias');

$catBase = isset($cols['categoria']) ? 'p.`categoria`' : "''";
$catExpr = $catJoin ? "COALESCE(NULLIF($catBase,''), c.`nome`, '')" : $catBase;
$fromSql = 'FROM produtos p' . ($catJoin ? ' LEFT JOIN categorias c ON c.`id` = p.`categoria_id`' : '');

// Mapeamento FIEL ao Quantum: o "Valor de venda" fica na coluna `preco` e o
// "Valor de compra" em `preco_compra` (as colunas preco_venda/preco_custo
// normalmente ficam zeradas). Usamos COALESCE para pegar o primeiro valor
// diferente de zero, mantendo retrocompatibilidade com bancos antigos.
function valexpr($cols, $cands) {
    $parts = [];
    foreach ($cands as $c) {
        if (isset($cols[strtolower($c)])) { $parts[] = "NULLIF(p.`$c`,0)"; }
    }
    return $parts ? ('COALESCE(' . implode(',', $parts) . ',0)') : '0';
}
$vendaExpr = valexpr($cols, ['preco', 'preco_venda']);
$custoExpr = valexpr($cols, ['preco_compra', 'preco_custo']);

// ---------- Filtros ----------
$f = [
    'q'        => trim($_GET['q'] ?? ''),
    'nome'     => trim($_GET['f_nome'] ?? ''),
    'emin'     => trim($_GET['f_emin'] ?? ''),
    'emest'    => $_GET['f_emest'] ?? '',
    'custo'    => trim($_GET['f_custo'] ?? ''),
    'venda'    => trim($_GET['f_venda'] ?? ''),
    'margem'   => $_GET['f_margem'] ?? '',
    'grupo'    => trim($_GET['f_grupo'] ?? ''),
    'inativos' => isset($_GET['inativos']),
];
$abaixo = isset($_GET['abaixo']);
$pg = max(1, (int)($_GET['pg'] ?? 1));
$porPagina = 200;
if (isset($_GET['print'])) { $pg = 1; $porPagina = 100000; } // relatório: todos os filtrados

function pcol($cols, $name, $default) {
    return isset($cols[strtolower($name)]) ? ('p.`' . $name . '`') : $default;
}

/** WHERE base: ativo + busca textual + filtros do painel (sem "abaixo do mínimo"). */
function montar_busca($cols, $catJoin, $catExpr, $vendaExpr, $custoExpr, $f, &$params) {
    $w = [];
    if (isset($cols['ativo']) && !$f['inativos']) {
        $w[] = '(p.`ativo` = 1 OR p.`ativo` IS NULL)';
    }
    if ($f['q'] !== '') {
        $campos = [];
        foreach (['codigo_barras', 'nome', 'categoria', 'codigo'] as $c) {
            if (isset($cols[$c])) { $campos[] = "p.`$c` LIKE ?"; }
        }
        if ($catJoin) { $campos[] = "c.`nome` LIKE ?"; }
        if ($campos) {
            $w[] = '(' . implode(' OR ', $campos) . ')';
            foreach ($campos as $_) { $params[] = '%' . $f['q'] . '%'; }
        }
    }
    if ($f['nome'] !== '' && isset($cols['nome']))           { $w[] = 'p.`nome` = ?';            $params[] = $f['nome']; }
    if ($f['emin'] !== '' && isset($cols['estoque_minimo'])) { $w[] = 'p.`estoque_minimo` = ?';  $params[] = $f['emin']; }
    if ($f['custo'] !== '') { $w[] = "$custoExpr = ?"; $params[] = $f['custo']; }
    if ($f['venda'] !== '') { $w[] = "$vendaExpr = ?"; $params[] = $f['venda']; }
    if ($f['grupo'] !== '')                                   { $w[] = "$catExpr = ?";           $params[] = $f['grupo']; }
    if ($f['emest'] === 'com' && isset($cols['estoque']))     { $w[] = 'p.`estoque` > 0'; }
    if ($f['emest'] === 'sem' && isset($cols['estoque']))     { $w[] = 'p.`estoque` <= 0'; }
    if ($f['margem'] !== '') {
        $m = "(($vendaExpr - $custoExpr) / $custoExpr * 100)";
        switch ($f['margem']) {
            case 'neg':    $w[] = "($custoExpr > 0 AND $vendaExpr < $custoExpr)"; break;
            case '0_20':   $w[] = "($custoExpr > 0 AND $m >= 0 AND $m <= 20)"; break;
            case '20_50':  $w[] = "($custoExpr > 0 AND $m > 20 AND $m <= 50)"; break;
            case '50_100': $w[] = "($custoExpr > 0 AND $m > 50 AND $m <= 100)"; break;
            case '100_':   $w[] = "($custoExpr > 0 AND $m > 100)"; break;
        }
    }
    return $w;
}

$resumo = ['total' => 0, 'baixo' => 0, 'minimo' => 0, 'acima' => 0];
$rows = [];
$totalFiltrado = 0;
$totalPaginas = 1;
$erro_tabela = $existeProdutos ? '' : 'A tabela "produtos" ainda não existe no banco. Faça a sincronização no sistema Quantum (Envio mysql externo).';

if ($existeProdutos) {
    // Resumo (respeita busca + painel; sem "abaixo do mínimo")
    $pR = [];
    $wR = montar_busca($cols, $catJoin, $catExpr, $vendaExpr, $custoExpr, $f, $pR);
    $wsR = $wR ? (' WHERE ' . implode(' AND ', $wR)) : '';
    if ($temEstoque) {
        $sqlR = "SELECT COUNT(*) total,
            SUM(CASE WHEN p.`estoque` < p.`estoque_minimo` THEN 1 ELSE 0 END) baixo,
            SUM(CASE WHEN p.`estoque` = p.`estoque_minimo` THEN 1 ELSE 0 END) minimo,
            SUM(CASE WHEN p.`estoque` > p.`estoque_minimo` THEN 1 ELSE 0 END) acima
            $fromSql$wsR";
    } else {
        $sqlR = "SELECT COUNT(*) total, 0 baixo, 0 minimo, 0 acima $fromSql$wsR";
    }
    $stR = $pdo->prepare($sqlR);
    $stR->execute($pR);
    if ($rr = $stR->fetch()) {
        $resumo = ['total'=>(int)$rr['total'], 'baixo'=>(int)$rr['baixo'], 'minimo'=>(int)$rr['minimo'], 'acima'=>(int)$rr['acima']];
    }

    // Lista (acrescenta "abaixo do mínimo")
    $params = [];
    $where = montar_busca($cols, $catJoin, $catExpr, $vendaExpr, $custoExpr, $f, $params);
    if ($abaixo && $temEstoque) { $where[] = 'p.`estoque` < p.`estoque_minimo`'; }
    $whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

    $stC = $pdo->prepare("SELECT COUNT(*) n $fromSql$whereSql");
    $stC->execute($params);
    $totalFiltrado = (int)($stC->fetch()['n'] ?? 0);
    $totalPaginas = max(1, (int)ceil($totalFiltrado / $porPagina));
    if ($pg > $totalPaginas) { $pg = $totalPaginas; }
    $offset = ($pg - 1) * $porPagina;

    $ordem = isset($cols['nome']) ? 'p.`nome`' : '1';
    $sql = "SELECT
        " . pcol($cols,'id',"''") . " pid,
        " . pcol($cols,'codigo_barras',"''") . " cb,
        " . pcol($cols,'nome',"''") . " nome,
        $catExpr categoria,
        $custoExpr preco_custo,
        $vendaExpr preco_venda,
        " . pcol($cols,'estoque_minimo','0') . " estoque_minimo,
        " . pcol($cols,'estoque','0') . " estoque
        $fromSql$whereSql ORDER BY $ordem ASC LIMIT $porPagina OFFSET $offset";
    $stL = $pdo->prepare($sql);
    $stL->execute($params);
    $rows = $stL->fetchAll();
}

function fmt_row($r, $temEstoque) {
    $margem = q_margem($r['preco_custo'], $r['preco_venda']);
    $id = (string)$r['pid'];
    if ($id === '') { $id = ((string)$r['cb'] !== '') ? (string)$r['cb'] : (string)$r['nome']; }
    return [
        'id'     => $id,
        'cb'     => (string)$r['cb'],
        'nome'   => (string)$r['nome'],
        'cat'    => (string)$r['categoria'],
        'custo'  => q_money($r['preco_custo']),
        'margem' => $margem === null ? '—' : number_format($margem, 1, ',', '.') . '%',
        'venda'  => q_money($r['preco_venda']),
        'emin'   => q_qtd($r['estoque_minimo']),
        'est'    => q_qtd($r['estoque']),
        'sit'    => $temEstoque ? q_stock_label($r['estoque'], $r['estoque_minimo']) : '—',
        'cls'    => $temEstoque ? q_stock_class($r['estoque'], $r['estoque_minimo']) : '',
        'nc'     => round(q_num($r['preco_custo']), 2),
        'nv'     => round(q_num($r['preco_venda']), 2),
        'ne'     => round(q_num($r['estoque']), 3),
    ];
}
$linhas = array_map(function ($r) use ($temEstoque) { return fmt_row($r, $temEstoque); }, $rows);

// ---------- Resposta AJAX (tempo real) ----------
if ($ehAjax) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'ok'=>$erro_tabela==='', 'erro'=>$erro_tabela, 'hora'=>date('H:i:s'),
        'resumo'=>$resumo, 'total'=>$totalFiltrado, 'paginas'=>$totalPaginas,
        'pg'=>$pg, 'temEstoque'=>$temEstoque, 'rows'=>$linhas,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- Listas para os dropdowns ----------
function distinct_vals($pdo, $selCol, $orderExpr, $whereSql) {
    try {
        $st = $pdo->query("SELECT DISTINCT $selCol v FROM produtos p$whereSql ORDER BY $orderExpr LIMIT 5000");
        $out = [];
        foreach ($st->fetchAll() as $r) {
            if ($r['v'] === null) { continue; }
            $out[] = $r['v'];
        }
        return $out;
    } catch (Exception $e) { return []; }
}

$nomes = $emins = $custos = $vendas = $grupos = [];
if ($existeProdutos) {
    $ativoSql = (isset($cols['ativo']) && !$f['inativos']) ? ' WHERE (p.`ativo` = 1 OR p.`ativo` IS NULL)' : '';
    if (isset($cols['nome']))           { $nomes  = distinct_vals($pdo, 'p.`nome`', 'p.`nome`', $ativoSql); }
    if (isset($cols['estoque_minimo'])) { $emins  = distinct_vals($pdo, 'p.`estoque_minimo`', 'p.`estoque_minimo`+0', $ativoSql); }
    if (isset($cols['preco_custo']) || isset($cols['preco_compra'])) { $custos = distinct_vals($pdo, $custoExpr, "$custoExpr+0", $ativoSql); }
    if (isset($cols['preco_venda']) || isset($cols['preco']))        { $vendas = distinct_vals($pdo, $vendaExpr, "$vendaExpr+0", $ativoSql); }
    if ($catJoin) {
        try {
            $st = $pdo->query("SELECT `nome` v FROM categorias WHERE `nome` <> '' ORDER BY `nome` LIMIT 5000");
            foreach ($st->fetchAll() as $r) { $grupos[] = $r['v']; }
        } catch (Exception $e) {}
    } elseif (isset($cols['categoria'])) {
        foreach (distinct_vals($pdo, 'p.`categoria`', 'p.`categoria`', $ativoSql) as $g) {
            if (trim((string)$g) !== '') { $grupos[] = $g; }
        }
    }
}

$margemOpts = ['' => '%  (todas)', 'neg' => 'Prejuízo (< 0%)', '0_20' => '0% a 20%', '20_50' => '20% a 50%', '50_100' => '50% a 100%', '100_' => 'Acima de 100%'];
$emestOpts  = ['' => 'Todos', 'com' => 'Com estoque', 'sem' => 'Sem estoque'];

function urlcom($overrides) {
    $base = [
        'q' => $_GET['q'] ?? '', 'f_nome' => $_GET['f_nome'] ?? '', 'f_emin' => $_GET['f_emin'] ?? '',
        'f_emest' => $_GET['f_emest'] ?? '', 'f_custo' => $_GET['f_custo'] ?? '', 'f_venda' => $_GET['f_venda'] ?? '',
        'f_margem' => $_GET['f_margem'] ?? '', 'f_grupo' => $_GET['f_grupo'] ?? '',
    ];
    if (isset($_GET['abaixo']))   { $base['abaixo'] = '1'; }
    if (isset($_GET['inativos'])) { $base['inativos'] = '1'; }
    return 'produtos.php?' . http_build_query(array_merge($base, $overrides));
}
$temFiltro = $f['q']!=='' || $f['nome']!=='' || $f['emin']!=='' || $f['emest']!=='' || $f['custo']!=='' || $f['venda']!=='' || $f['margem']!=='' || $f['grupo']!=='' || $abaixo || $f['inativos'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Produtos e Estoque • <?= h(APP_NOME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body class="tela-produtos">
<header class="topbar">
  <div class="brand"><a href="index.php" class="voltar">‹ Painel</a> <span class="brand-txt">📦 Produtos e Estoque</span></div>
  <div class="userbox">
    <span class="user-nome"><?= h($user['nome']) ?></span>
    <a class="btn-sair" href="logout.php">Sair</a>
  </div>
</header>

<main class="wrap">
<?php if ($erro_tabela): ?>
  <div class="alert alert-info"><?= h($erro_tabela) ?></div>
<?php else: ?>

  <form class="painel" method="get">
    <div class="painel-head">▼ Filtros de Pesquisa</div>
    <div class="painel-body">
      <input class="busca" type="text" name="q" value="<?= h($f['q']) ?>" placeholder="🔎 Buscar por código de barras, nome ou categoria...">
      <div class="grid-filtros">

        <div class="campo">
          <label>Nome</label>
          <select name="f_nome">
            <option value="">Todos</option>
            <?php foreach ($nomes as $v): ?>
              <option value="<?= h($v) ?>" <?= $f['nome']===(string)$v?'selected':'' ?>><?= h($v) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Estoque Mínimo</label>
          <select name="f_emin">
            <option value="">Todos</option>
            <?php foreach ($emins as $v): ?>
              <option value="<?= h($v) ?>" <?= $f['emin']===(string)$v?'selected':'' ?>><?= h(q_qtd($v)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Em Estoque</label>
          <select name="f_emest">
            <?php foreach ($emestOpts as $k => $lbl): ?>
              <option value="<?= h($k) ?>" <?= $f['emest']===$k?'selected':'' ?>><?= h($lbl) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Preço de Custo</label>
          <select name="f_custo">
            <option value="">Todos</option>
            <?php foreach ($custos as $v): ?>
              <option value="<?= h($v) ?>" <?= $f['custo']===(string)$v?'selected':'' ?>><?= h(q_money($v)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Preço de Venda</label>
          <select name="f_venda">
            <option value="">Todos</option>
            <?php foreach ($vendas as $v): ?>
              <option value="<?= h($v) ?>" <?= $f['venda']===(string)$v?'selected':'' ?>><?= h(q_money($v)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Margem</label>
          <select name="f_margem">
            <?php foreach ($margemOpts as $k => $lbl): ?>
              <option value="<?= h($k) ?>" <?= $f['margem']===$k?'selected':'' ?>><?= h($lbl) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo">
          <label>Grupo</label>
          <select name="f_grupo">
            <option value="">Todos</option>
            <?php foreach ($grupos as $v): ?>
              <option value="<?= h($v) ?>" <?= $f['grupo']===(string)$v?'selected':'' ?>><?= h($v) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="campo campo-checks">
          <label class="chk"><input type="checkbox" name="abaixo" value="1" <?= $abaixo?'checked':'' ?>> Abaixo do estoque mínimo</label>
          <label class="chk"><input type="checkbox" name="inativos" value="1" <?= $f['inativos']?'checked':'' ?>> Incluir inativos</label>
        </div>
      </div>
      <div class="painel-acoes">
        <button type="submit">Pesquisar</button>
        <?php if ($temFiltro): ?><a class="limpar" href="produtos.php">Limpar filtros</a><?php endif; ?>
      </div>
    </div>
  </form>

  <div class="barra-live">
    <button type="button" id="btnLive" class="btn-live"><span class="dot"></span> <span id="liveTxt">Ao vivo</span></button>
    <button type="button" id="btnImprimir" class="btn-print">🖨️ Imprimir relatório</button>
    <span class="live-info">Atualizado às <b id="hora"><?= date('H:i:s') ?></b></span>
    <span class="live-info live-hint">As alterações sobem para o topo e destacam por instantes.</span>
  </div>

  <div class="modal-overlay" id="modalPrint" aria-hidden="true">
    <div class="modal-card" role="dialog" aria-modal="true" aria-label="Formato de impressão">
      <div class="modal-head">🖨️ Imprimir relatório</div>
      <div class="modal-body">
        <p>Escolha o formato do relatório:</p>
        <div class="formatos">
          <button type="button" class="fmt" data-fmt="a4"><span class="fmt-ic">📄</span><b>A4</b><small>Folha / PDF</small></button>
          <button type="button" class="fmt" data-fmt="80"><span class="fmt-ic">🧾</span><b>80&nbsp;mm</b><small>Bobina térmica</small></button>
          <button type="button" class="fmt" data-fmt="58"><span class="fmt-ic">🧾</span><b>58&nbsp;mm</b><small>Bobina pequena</small></button>
        </div>
      </div>
      <div class="modal-foot"><button type="button" class="btn-cancelar" id="btnCancelarPrint">Cancelar</button></div>
    </div>
  </div>

  <div class="resumo" id="resumo">
    <span class="chip chip-total"><b id="c-total"><?= number_format($resumo['total'],0,',','.') ?></b> produtos</span>
    <span class="chip chip-baixo"><b id="c-baixo"><?= number_format($resumo['baixo'],0,',','.') ?></b> abaixo do mínimo</span>
    <span class="chip chip-minimo"><b id="c-minimo"><?= number_format($resumo['minimo'],0,',','.') ?></b> no mínimo</span>
    <span class="chip chip-acima"><b id="c-acima"><?= number_format($resumo['acima'],0,',','.') ?></b> acima do mínimo</span>
  </div>

  <div class="legenda">
    <span><i class="sw st-baixo"></i> abaixo do mínimo</span>
    <span><i class="sw st-minimo"></i> no mínimo</span>
    <span><i class="sw st-acima"></i> acima do mínimo</span>
  </div>

  <div class="tabela-wrap">
  <table class="grid">
    <thead><tr>
      <th>Código de barras</th><th>Produto</th><th>Categoria</th>
      <th class="num">Valor de compra</th><th class="num">Margem</th><th class="num">Valor de venda</th>
      <th class="num">Estoque mín.</th><th class="num">Estoque</th><th>Situação</th>
    </tr></thead>
    <tbody id="tbody">
      <?php if (!$linhas): ?>
        <tr><td colspan="9" class="vazio">Nenhum produto encontrado.</td></tr>
      <?php else: foreach ($linhas as $l): ?>
        <tr class="<?= h($l['cls']) ?>">
          <td data-l="Código de barras" class="mono"><?= h($l['cb']) ?></td>
          <td data-l="Produto"><?= h($l['nome']) ?></td>
          <td data-l="Categoria"><?= h($l['cat']) ?></td>
          <td data-l="Valor de compra" class="num"><?= h($l['custo']) ?></td>
          <td data-l="Margem" class="num"><?= h($l['margem']) ?></td>
          <td data-l="Valor de venda" class="num"><?= h($l['venda']) ?></td>
          <td data-l="Estoque mín." class="num"><?= h($l['emin']) ?></td>
          <td data-l="Estoque" class="num"><b><?= h($l['est']) ?></b></td>
          <td data-l="Situação"><?= h($l['sit']) ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>

  <?php if ($totalPaginas > 1): ?>
  <div class="paginacao">
    <?php if ($pg > 1): ?><a href="<?= h(urlcom(['pg'=>$pg-1])) ?>">‹ Anterior</a><?php endif; ?>
    <span>Página <?= $pg ?> de <?= $totalPaginas ?> (<?= number_format($totalFiltrado,0,',','.') ?> registros)</span>
    <?php if ($pg < $totalPaginas): ?><a href="<?= h(urlcom(['pg'=>$pg+1])) ?>">Próxima ›</a><?php endif; ?>
  </div>
  <?php endif; ?>

<script>
(function(){
  var INTERVALO = 4000;
  var CICLOS_TOPO = 2; // a linha alterada sobe e fica no topo por 2 atualizacoes
  var ativo = localStorage.getItem('q_live') !== 'off';
  var timer = null, primeira = true;
  var prev = {}, pin = {};
  var btn = document.getElementById('btnLive'), liveTxt = document.getElementById('liveTxt');
  var tbody = document.getElementById('tbody'), hora = document.getElementById('hora');

  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function sig(r){ return [r.est,r.emin,r.custo,r.venda,r.nome,r.cat,r.cls,r.sit].join('|'); }

  function pintarBotao(){
    if(ativo){ btn.classList.add('on'); btn.classList.remove('off'); liveTxt.textContent='Ao vivo'; }
    else { btn.classList.add('off'); btn.classList.remove('on'); liveTxt.textContent='Pausado'; }
  }
  function setTxt(id,v){ var e=document.getElementById(id); if(e) e.textContent=v; }

  function montaLinha(r, flash){
    var cls = (r.cls||'') + (r._pin?' pinned':'') + (flash?' flash':'');
    var tr = '<tr class="'+cls.trim()+'">';
    tr += '<td data-l="Código de barras" class="mono">'+esc(r.cb)+'</td>';
    tr += '<td data-l="Produto">'+esc(r.nome)+'</td>';
    tr += '<td data-l="Categoria">'+esc(r.cat)+'</td>';
    tr += '<td data-l="Valor de compra" class="num">'+esc(r.custo)+'</td>';
    tr += '<td data-l="Margem" class="num">'+esc(r.margem)+'</td>';
    tr += '<td data-l="Valor de venda" class="num">'+esc(r.venda)+'</td>';
    tr += '<td data-l="Estoque mín." class="num">'+esc(r.emin)+'</td>';
    tr += '<td data-l="Estoque" class="num"><b>'+esc(r.est)+'</b></td>';
    tr += '<td data-l="Situação">'+esc(r.sit)+'</td></tr>';
    return tr;
  }

  function aplicar(j){
    if(!j || !j.ok) return;
    var rows = j.rows || [];
    var mudouAgora = {};
    if(!primeira){
      rows.forEach(function(r){
        var s = sig(r);
        if(prev[r.id] !== undefined && prev[r.id] !== s){
          pin[r.id] = CICLOS_TOPO;   // marca para subir ao topo
          mudouAgora[r.id] = true;
        }
      });
    }
    // assinatura para o proximo ciclo
    var novoPrev = {}; rows.forEach(function(r){ novoPrev[r.id] = sig(r); });
    // aplica pino e separa topo x normal
    rows.forEach(function(r){ r._pin = pin[r.id] || 0; });
    var topo = rows.filter(function(r){ return r._pin>0; });
    var normal = rows.filter(function(r){ return !r._pin; });
    topo.sort(function(a,b){ return b._pin - a._pin; }); // mais recentes primeiro
    var ordenado = topo.concat(normal);

    var html = '';
    if(ordenado.length===0){ html = '<tr><td colspan="9" class="vazio">Nenhum produto encontrado.</td></tr>'; }
    else { ordenado.forEach(function(r){ html += montaLinha(r, !!mudouAgora[r.id]); }); }
    tbody.innerHTML = html; // troca atomica

    setTxt('c-total',  Number(j.resumo.total ).toLocaleString('pt-BR'));
    setTxt('c-baixo',  Number(j.resumo.baixo ).toLocaleString('pt-BR'));
    setTxt('c-minimo', Number(j.resumo.minimo).toLocaleString('pt-BR'));
    setTxt('c-acima',  Number(j.resumo.acima ).toLocaleString('pt-BR'));
    if(hora) hora.textContent = j.hora;

    // decrementa os ciclos; ao zerar, a linha volta para a ordem normal
    Object.keys(pin).forEach(function(id){ pin[id]--; if(pin[id]<=0) delete pin[id]; });
    prev = novoPrev; primeira = false;
  }

  function url(){ var u = new URL(window.location.href); u.searchParams.set('ajax','1'); return u.toString(); }
  function atualizar(){
    if(!ativo) return;
    fetch(url(), {headers:{'X-Requested-With':'fetch'}, cache:'no-store'})
      .then(function(r){ return r.json(); }).then(aplicar).catch(function(){});
  }
  function loop(){ if(timer) clearInterval(timer); if(ativo){ timer=setInterval(atualizar, INTERVALO); atualizar(); } }

  btn.addEventListener('click', function(){
    ativo=!ativo; localStorage.setItem('q_live', ativo?'on':'off'); pintarBotao(); loop();
  });
  pintarBotao(); loop();
  document.addEventListener('visibilitychange', function(){
    if(document.hidden){ if(timer) clearInterval(timer); } else { loop(); }
  });
})();
</script>

<script>
/* ============ Impressão de relatório profissional (A4 / 80mm / 58mm) ============ */
(function(){
  var Q_APP  = <?= json_encode(APP_NOME, JSON_UNESCAPED_UNICODE) ?>;
  var Q_USER = <?= json_encode($user['nome'], JSON_UNESCAPED_UNICODE) ?>;
  var modal = document.getElementById('modalPrint');
  var btn   = document.getElementById('btnImprimir');
  var btnCancel = document.getElementById('btnCancelarPrint');

  function abrir(){ modal.classList.add('aberto'); modal.setAttribute('aria-hidden','false'); }
  function fechar(){ modal.classList.remove('aberto'); modal.setAttribute('aria-hidden','true'); }
  if(btn) btn.addEventListener('click', abrir);
  if(btnCancel) btnCancel.addEventListener('click', fechar);
  modal.addEventListener('click', function(e){ if(e.target===modal) fechar(); });
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') fechar(); });
  Array.prototype.forEach.call(modal.querySelectorAll('.fmt'), function(b){
    b.addEventListener('click', function(){ var f=b.getAttribute('data-fmt'); fechar(); imprimir(f); });
  });

  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function brl(n){ n=Number(n)||0; return 'R$ '+n.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
  function intBR(n){ return Number(n||0).toLocaleString('pt-BR'); }
  function qtd(n){ n=Number(n)||0; return (Math.abs(n-Math.round(n))<0.0005)? intBR(n) : n.toLocaleString('pt-BR',{maximumFractionDigits:3}); }
  function agora(){ var d=new Date(),p=function(x){return(x<10?'0':'')+x;};
      return p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear()+' '+p(d.getHours())+':'+p(d.getMinutes()); }
  function cor(cls){ return cls==='st-baixo'?'#dc2626':(cls==='st-minimo'?'#d97706':(cls==='st-acima'?'#2563eb':'#94a3b8')); }
  function monograma(){ var s=(Q_APP||'Q').replace(/[^A-Za-zÀ-ÿ ]/g,'').trim().split(/\s+/);
      return ((s[0]?s[0][0]:'Q')+(s[1]?s[1][0]:'P')).toUpperCase(); }

  function coletaFiltros(){
    var arr=[]; var q=document.querySelector('input[name=q]');
    if(q&&q.value.trim()) arr.push(['Busca', q.value.trim()]);
    function sel(name,label){ var s=document.querySelector('select[name='+name+']');
      if(s&&s.value!=='') arr.push([label, s.options[s.selectedIndex].text.trim()]); }
    sel('f_nome','Nome'); sel('f_emin','Estoque mínimo'); sel('f_emest','Em estoque');
    sel('f_custo','Preço de custo'); sel('f_venda','Preço de venda'); sel('f_margem','Margem'); sel('f_grupo','Grupo');
    var ab=document.querySelector('input[name=abaixo]'); if(ab&&ab.checked) arr.push(['Situação','Abaixo do estoque mínimo']);
    var inv=document.querySelector('input[name=inativos]'); if(inv&&inv.checked) arr.push(['Incluir','Inativos']);
    return arr;
  }

  function totais(rows){
    var t={itens:rows.length,est:0,custo:0,venda:0};
    rows.forEach(function(x){ var e=Number(x.ne)||0; t.est+=e; t.custo+=(Number(x.nc)||0)*e; t.venda+=(Number(x.nv)||0)*e; });
    t.lucro=t.venda-t.custo; return t;
  }

  function cssBase(fmt){
    var pageA4='@page{size:A4 portrait;margin:12mm}';
    var page80='@page{size:80mm auto;margin:3mm}';
    var page58='@page{size:58mm auto;margin:2mm}';
    var page = fmt==='a4'?pageA4:(fmt==='80'?page80:page58);
    var comum='*{box-sizing:border-box}html,body{margin:0;padding:0;color:#0f172a;'
      +'font-family:\'Segoe UI\',Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}'+page;
    if(fmt==='a4'){
      return comum+
      '.doc{font-size:12px}'+
      '.rep-head{display:flex;align-items:center;gap:14px;border-bottom:3px solid #2563eb;padding-bottom:12px}'+
      '.rep-logo{width:54px;height:54px;border-radius:12px;background:linear-gradient(135deg,#1e3a8a,#2563eb);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:22px;letter-spacing:1px}'+
      '.rep-id{flex:1}.rep-app{font-size:18px;font-weight:800;color:#1e293b}'+
      '.rep-sub{font-size:12px;color:#475569;font-weight:700;text-transform:uppercase;letter-spacing:.08em}'+
      '.rep-meta{font-size:11px;color:#475569;text-align:right;line-height:1.55}.rep-meta b{color:#0f172a}'+
      '.sec-tit{margin:16px 0 6px;font-size:11px;font-weight:800;color:#1e293b;text-transform:uppercase;letter-spacing:.06em;border-left:4px solid #2563eb;padding-left:8px}'+
      '.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}'+
      '.kpi{border:1px solid #e2e8f0;border-radius:10px;padding:9px 10px;background:#f8fafc}'+
      '.kpi span{display:block;font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:.04em}.kpi b{font-size:14px}'+
      '.kpi-c{background:#eef2ff}.kpi-v{background:#ecfdf5}.kpi-l{background:#fff7ed}'+
      '.status-line{display:flex;gap:8px;margin-top:8px;font-size:11px}'+
      '.badge{padding:2px 9px;border-radius:20px;border:1px solid #e2e8f0}'+
      '.b-baixo{background:#fde2e1;border-color:#f5b5b2}.b-min{background:#fff4cc;border-color:#f2dd8c}.b-acima{background:#e3edff;border-color:#b9d0fb}'+
      '.filtros-box{margin-top:8px;font-size:11px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;padding:8px 10px;color:#334155}'+
      'table{width:100%;border-collapse:collapse;margin-top:6px;font-size:11px}'+
      'thead th{background:#1e293b;color:#fff;padding:7px 8px;text-align:left;font-size:10px;text-transform:uppercase}'+
      'tbody td{padding:6px 8px;border-bottom:1px solid #e5e7eb}tbody tr:nth-child(even){background:#f8fafc}'+
      'td.num,th.num{text-align:right}.mono{font-family:Consolas,monospace}'+
      '.dt{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}'+
      'tfoot td{padding:8px;border-top:2px solid #1e293b;font-weight:800;background:#f1f5f9}'+
      '.rep-foot{margin-top:14px;border-top:1px solid #e2e8f0;padding-top:8px;font-size:10px;color:#64748b;text-align:center}';
    }
    // térmico (80/58)
    var fs = fmt==='80'?'11px':'10px';
    var w  = fmt==='80'?'74mm':'54mm';
    return comum+
      'body{width:'+w+';font-size:'+fs+'}'+
      '.c{text-align:center}.b{font-weight:800}'+
      '.app{font-weight:800;font-size:'+(fmt==='80'?'14px':'12px')+'}'+
      '.sub{font-size:'+(fmt==='80'?'11px':'10px')+';text-transform:uppercase;letter-spacing:.04em}'+
      '.meta{font-size:9px;color:#222;line-height:1.5;margin-top:2px}'+
      '.hr{border-top:1px dashed #000;margin:6px 0}'+
      '.row{display:flex;justify-content:space-between;gap:6px;font-size:'+(fmt==='80'?'10px':'9px')+'}'+
      '.it{margin:5px 0}.it .nm{font-weight:700}'+
      '.dt{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:4px}'+
      '.tot{font-weight:800;font-size:'+(fmt==='80'?'11px':'10px')+'}'+
      '.foot{margin-top:8px;font-size:8.5px;color:#444;text-align:center}';
  }

  function relA4(j){
    var rows=j.rows||[], r=j.resumo||{}, t=totais(rows), f=coletaFiltros();
    var corpo='';
    rows.forEach(function(x){
      corpo+='<tr>'+
        '<td class="mono">'+esc(x.cb)+'</td>'+
        '<td>'+esc(x.nome)+'</td>'+
        '<td>'+esc(x.cat)+'</td>'+
        '<td class="num">'+esc(x.custo)+'</td>'+
        '<td class="num">'+esc(x.margem)+'</td>'+
        '<td class="num">'+esc(x.venda)+'</td>'+
        '<td class="num">'+esc(x.emin)+'</td>'+
        '<td class="num">'+esc(x.est)+'</td>'+
        '<td><span class="dt" style="background:'+cor(x.cls)+'"></span>'+esc(x.sit)+'</td>'+
      '</tr>';
    });
    if(!rows.length) corpo='<tr><td colspan="9" style="text-align:center;padding:18px;color:#64748b">Nenhum produto.</td></tr>';
    var filtrosTxt = f.length ? f.map(function(p){return '<b>'+esc(p[0])+':</b> '+esc(p[1]);}).join(' &nbsp;•&nbsp; ') : 'Nenhum filtro aplicado (todos os produtos).';
    return '<div class="doc">'+
      '<div class="rep-head">'+
        '<div class="rep-logo">'+esc(monograma())+'</div>'+
        '<div class="rep-id"><div class="rep-app">'+esc(Q_APP)+'</div><div class="rep-sub">Relatório de Produtos e Estoque</div></div>'+
        '<div class="rep-meta"><div>Emitido em: <b>'+agora()+'</b></div><div>Responsável: <b>'+esc(Q_USER)+'</b></div></div>'+
      '</div>'+
      '<div class="sec-tit">Resumo</div>'+
      '<div class="kpis">'+
        '<div class="kpi"><span>Produtos</span><b>'+intBR(t.itens)+'</b></div>'+
        '<div class="kpi"><span>Estoque (un)</span><b>'+qtd(t.est)+'</b></div>'+
        '<div class="kpi kpi-c"><span>Valor a custo</span><b>'+brl(t.custo)+'</b></div>'+
        '<div class="kpi kpi-v"><span>Valor a venda</span><b>'+brl(t.venda)+'</b></div>'+
        '<div class="kpi kpi-l"><span>Lucro potencial</span><b>'+brl(t.lucro)+'</b></div>'+
      '</div>'+
      '<div class="status-line">'+
        '<span class="badge b-baixo">Abaixo do mínimo: <b>'+intBR(r.baixo)+'</b></span>'+
        '<span class="badge b-min">No mínimo: <b>'+intBR(r.minimo)+'</b></span>'+
        '<span class="badge b-acima">Acima do mínimo: <b>'+intBR(r.acima)+'</b></span>'+
      '</div>'+
      '<div class="filtros-box">'+filtrosTxt+'</div>'+
      '<div class="sec-tit">Produtos</div>'+
      '<table><thead><tr>'+
        '<th>Cód. barras</th><th>Produto</th><th>Categoria</th><th class="num">Compra</th>'+
        '<th class="num">Margem</th><th class="num">Venda</th><th class="num">Est. mín.</th>'+
        '<th class="num">Estoque</th><th>Situação</th>'+
      '</tr></thead><tbody>'+corpo+'</tbody>'+
      '<tfoot><tr><td colspan="7">Totais ('+intBR(t.itens)+' itens)</td>'+
        '<td class="num">'+qtd(t.est)+'</td><td>'+brl(t.venda)+'</td></tr></tfoot>'+
      '</table>'+
      '<div class="rep-foot">'+esc(Q_APP)+' &bull; Documento gerado automaticamente em '+agora()+' &bull; Página única</div>'+
    '</div>';
  }

  function relTermico(j, fmt){
    var rows=j.rows||[], r=j.resumo||{}, t=totais(rows), f=coletaFiltros();
    var itens='';
    rows.forEach(function(x){
      itens+='<div class="it">'+
        '<div class="nm"><span class="dt" style="background:'+cor(x.cls)+'"></span>'+esc(x.nome)+'</div>'+
        '<div class="row"><span>'+esc(x.cb||'-')+'</span><span>'+esc(x.cat||'')+'</span></div>'+
        '<div class="row"><span>Venda: '+esc(x.venda)+'</span><span>Margem: '+esc(x.margem)+'</span></div>'+
        '<div class="row"><span>Estoque: '+esc(x.est)+'</span><span>Mín.: '+esc(x.emin)+'</span></div>'+
        '<div class="row"><span>'+esc(x.sit)+'</span><span>Compra: '+esc(x.custo)+'</span></div>'+
      '</div><div class="hr"></div>';
    });
    if(!rows.length) itens='<div class="c">Nenhum produto.</div><div class="hr"></div>';
    var filtrosTxt = f.length ? f.map(function(p){return p[0]+': '+p[1];}).join(' | ') : 'Sem filtros';
    return '<div class="c app">'+esc(Q_APP)+'</div>'+
      '<div class="c sub">Produtos e Estoque</div>'+
      '<div class="c meta">'+agora()+'<br>Resp.: '+esc(Q_USER)+'</div>'+
      '<div class="hr"></div>'+
      '<div class="meta"><b>Filtros:</b> '+esc(filtrosTxt)+'</div>'+
      '<div class="hr"></div>'+
      '<div class="row b"><span>Produtos</span><span>'+intBR(t.itens)+'</span></div>'+
      '<div class="row"><span>Abaixo / Mín / Acima</span><span>'+intBR(r.baixo)+' / '+intBR(r.minimo)+' / '+intBR(r.acima)+'</span></div>'+
      '<div class="row"><span>Estoque total (un)</span><span>'+qtd(t.est)+'</span></div>'+
      '<div class="row"><span>Valor a custo</span><span>'+brl(t.custo)+'</span></div>'+
      '<div class="row tot"><span>Valor a venda</span><span>'+brl(t.venda)+'</span></div>'+
      '<div class="row"><span>Lucro potencial</span><span>'+brl(t.lucro)+'</span></div>'+
      '<div class="hr"></div>'+ itens +
      '<div class="row tot"><span>TOTAL VENDA</span><span>'+brl(t.venda)+'</span></div>'+
      '<div class="hr"></div>'+
      '<div class="c foot">'+esc(Q_APP)+'<br>Gerado em '+agora()+'</div>';
  }

  function imprimir(fmt){
    var u = new URL(window.location.href);
    u.searchParams.set('ajax','1'); u.searchParams.set('print','1');
    fetch(u.toString(), {cache:'no-store'}).then(function(r){return r.json();}).then(function(j){
      if(!j || !j.ok){ alert('Não foi possível gerar o relatório agora.'); return; }
      var corpo = (fmt==='a4') ? relA4(j) : relTermico(j, fmt);
      var doc = '<!doctype html><html lang="pt-br"><head><meta charset="utf-8">'+
        '<title>Relatório de Produtos e Estoque</title><style>'+cssBase(fmt)+'</style></head><body>'+
        corpo +
        '<scr'+'ipt>setTimeout(function(){try{window.focus();window.print();}catch(e){}},300);'+
        'window.onafterprint=function(){setTimeout(function(){window.close();},200);};<\/scr'+'ipt>'+
        '</body></html>';
      var w = window.open('', '_blank');
      if(!w){ alert('Permita pop-ups para imprimir o relatório.'); return; }
      w.document.open(); w.document.write(doc); w.document.close();
    }).catch(function(){ alert('Falha ao buscar os dados do relatório.'); });
  }
})();
</script>

<?php endif; ?>
</main>
</body>
</html>
