<?php
require_once __DIR__ . '/auth.php';
q_session_start();

if (!empty($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!q_csrf_check($_POST['csrf'] ?? '')) {
        $erro = 'Sessão expirada. Tente novamente.';
    } else {
        $login = $_POST['login'] ?? '';
        $senha = $_POST['senha'] ?? '';
        try {
            $user = q_autenticar($login, $senha);
        } catch (Exception $e) {
            $user = null;
            $erro = 'Erro ao acessar o banco de dados.';
        }
        if ($user) {
            q_login_sessao($user);
            header('Location: index.php');
            exit;
        } elseif ($erro === '') {
            $erro = 'Usuário ou senha inválidos.';
        }
    }
}

$usuarios = q_listar_usuarios();
$temLista = count($usuarios) > 0;
$loginSel = $_POST['login'] ?? '';
$csrf = q_csrf_token();
$expirado = isset($_GET['expirado']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Entrar • <?= h(APP_NOME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body class="login-body">
  <form class="login-card" method="post" autocomplete="off">
    <div class="login-logo">🌐</div>
    <h1><?= h(APP_NOME) ?></h1>
    <p class="login-sub">Monitoramento e consultas</p>

    <?php if ($expirado && $erro === ''): ?>
      <div class="alert alert-info">Sua sessão expirou. Entre novamente.</div>
    <?php endif; ?>
    <?php if ($erro): ?>
      <div class="alert alert-erro"><?= h($erro) ?></div>
    <?php endif; ?>

    <label>Usuário</label>
    <?php if ($temLista): ?>
      <select name="login" required>
        <option value="" disabled <?= $loginSel === '' ? 'selected' : '' ?>>— selecione o usuário —</option>
        <?php foreach ($usuarios as $u): ?>
          <option value="<?= h($u['login']) ?>" <?= $loginSel === $u['login'] ? 'selected' : '' ?>>
            <?= h($u['nome']) ?><?= strcasecmp($u['nome'], $u['login']) !== 0 ? ' (' . h($u['login']) . ')' : '' ?>
          </option>
        <?php endforeach; ?>
      </select>
    <?php else: ?>
      <input type="text" name="login" value="<?= h($loginSel) ?>" autofocus required>
    <?php endif; ?>

    <label>Senha</label>
    <div class="senha-wrap">
      <input type="password" name="senha" id="senha" required>
      <button type="button" class="olho" id="btnOlho" aria-label="Mostrar senha" title="Mostrar/ocultar senha">👁</button>
    </div>

    <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
    <button type="submit" class="btn-entrar">Entrar</button>
    <p class="login-foot">Use o mesmo usuário e senha do sistema Quantum.</p>
  </form>

<script>
(function(){
  var btn = document.getElementById('btnOlho');
  var inp = document.getElementById('senha');
  if (btn && inp) {
    btn.addEventListener('click', function(){
      var ver = inp.type === 'password';
      inp.type = ver ? 'text' : 'password';
      btn.textContent = ver ? '🙈' : '👁';
      btn.setAttribute('aria-label', ver ? 'Ocultar senha' : 'Mostrar senha');
      inp.focus();
    });
  }
})();
</script>
</body>
</html>
