<?php
/**
 * Funções utilitárias puras (sem banco) do Painel Web Quantum.
 * Mantidas separadas para facilitar testes e reuso.
 */

/**
 * Verifica a senha contra o hash armazenado no sistema Quantum.
 * Regras (iguais ao app Python):
 *   - hash começa com $2b$ / $2y$  -> bcrypt  (password_verify)
 *   - caso contrário               -> SHA-256 hex sem salt
 */
function q_verify_password($senha, $hash) {
    $senha = (string)$senha;
    $hash = (string)$hash;
    if ($hash === '') {
        return false;
    }
    if (strpos($hash, '$2b$') === 0 || strpos($hash, '$2y$') === 0 || strpos($hash, '$2a$') === 0) {
        if (password_verify($senha, $hash)) {
            return true;
        }
        // Compatibilidade: bcrypt do Python usa o prefixo $2b$. Em algumas versões
        // do PHP o password_verify só aceita $2y$. O corpo do hash é idêntico, então
        // tentamos novamente normalizando o prefixo para $2y$.
        $norm = '$2y$' . substr($hash, 4);
        return password_verify($senha, $norm);
    }
    // SHA-256 hex (lowercase), comparação em tempo constante
    return hash_equals(strtolower($hash), hash('sha256', $senha));
}

/** Converte valor do banco em float de forma tolerante (aceita "12,50" ou "12.50"). */
function q_num($v) {
    if ($v === null || $v === '') {
        return 0.0;
    }
    if (is_numeric($v)) {
        return (float)$v;
    }
    $s = str_replace(['.', ' '], ['', ''], (string)$v); // remove milhar
    $s = str_replace(',', '.', $s);
    return is_numeric($s) ? (float)$s : 0.0;
}

/**
 * Classe CSS conforme a regra de estoque:
 *   estoque  < mínimo  -> 'st-baixo'  (vermelho claro)
 *   estoque == mínimo  -> 'st-minimo' (amarelo claro)
 *   estoque  > mínimo  -> 'st-acima'  (azul claro)
 */
function q_stock_class($estoque, $minimo) {
    $e = q_num($estoque);
    $m = q_num($minimo);
    $tol = 0.0005;
    if ($e < $m - $tol) {
        return 'st-baixo';
    }
    if ($e > $m + $tol) {
        return 'st-acima';
    }
    return 'st-minimo';
}

/** Rótulo legível do status de estoque. */
function q_stock_label($estoque, $minimo) {
    switch (q_stock_class($estoque, $minimo)) {
        case 'st-baixo':  return 'Abaixo do mínimo';
        case 'st-acima':  return 'Acima do mínimo';
        default:          return 'No mínimo';
    }
}

/** Margem de lucro % a partir de custo e venda (calculada, pois não é armazenada). */
function q_margem($custo, $venda) {
    $c = q_num($custo);
    $v = q_num($venda);
    if ($c > 0) {
        return (($v - $c) / $c) * 100.0;
    }
    return null; // sem custo não há como calcular
}

/** Formata moeda em Real brasileiro. */
function q_money($v) {
    return 'R$ ' . number_format(q_num($v), 2, ',', '.');
}

/** Formata quantidade (até 3 casas, sem zeros à toa). */
function q_qtd($v) {
    $n = q_num($v);
    if (abs($n - round($n)) < 0.0005) {
        return number_format($n, 0, ',', '.');
    }
    return rtrim(rtrim(number_format($n, 3, ',', '.'), '0'), ',');
}

/** Escape para HTML. */
function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
