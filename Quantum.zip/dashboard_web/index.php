<?php
require_once __DIR__ . '/auth.php';
$user = q_require_login();

$botoes = [
    ['titulo' => 'Controle de Produtos e Estoque', 'desc' => 'Tabela de produtos, preços e estoque com alertas de mínimo.', 'icone' => '📦', 'href' => 'produtos.php', 'ativo' => true],
    ['titulo' => 'Vendas',          'desc' => 'Analisar vendas: filtros, totais e detalhes.', 'icone' => '📊', 'href' => 'vendas.php', 'ativo' => true],
    ['titulo' => 'Clientes',        'desc' => 'Cadastro de clientes (em breve).',      'icone' => '👥', 'href' => '#', 'ativo' => false],
    ['titulo' => 'Relatórios',      'desc' => 'Indicadores e relatórios (em breve).',  'icone' => '📈', 'href' => '#', 'ativo' => false],
    ['titulo' => 'Configurações',   'desc' => 'Conexão do banco e chave da API (senha mestra).', 'icone' => '⚙️', 'href' => 'config_admin.php', 'ativo' => true],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Painel • <?= h(APP_NOME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body>
<header class="topbar">
  <div class="brand">🌐 <?= h(APP_NOME) ?></div>
  <div class="userbox">
    <span class="user-nome"><?= h($user['nome']) ?></span>
    <span class="user-nivel"><?= h($user['nivel']) ?></span>
    <a class="btn-sair" href="logout.php">Sair</a>
  </div>
</header>

<main class="wrap">
  <h1 class="page-title">Dashboard</h1>
  <p class="page-sub">Selecione um módulo abaixo.</p>

  <div class="cards">
    <?php foreach ($botoes as $b): ?>
      <?php if ($b['ativo']): ?>
        <a class="card" href="<?= h($b['href']) ?>">
          <div class="card-ico"><?= $b['icone'] ?></div>
          <div class="card-tit"><?= h($b['titulo']) ?></div>
          <div class="card-desc"><?= h($b['desc']) ?></div>
        </a>
      <?php else: ?>
        <div class="card card-off">
          <div class="card-ico"><?= $b['icone'] ?></div>
          <div class="card-tit"><?= h($b['titulo']) ?></div>
          <div class="card-desc"><?= h($b['desc']) ?></div>
          <span class="badge-breve">em breve</span>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
</main>
</body>
</html>
