<?php
require_once __DIR__ . '/auth.php';
$user = q_require_login();
q_session_start();

/* ---------- Helpers de edição de arquivos de configuração ---------- */
function cfg_get_define($c, $name) {
    $n = preg_quote($name, '/');
    // valor entre aspas simples (tratando escapes \' e \\)
    if (preg_match('/define\(\s*[\'"]' . $n . '[\'"]\s*,\s*\'((?:\\\\.|[^\'\\\\])*)\'\s*\)\s*;/s', $c, $m)) {
        return str_replace(["\\'", "\\\\"], ["'", "\\"], $m[1]);
    }
    // valor entre aspas duplas
    if (preg_match('/define\(\s*[\'"]' . $n . '[\'"]\s*,\s*"((?:\\\\.|[^"\\\\])*)"\s*\)\s*;/s', $c, $m)) {
        return str_replace(['\\"', "\\\\"], ['"', "\\"], $m[1]);
    }
    if (preg_match('/define\(\s*[\'"]' . $n . '[\'"]\s*,\s*([0-9]+)\s*\)\s*;/', $c, $m)) return $m[1];
    return '';
}
function cfg_set_define($c, $name, $value, $isInt = false) {
    if ($isInt) { $val = (string)(int)$value; }
    else { $val = "'" . str_replace(['\\', "'"], ['\\\\', "\\'"], (string)$value) . "'"; }
    $pat = '/define\(\s*[\'"]' . preg_quote($name, '/') . '[\'"]\s*,\s*[^;]*\);/';
    $rep = "define('" . $name . "', " . $val . ");";
    if (preg_match($pat, $c)) return preg_replace($pat, $rep, $c, 1);
    if (strpos($c, '<?php') !== false) return preg_replace('/<\?php/', "<?php\n" . $rep, $c, 1);
    return $c . "\n" . $rep . "\n";
}
function nova_chave_api($n = 48) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    $out = '';
    for ($i = 0; $i < $n; $i++) { $out .= $chars[random_int(0, strlen($chars) - 1)]; }
    return $out;
}

$cfgPath = __DIR__ . '/config.php';

// Candidatos para o sync_config.php (uma pasta acima, ou em api_php_servidor)
$syncCands = [
    __DIR__ . '/../sync_config.php',
    __DIR__ . '/../api_php_servidor/sync_config.php',
    __DIR__ . '/sync_config.php',
    __DIR__ . '/../../sync_config.php',
    __DIR__ . '/../php_servidor/sync_config.php',
];
$syncPath = '';
foreach ($syncCands as $cand) { if (is_file($cand)) { $syncPath = $cand; break; } }
if (!$syncPath) { $syncPath = __DIR__ . '/../sync_config.php'; } // padrão (uma pasta acima)
if (!empty($_POST['sync_path'])) {
    $p = trim($_POST['sync_path']);
    if (basename($p) === 'sync_config.php') { $syncPath = $p; }
}

$msg = ''; $msgTipo = 'ok';
$unlocked = !empty($_SESSION['cfg_unlocked']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if (!q_csrf_check($_POST['csrf'] ?? '')) {
        $msg = 'Sessão expirada. Recarregue a página.'; $msgTipo = 'erro';
    } elseif ($acao === 'unlock') {
        if (hash_equals('4872', (string)($_POST['senha'] ?? ''))) {
            $_SESSION['cfg_unlocked'] = true; $unlocked = true;
            $msg = 'Configurações desbloqueadas.';
        } else { $msg = 'Senha incorreta.'; $msgTipo = 'erro'; }
    } elseif ($acao === 'lock') {
        unset($_SESSION['cfg_unlocked']); $unlocked = false; $msg = 'Configurações bloqueadas.';
    } elseif (!$unlocked) {
        $msg = 'Digite a senha para acessar as configurações.'; $msgTipo = 'erro';
    } elseif ($acao === 'save_painel') {
        $c = @file_get_contents($cfgPath);
        if ($c === false) { $msg = 'Não foi possível ler config.php.'; $msgTipo = 'erro'; }
        else {
            $c = cfg_set_define($c, 'DB_HOST', $_POST['DB_HOST'] ?? '');
            $c = cfg_set_define($c, 'DB_PORT', $_POST['DB_PORT'] ?? '3306', true);
            $c = cfg_set_define($c, 'DB_NAME', $_POST['DB_NAME'] ?? '');
            $c = cfg_set_define($c, 'DB_USER', $_POST['DB_USER'] ?? '');
            $c = cfg_set_define($c, 'DB_PASS', $_POST['DB_PASS'] ?? '');
            $c = cfg_set_define($c, 'DB_CHARSET', $_POST['DB_CHARSET'] ?: 'utf8mb4');
            if (isset($_POST['APP_NOME'])) { $c = cfg_set_define($c, 'APP_NOME', $_POST['APP_NOME']); }
            if (@file_put_contents($cfgPath, $c, LOCK_EX) !== false) { $msg = 'Conexão do painel (config.php) salva com sucesso.'; }
            else { $msg = 'Falha ao gravar config.php (verifique permissão de escrita do arquivo).'; $msgTipo = 'erro'; }
        }
    } elseif ($acao === 'save_sync') {
        if (basename($syncPath) !== 'sync_config.php') { $msg = 'Caminho inválido para sync_config.php.'; $msgTipo = 'erro'; }
        else {
            $c = is_file($syncPath) ? @file_get_contents($syncPath) : "<?php\n";
            if ($c === false) { $msg = 'Não foi possível ler o sync_config.php.'; $msgTipo = 'erro'; }
            else {
                $c = cfg_set_define($c, 'DB_HOST', $_POST['S_DB_HOST'] ?? '');
                $c = cfg_set_define($c, 'DB_PORT', $_POST['S_DB_PORT'] ?? '3306', true);
                $c = cfg_set_define($c, 'DB_NAME', $_POST['S_DB_NAME'] ?? '');
                $c = cfg_set_define($c, 'DB_USER', $_POST['S_DB_USER'] ?? '');
                $c = cfg_set_define($c, 'DB_PASS', $_POST['S_DB_PASS'] ?? '');
                $c = cfg_set_define($c, 'DB_CHARSET', $_POST['S_DB_CHARSET'] ?: 'utf8mb4');
                if (isset($_POST['SYNC_API_KEY'])) { $c = cfg_set_define($c, 'SYNC_API_KEY', $_POST['SYNC_API_KEY']); }
                if (@file_put_contents($syncPath, $c, LOCK_EX) !== false) { $msg = 'Dados de sincronização (sync_config.php) salvos com sucesso.'; }
                else { $msg = 'Falha ao gravar o sync_config.php (verifique o caminho e a permissão de escrita).'; $msgTipo = 'erro'; }
            }
        }
    }
}

// Limpar todos os dados do banco (zona de perigo)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'limpar_banco' && $unlocked && q_csrf_check($_POST['csrf'] ?? '')) {
    if (($_POST['confirma'] ?? '') !== 'LIMPAR') { $msg = 'Para limpar, digite LIMPAR (em maiúsculas) no campo de confirmação.'; $msgTipo = 'erro'; }
    elseif (!hash_equals('4872', (string)($_POST['senha2'] ?? ''))) { $msg = 'Senha de confirmação incorreta.'; $msgTipo = 'erro'; }
    else {
        try {
            $pdo = q_pdo();
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            $st = $pdo->prepare("SELECT table_name AS tn FROM information_schema.tables WHERE table_schema = ? AND table_type = 'BASE TABLE'");
            $st->execute([DB_NAME]);
            $n = 0;
            foreach ($st->fetchAll() as $t) {
                $tn = (string)$t['tn'];
                if ($tn === '') continue;
                $pdo->exec('TRUNCATE TABLE `' . str_replace('`', '', $tn) . '`');
                $n++;
            }
            $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            $msg = "Banco limpo com sucesso: $n tabela(s) esvaziada(s). As estruturas foram mantidas.";
            $msgTipo = 'ok';
        } catch (Exception $e) {
            $msg = 'Falha ao limpar o banco: ' . $e->getMessage(); $msgTipo = 'erro';
        }
    }
}

// Valores atuais para preencher os formulários
$cfgC = @file_get_contents($cfgPath) ?: '';
$cur = [
    'DB_HOST' => cfg_get_define($cfgC, 'DB_HOST'), 'DB_PORT' => cfg_get_define($cfgC, 'DB_PORT') ?: '3306',
    'DB_NAME' => cfg_get_define($cfgC, 'DB_NAME'), 'DB_USER' => cfg_get_define($cfgC, 'DB_USER'),
    'DB_PASS' => cfg_get_define($cfgC, 'DB_PASS'), 'DB_CHARSET' => cfg_get_define($cfgC, 'DB_CHARSET') ?: 'utf8mb4',
    'APP_NOME' => cfg_get_define($cfgC, 'APP_NOME'),
];
$syncExiste = is_file($syncPath);
$syncC = $syncExiste ? (@file_get_contents($syncPath) ?: '') : '';
$scur = [
    'DB_HOST' => cfg_get_define($syncC, 'DB_HOST'), 'DB_PORT' => cfg_get_define($syncC, 'DB_PORT') ?: '3306',
    'DB_NAME' => cfg_get_define($syncC, 'DB_NAME'), 'DB_USER' => cfg_get_define($syncC, 'DB_USER'),
    'DB_PASS' => cfg_get_define($syncC, 'DB_PASS'), 'DB_CHARSET' => cfg_get_define($syncC, 'DB_CHARSET') ?: 'utf8mb4',
    'SYNC_API_KEY' => cfg_get_define($syncC, 'SYNC_API_KEY'),
];
$csrf = q_csrf_token();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Configurações • <?= h(APP_NOME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body>
<header class="topbar">
  <div class="brand"><a href="index.php" class="voltar">‹ Painel</a> <span class="brand-txt">⚙️ Configurações</span></div>
  <div class="userbox"><span class="user-nome"><?= h($user['nome']) ?></span><a class="btn-sair" href="logout.php">Sair</a></div>
</header>

<main class="wrap">
<?php if ($msg): ?><div class="alert <?= $msgTipo==='erro'?'alert-erro':'alert-info' ?>"><?= h($msg) ?></div><?php endif; ?>

<?php if (!$unlocked): ?>
  <form class="cfg-lock" method="post" autocomplete="off">
    <div class="lock-ic">🔒</div>
    <h1>Área restrita</h1>
    <p>Digite a senha mestra para abrir as configurações de conexão.</p>
    <div class="senha-wrap">
      <input type="password" name="senha" id="senha" placeholder="Senha" autofocus required>
      <button type="button" class="olho" onclick="var s=document.getElementById('senha');s.type=s.type==='password'?'text':'password';this.textContent=s.type==='password'?'👁':'🙈';">👁</button>
    </div>
    <input type="hidden" name="acao" value="unlock">
    <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
    <button type="submit" class="btn-entrar">Desbloquear</button>
  </form>
<?php else: ?>

  <div class="cfg-topo">
    <p>Edite os dados de conexão. <b>Atenção:</b> alterações incorretas podem derrubar o acesso ao banco.</p>
    <form method="post" style="margin:0"><input type="hidden" name="acao" value="lock"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><button class="btn-cancelar" type="submit">🔒 Bloquear</button></form>
  </div>

  <!-- Conexão do Painel (config.php) -->
  <form class="painel" method="post" autocomplete="off">
    <div class="painel-head">🖥️ Conexão do Painel — config.php</div>
    <div class="painel-body">
      <div class="grid-filtros">
        <div class="campo"><label>Servidor (DB_HOST)</label><input type="text" name="DB_HOST" value="<?= h($cur['DB_HOST']) ?>"></div>
        <div class="campo"><label>Porta (DB_PORT)</label><input type="text" name="DB_PORT" value="<?= h($cur['DB_PORT']) ?>"></div>
        <div class="campo"><label>Banco (DB_NAME)</label><input type="text" name="DB_NAME" value="<?= h($cur['DB_NAME']) ?>"></div>
        <div class="campo"><label>Usuário (DB_USER)</label><input type="text" name="DB_USER" value="<?= h($cur['DB_USER']) ?>"></div>
        <div class="campo"><label>Senha (DB_PASS)</label><input type="text" name="DB_PASS" value="<?= h($cur['DB_PASS']) ?>"></div>
        <div class="campo"><label>Charset</label><input type="text" name="DB_CHARSET" value="<?= h($cur['DB_CHARSET']) ?>"></div>
        <div class="campo"><label>Nome do Painel (APP_NOME)</label><input type="text" name="APP_NOME" value="<?= h($cur['APP_NOME']) ?>"></div>
      </div>
      <div class="painel-acoes"><button type="submit">💾 Salvar conexão do painel</button>
        <input type="hidden" name="acao" value="save_painel"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"></div>
    </div>
  </form>

  <!-- Conexão da Sincronização (sync_config.php) -->
  <form class="painel" method="post" autocomplete="off">
    <div class="painel-head">🔄 Conexão da Sincronização — sync_config.php</div>
    <div class="painel-body">
      <div class="campo" style="margin-bottom:12px">
        <label>Caminho do sync_config.php <?= $syncExiste ? '<span class="ok-tag">encontrado</span>' : '<span class="warn-tag">não encontrado — informe o caminho</span>' ?></label>
        <input type="text" name="sync_path" value="<?= h($syncPath) ?>">
      </div>
      <div class="grid-filtros">
        <div class="campo"><label>Servidor (DB_HOST)</label><input type="text" name="S_DB_HOST" value="<?= h($scur['DB_HOST']) ?>"></div>
        <div class="campo"><label>Porta (DB_PORT)</label><input type="text" name="S_DB_PORT" value="<?= h($scur['DB_PORT']) ?>"></div>
        <div class="campo"><label>Banco (DB_NAME)</label><input type="text" name="S_DB_NAME" value="<?= h($scur['DB_NAME']) ?>"></div>
        <div class="campo"><label>Usuário (DB_USER)</label><input type="text" name="S_DB_USER" value="<?= h($scur['DB_USER']) ?>"></div>
        <div class="campo"><label>Senha (DB_PASS)</label><input type="text" name="S_DB_PASS" value="<?= h($scur['DB_PASS']) ?>"></div>
        <div class="campo"><label>Charset</label><input type="text" name="S_DB_CHARSET" value="<?= h($scur['DB_CHARSET']) ?>"></div>
      </div>
      <div class="campo" style="margin-top:12px">
        <label>Chave da API (SYNC_API_KEY)</label>
        <div class="chave-wrap">
          <input type="text" name="SYNC_API_KEY" id="apikey" value="<?= h($scur['SYNC_API_KEY']) ?>">
          <button type="button" class="btn-gerar" onclick="gerarChave()">🔑 Gerar nova chave</button>
        </div>
        <small class="dica">A mesma chave deve estar no app Quantum (campo API_KEY do Envio mysql externo).</small>
      </div>
      <div class="painel-acoes"><button type="submit">💾 Salvar sincronização</button>
        <input type="hidden" name="acao" value="save_sync"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"></div>
    </div>
  </form>

  <form class="painel painel-danger" method="post" autocomplete="off" onsubmit="return confirmarLimpeza()">
    <div class="painel-head danger-head">🗑️ Zona de perigo — Limpar banco de dados</div>
    <div class="painel-body">
      <p class="danger-txt"><b>Atenção:</b> esta ação apaga <b>TODOS os dados</b> de todas as tabelas do banco MySQL. As tabelas continuam existindo, porém ficam <b>vazias</b>. <b>Não há como desfazer.</b></p>
      <div class="grid-filtros">
        <div class="campo"><label>Digite <b>LIMPAR</b> para confirmar</label><input type="text" name="confirma" placeholder="LIMPAR" autocomplete="off"></div>
        <div class="campo"><label>Senha mestra</label><input type="password" name="senha2" placeholder="••••" autocomplete="off"></div>
      </div>
      <div class="painel-acoes">
        <button type="submit" class="btn-danger">🗑️ Limpar TODOS os dados</button>
        <input type="hidden" name="acao" value="limpar_banco"><input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      </div>
    </div>
  </form>

<script>
function confirmarLimpeza(){
  return confirm('Tem certeza ABSOLUTA? Isso apaga TODOS os dados do banco e NÃO pode ser desfeito.');
}
function gerarChave(){
  var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_', s='';
  var arr=new Uint32Array(48);
  if(window.crypto&&window.crypto.getRandomValues){ window.crypto.getRandomValues(arr);
    for(var i=0;i<48;i++){ s+=chars[arr[i]%chars.length]; } }
  else { for(var j=0;j<48;j++){ s+=chars[Math.floor(Math.random()*chars.length)]; } }
  document.getElementById('apikey').value=s;
}
</script>

<?php endif; ?>
</main>
</body>
</html>
