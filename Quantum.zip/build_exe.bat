@echo off
chcp 65001 >nul
setlocal
cls
echo ============================================================
echo  COMPILADOR QUANTUM CORRIGIDO
echo  Corrige erro: No module named '_socket'
echo  Corrige aviso: Failed to remove temporary directory _MEI
echo ============================================================
echo.

set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set QUANTUM_RUNTIME_DIR=C:\ProgramData\QuantumRuntime

if not exist "%QUANTUM_RUNTIME_DIR%" mkdir "%QUANTUM_RUNTIME_DIR%" >nul 2>nul

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Instale o Python e marque Add Python to PATH.
    pause
    exit /b 1
)

echo [INFO] Limpando temporarios antigos do PyInstaller...
for /d %%D in ("%TEMP%\_MEI*") do rmdir /s /q "%%D" >nul 2>nul
for /d %%D in ("%QUANTUM_RUNTIME_DIR%\_MEI*") do rmdir /s /q "%%D" >nul 2>nul

echo [INFO] Iniciando compilador Python corrigido...
python quantum_build_exe_corrigido.py
if errorlevel 1 goto erro

echo.
echo ============================================================
echo  CONCLUIDO!
echo  Executaveis gerados na pasta dist\
echo ============================================================
pause
exit /b 0

:erro
echo.
echo [ERRO] A compilacao falhou.
echo.
echo Dicas:
echo 1. Feche todos os executaveis Quantum abertos.
echo 2. Abra o PowerShell/CMD como Administrador.
echo 3. Rode novamente build_exe.bat.
echo 4. Se continuar sem _socket, repare/reinstale seu Python 3.11.
echo.
pause
exit /b 1
