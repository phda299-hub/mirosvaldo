# Envio MySQL externo via API PHP — Guia rápido

## Por que mudou

Hospedagens gratuitas como o **InfinityFree NÃO permitem conexão MySQL remota**
(de fora da rede deles). Por isso a versão anterior, que conectava direto no
MySQL pelo aplicativo, exibia o erro:

```
2003: Can't connect to MySQL server on '%-.100s:%u' (%s)
(Warning: %u format: a real number is required, not str)
```

Agora o **Envio mysql externo** funciona como a versão que já dava certo
(TopVendas x Web): o aplicativo envia os dados por **HTTPS** para um arquivo
**PHP hospedado no próprio servidor web**, e esse PHP grava no MySQL local da
hospedagem. Assim o bloqueio de MySQL remoto deixa de ser um problema.

```
[Quantum no Windows]  --HTTPS POST (JSON)-->  sync_api.php  --PDO local-->  MySQL
                       URL + API_KEY           (na hospedagem)              (InfinityFree)
```

## Passo 1 — Publicar o PHP na hospedagem

1. Abra a pasta `api_php_servidor/` deste pacote.
2. Edite `sync_config.php` e preencha:
   - `SYNC_API_KEY`: uma chave longa e aleatória (você vai repeti-la no Quantum).
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`: os dados do MySQL da sua
     hospedagem (no InfinityFree veja em **MySQL Databases**).
3. Envie os arquivos `sync_api.php`, `sync_config.php` e `.htaccess` para a
   pasta pública do site (geralmente `htdocs` no InfinityFree).
4. A URL final será algo como:
   `https://seusite.infinityfreeapp.com/sync_api.php`

## Passo 2 — Configurar o Quantum

1. Abra o sistema e vá em **Utilitários > Envio mysql externo** (pede senha mestra).
2. Preencha:
   - **URL da API PHP**: a URL do `sync_api.php` (passo 1).
   - **Chave da API (API_KEY)**: exatamente a mesma de `SYNC_API_KEY`.
   - Marque **Ativar**.
3. Clique em **Testar**. Deve aparecer "Conexão OK com a API PHP".
4. Clique em **Gravar**. O sistema faz a primeira sincronização completa e, a
   partir daí, mantém a cópia atualizada em segundo plano.

## Observações

- O aplicativo passa automaticamente pela proteção anti-bot do InfinityFree
  (precisa da biblioteca `pycryptodome`, já incluída no `requirements.txt` e no
  instalador automático de dependências).
- Os dados sensíveis do MySQL (host, usuário, senha) ficam **somente** no
  `sync_config.php`, no servidor — não no aplicativo.
- A sincronização é um **espelho completo**: cada tabela local é recriada/ajustada
  e reenviada no servidor (REPLACE INTO), refazendo tudo se a conexão cair.
- Se quiser usar outra hospedagem (VPS, plano pago, etc.), basta apontar a URL
  para o `sync_api.php` publicado lá e usar os dados de MySQL daquele servidor.


---

## Atualização — sincronização em tempo real e atômica

Esta versão melhora a sincronização de fundo:

- **Quase em tempo real:** o sistema verifica alterações a cada ~1,5s e envia
  imediatamente (antes era a cada 8s).
- **Incremental:** envia **apenas a(s) tabela(s) que mudaram**, não mais todas a
  cada ciclo. Isso deixa o envio muito mais leve e rápido (essencial no
  InfinityFree, que tem limite de requisições).
- **Atômica:** cada tabela é carregada numa tabela temporária no servidor e
  trocada com `RENAME TABLE` (operação atômica). O destino nunca fica vazio ou
  parcial, mesmo se a conexão cair no meio.
- **Espelho completo de segurança:** a cada ~5 minutos é feita uma verificação
  completa de todas as tabelas, para cobrir remoções/itens perdidos.

### IMPORTANTE ao atualizar

O arquivo **`sync_api.php` foi atualizado** (novas ações `swap` e `fresh`).
Ao instalar esta versão, **reenvie o `sync_api.php`** desta pasta para a
hospedagem, substituindo o anterior. O `sync_config.php` (com seus dados e a
API_KEY) **não precisa** ser trocado.


---

## Painel Web (dashboard de monitoramento)

Foi incluída a pasta **`dashboard_web/`** — um site em PHP que roda na mesma
hospedagem e lê as tabelas espelhadas:

- **Login** com o mesmo usuário/senha da tabela `usuarios` do Quantum
  (bcrypt `$2b$`/`$2y$` ou SHA-256).
- **Dashboard** com botões; o 1º botão abre **Controle de Produtos e Estoque**:
  tabela com código de barras, nome, categoria, valor de compra, margem de lucro
  (calculada), valor de venda, estoque mínimo e estoque, com busca e cores:
  **vermelho claro** (abaixo do mínimo), **amarelo claro** (no mínimo),
  **azul claro** (acima do mínimo).

Para instalar, veja `dashboard_web/LEIA-ME.txt` (resumo: preencher `config.php`
com os mesmos dados do MySQL e enviar a pasta para o htdocs; acessar
`.../dashboard_web/login.php`).
