<?php
/**
 * Configuração do endpoint de sincronização (sync_api.php).
 *
 * Preencha os dados do MySQL da SUA hospedagem (ex.: InfinityFree) e defina
 * uma chave secreta longa. ESTA MESMA CHAVE deve ser informada no sistema
 * Quantum, no campo "Chave da API (API_KEY)" da tela Envio mysql externo.
 *
 * IMPORTANTE: como o sync_api.php roda DENTRO da hospedagem, ele acessa o
 * MySQL localmente — por isso funciona mesmo onde a conexão MySQL remota é
 * bloqueada (caso do InfinityFree gratuito).
 */

// Chave secreta compartilhada entre o Quantum (Windows) e este PHP.
// Troque por um valor longo e aleatório (use o mesmo no Quantum).
define('SYNC_API_KEY', 'COLOQUE_AQUI_UMA_CHAVE_LONGA_E_ALEATORIA');

// Dados do MySQL da sua hospedagem (veja no painel: "MySQL Databases").
define('DB_HOST', 'sqlXXX.infinityfree.com');  // Host MySQL informado pela hospedagem
define('DB_PORT', 3306);
define('DB_NAME', 'if0_XXXXXXXX_banco');        // Nome do banco
define('DB_USER', 'if0_XXXXXXXX');              // Usuário do banco
define('DB_PASS', 'SUA_SENHA_DO_MYSQL');        // Senha do banco
define('DB_CHARSET', 'utf8mb4');

// Limite máximo de registros por requisição (segurança).
define('MAX_ROWS_PER_REQUEST', 50000);

// Arquivo de log (relativo a este script).
define('SYNC_LOG_FILE', __DIR__ . '/sync_api.log');
