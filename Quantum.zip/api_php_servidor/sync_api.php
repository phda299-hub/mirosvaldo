<?php
/**
 * Endpoint de sincronização - recebe dados do serviço Python via HTTP POST
 * e grava no MySQL local da hospedagem usando REPLACE INTO.
 *
 * Ações suportadas (parâmetro "action"):
 *   - "sync"       : Recebe registros e faz REPLACE INTO na tabela indicada.
 *   - "create_table": Cria a tabela se não existir, adiciona colunas faltantes.
 *   - "ping"       : Teste de conectividade (retorna status do banco).
 *   - "truncate"   : Limpa uma tabela (requer confirmação).
 *
 * Protocolo:
 *   - Método: POST
 *   - Content-Type: application/json
 *   - Header: X-Api-Key com a chave secreta
 *   - Body JSON conforme a ação
 */

header('Content-Type: application/json; charset=utf-8');

// Carrega configuração
$configPath = __DIR__ . '/sync_config.php';
if (!file_exists($configPath)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Arquivo sync_config.php não encontrado no servidor.']);
    exit;
}
require_once $configPath;

// ============================================================
// Funções auxiliares
// ============================================================

function sync_log($message) {
    if (defined('SYNC_LOG_FILE') && SYNC_LOG_FILE) {
        $line = date('Y-m-d H:i:s') . ' ' . $message . "\n";
        @file_put_contents(SYNC_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
    }
}

function json_response($data, $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function json_error($message, $httpCode = 400) {
    sync_log("[ERRO] $message");
    json_response(['status' => 'error', 'message' => $message], $httpCode);
}

function get_pdo() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET,
        ]);
    } catch (PDOException $e) {
        json_error('Falha na conexão com o MySQL: ' . $e->getMessage(), 500);
    }
    return $pdo;
}

function quote_identifier($name) {
    return '`' . str_replace('`', '``', $name) . '`';
}

// ============================================================
// Autenticação
// ============================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido. Use POST.', 405);
}

// Aceita a chave via header ou campo JSON
$apiKey = isset($_SERVER['HTTP_X_API_KEY']) ? $_SERVER['HTTP_X_API_KEY'] : '';

$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true);

if (empty($apiKey) && isset($body['api_key'])) {
    $apiKey = $body['api_key'];
}

if (!$apiKey || !hash_equals(SYNC_API_KEY, $apiKey)) {
    json_error('Chave de API inválida ou ausente.', 403);
}

if (!is_array($body)) {
    json_error('Body JSON inválido ou ausente.');
}

$action = isset($body['action']) ? strtolower(trim($body['action'])) : '';

// ============================================================
// Ação: ping
// ============================================================
if ($action === 'ping') {
    try {
        $pdo = get_pdo();
        $stmt = $pdo->query('SELECT 1');
        json_response([
            'status'   => 'ok',
            'message'  => 'Conexão com o MySQL OK.',
            'database' => DB_NAME,
            'host'     => DB_HOST,
        ]);
    } catch (Exception $e) {
        json_error('Ping falhou: ' . $e->getMessage(), 500);
    }
}

// ============================================================
// Ação: create_table
// ============================================================
if ($action === 'create_table') {
    $tableName = isset($body['table']) ? trim($body['table']) : '';
    $columns   = isset($body['columns']) ? $body['columns'] : [];  // [{"name":"...", "type":"...", "nullable":true}]
    $primaryKeys = isset($body['primary_keys']) ? $body['primary_keys'] : [];

    if (!$tableName || !is_array($columns) || count($columns) === 0) {
        json_error('Parâmetros inválidos para create_table. Necessário: table, columns[].');
    }

    $pdo = get_pdo();
    $actions = [];

    // Recriação limpa (usada para tabelas temporárias da sincronização atômica).
    $fresh = isset($body['fresh']) ? ($body['fresh'] === true || $body['fresh'] === 'true' || $body['fresh'] === 1) : false;
    if ($fresh) {
        try {
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $pdo->exec("DROP TABLE IF EXISTS " . quote_identifier($tableName));
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        } catch (Exception $e) { /* ignora */ }
    }

    // Verifica se a tabela existe
    $stmt = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1");
    $stmt->execute([DB_NAME, $tableName]);
    $tableExists = (bool) $stmt->fetch();

    if (!$tableExists) {
        // Criar tabela
        $colDefs = [];
        foreach ($columns as $col) {
            $colDefs[] = quote_identifier($col['name']) . ' ' . $col['type'] . ' NULL';
        }
        if (!empty($primaryKeys)) {
            $pkCols = implode(', ', array_map('quote_identifier', $primaryKeys));
            $colDefs[] = "PRIMARY KEY ($pkCols)";
        }
        $sql = "CREATE TABLE " . quote_identifier($tableName) . " (" . implode(', ', $colDefs) . ") ENGINE=InnoDB DEFAULT CHARSET=" . DB_CHARSET;
        $pdo->exec($sql);
        $actions[] = "Tabela $tableName criada.";
        sync_log("[INFO] Tabela $tableName criada automaticamente.");
    }

    // Verificar colunas faltantes
    $stmt = $pdo->prepare("SELECT column_name FROM information_schema.columns WHERE table_schema = ? AND table_name = ?");
    $stmt->execute([DB_NAME, $tableName]);
    $existing = [];
    while ($row = $stmt->fetch()) {
        $existing[strtoupper($row['column_name'])] = true;
    }

    foreach ($columns as $col) {
        if (!isset($existing[strtoupper($col['name'])])) {
            $sql = "ALTER TABLE " . quote_identifier($tableName) . " ADD COLUMN " . quote_identifier($col['name']) . " " . $col['type'] . " NULL";
            $pdo->exec($sql);
            $actions[] = "Coluna {$col['name']} adicionada.";
            sync_log("[INFO] Coluna {$tableName}.{$col['name']} adicionada.");
        }
    }

    // Verificar chave primária
    if (!empty($primaryKeys)) {
        $stmt = $pdo->prepare("SELECT column_name FROM information_schema.key_column_usage WHERE table_schema = ? AND table_name = ? AND constraint_name = 'PRIMARY' ORDER BY ordinal_position");
        $stmt->execute([DB_NAME, $tableName]);
        $existingPK = [];
        while ($row = $stmt->fetch()) {
            $existingPK[] = strtoupper($row['column_name']);
        }
        $desiredPK = array_map('strtoupper', $primaryKeys);

        if (empty($existingPK) && !empty($desiredPK)) {
            try {
                $pkCols = implode(', ', array_map('quote_identifier', $primaryKeys));
                $pdo->exec("ALTER TABLE " . quote_identifier($tableName) . " ADD PRIMARY KEY ($pkCols)");
                $actions[] = "Chave primária adicionada: " . implode(', ', $primaryKeys);
            } catch (Exception $e) {
                $actions[] = "Aviso: não foi possível adicionar PK: " . $e->getMessage();
            }
        }
    }

    json_response([
        'status'  => 'ok',
        'table'   => $tableName,
        'actions' => $actions,
    ]);
}

// ============================================================
// Ação: sync (principal)
// ============================================================
if ($action === 'sync') {
    $tableName = isset($body['table']) ? trim($body['table']) : '';
    $columns   = isset($body['columns']) ? $body['columns'] : [];
    $rows      = isset($body['rows']) ? $body['rows'] : [];

    if (!$tableName || !is_array($columns) || count($columns) === 0) {
        json_error('Parâmetros inválidos para sync. Necessário: table, columns[], rows[].');
    }

    if (count($rows) > MAX_ROWS_PER_REQUEST) {
        json_error("Número de registros (" . count($rows) . ") excede o limite de " . MAX_ROWS_PER_REQUEST . ".");
    }

    $pdo = get_pdo();

    // Monta o REPLACE INTO
    $quotedCols = implode(', ', array_map('quote_identifier', $columns));
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $sql = "REPLACE INTO " . quote_identifier($tableName) . " ($quotedCols) VALUES ($placeholders)";

    $rowCount = 0;
    $errors = [];

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare($sql);

        foreach ($rows as $index => $row) {
            if (!is_array($row) || count($row) !== count($columns)) {
                $errors[] = "Linha $index: número de valores não corresponde ao número de colunas.";
                continue;
            }
            try {
                $stmt->execute(array_values($row));
                $rowCount++;
            } catch (PDOException $e) {
                $errors[] = "Linha $index: " . $e->getMessage();
            }
        }

        $pdo->commit();
    } catch (Exception $e) {
        try { $pdo->rollBack(); } catch (Exception $re) {}
        json_error("Erro na transação: " . $e->getMessage(), 500);
    }

    $result = [
        'status'         => count($errors) > 0 ? 'partial' : 'ok',
        'table'          => $tableName,
        'rows_received'  => count($rows),
        'rows_processed' => $rowCount,
    ];
    if (!empty($errors)) {
        $result['errors'] = array_slice($errors, 0, 50); // Limita erros retornados
    }

    sync_log("[INFO] Sync $tableName: recebidos=" . count($rows) . " processados=$rowCount erros=" . count($errors));
    json_response($result);
}

// ============================================================
// Ação: truncate
// ============================================================
if ($action === 'truncate') {
    $tableName = isset($body['table']) ? trim($body['table']) : '';
    $confirm   = isset($body['confirm']) ? $body['confirm'] : false;

    if (!$tableName) {
        json_error('Parâmetro "table" é obrigatório para truncate.');
    }
    if ($confirm !== true && $confirm !== 'true') {
        json_error('Parâmetro "confirm" deve ser true para executar truncate.');
    }

    $pdo = get_pdo();
    try {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $pdo->exec("TRUNCATE TABLE " . quote_identifier($tableName));
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        sync_log("[INFO] Tabela $tableName truncada via API.");
        json_response(['status' => 'ok', 'message' => "Tabela $tableName truncada com sucesso."]);
    } catch (Exception $e) {
        json_error("Erro ao truncar $tableName: " . $e->getMessage(), 500);
    }
}

// ============================================================
// Ação: swap (troca atômica de tabela: from -> to via RENAME TABLE)
// ============================================================
if ($action === 'swap') {
    $from = isset($body['from']) ? trim($body['from']) : '';
    $to   = isset($body['to'])   ? trim($body['to'])   : '';

    if (!$from || !$to) {
        json_error('swap requer os parâmetros "from" e "to".');
    }

    $pdo = get_pdo();
    try {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // A origem (tabela temporária) precisa existir.
        $stmt = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1");
        $stmt->execute([DB_NAME, $from]);
        if (!$stmt->fetch()) {
            json_error("Tabela de origem '$from' não existe para swap.", 500);
        }

        // O destino existe?
        $stmt = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ? LIMIT 1");
        $stmt->execute([DB_NAME, $to]);
        $toExists = (bool) $stmt->fetch();

        $old = substr('__qsync_old_' . md5($to), 0, 60);
        $pdo->exec("DROP TABLE IF EXISTS " . quote_identifier($old));

        if ($toExists) {
            // Troca atômica: destino atual sai e a temporária entra no lugar, numa só operação.
            $pdo->exec("RENAME TABLE " . quote_identifier($to) . " TO " . quote_identifier($old) . ", "
                       . quote_identifier($from) . " TO " . quote_identifier($to));
            $pdo->exec("DROP TABLE IF EXISTS " . quote_identifier($old));
        } else {
            $pdo->exec("RENAME TABLE " . quote_identifier($from) . " TO " . quote_identifier($to));
        }

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        sync_log("[INFO] Swap atômico $from -> $to concluído.");
        json_response(['status' => 'ok', 'from' => $from, 'to' => $to]);
    } catch (Exception $e) {
        json_error("Erro no swap $from -> $to: " . $e->getMessage(), 500);
    }
}

// ============================================================
// Ação desconhecida
// ============================================================
json_error("Ação desconhecida: '$action'. Ações válidas: ping, create_table, sync, truncate, swap.");
