#!/usr/bin/env node
/**
 * ============================================
 *  🔑 GERADOR DE LICENÇAS - Fast Food Bot
 *  Ferramenta do ADMINISTRADOR
 * ============================================
 * 
 * USO:
 *   node gerar-licenca.js
 *   (modo interativo - pergunta WHID, contra-chave e data)
 * 
 *   node gerar-licenca.js --whid XXXX-XXXX-XXXX-XXXX --contra-chave XXXXXXXX --expira 2026-03-19
 *   (modo direto via argumentos)
 * 
 * O WHID e a CONTRA-CHAVE são fornecidos pelo cliente.
 * A DATA DE EXPIRAÇÃO é definida por você.
 * A LICENÇA gerada deve ser enviada ao cliente para ativação.
 */

const crypto = require('crypto');
const readline = require('readline');

// ─── MESMA CHAVE SECRETA DO MÓDULO DE LICENÇA DO BOT ───────────
const SECRET_KEY = 'FFB@2024#S3cR3t!K3y$LiC3nS3';
const CIPHER_ALGO = 'aes-256-cbc';

// ─── FUNÇÕES DE CRIPTOGRAFIA ────────────────────────────────────

function derivarChave(whid) {
  return crypto.scryptSync(SECRET_KEY + whid, 'fastfood-bot-salt', 32);
}

function gerarContraChaveEsperada(whid) {
  const hash = crypto.createHmac('sha256', SECRET_KEY)
    .update(whid)
    .update('CONTRA-CHAVE')
    .digest('hex');
  return hash.substring(0, 8).toUpperCase();
}

function gerarLicenca(whid, contraChave, dataExpiracao) {
  // Validar WHID (formato XXXX-XXXX-XXXX-XXXX)
  const whidRegex = /^[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$/;
  if (!whidRegex.test(whid.toUpperCase())) {
    throw new Error('WHID inválido. Formato esperado: XXXX-XXXX-XXXX-XXXX (hexadecimal)');
  }
  whid = whid.toUpperCase();

  // Validar contra-chave
  const contraChaveEsperada = gerarContraChaveEsperada(whid);
  if (contraChave.toUpperCase() !== contraChaveEsperada) {
    throw new Error(`Contra-chave inválida para este WHID!\nEsperada: ${contraChaveEsperada}\nRecebida: ${contraChave.toUpperCase()}`);
  }

  // Validar data
  const expira = new Date(dataExpiracao + 'T23:59:59');
  if (isNaN(expira.getTime())) {
    throw new Error('Data inválida. Use o formato AAAA-MM-DD (ex: 2026-03-19)');
  }

  const agora = new Date();
  if (expira <= agora) {
    throw new Error('A data de expiração deve ser no futuro!');
  }

  // Montar payload da licença
  const payload = JSON.stringify({
    whid: whid,
    contraChave: contraChave.toUpperCase(),
    expiraEm: expira.toISOString(),
    criadoEm: agora.toISOString(),
    versao: '1.0',
  });

  // Criptografar
  const key = derivarChave(whid);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(CIPHER_ALGO, key, iv);
  let encrypted = cipher.update(payload, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  // Formato final: IV:ENCRYPTED
  const licenseKey = `${iv.toString('hex')}:${encrypted}`;

  // Calcular dias
  const diffMs = expira - agora;
  const dias = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  return {
    licenca: licenseKey,
    whid,
    expiraEm: dataExpiracao,
    diasValidade: dias,
  };
}

// ─── INTERFACE INTERATIVA ───────────────────────────────────────

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function pergunta(texto) {
  return new Promise((resolve) => {
    rl.question(texto, (resposta) => {
      resolve(resposta.trim());
    });
  });
}

async function modoInterativo() {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║   🔑 GERADOR DE LICENÇAS - Fast Food Bot    ║');
  console.log('║   Ferramenta do Administrador                ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║                                              ║');
  console.log('║  Informe os dados fornecidos pelo cliente    ║');
  console.log('║  para gerar a licença de ativação.           ║');
  console.log('║                                              ║');
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');

  try {
    const whid = await pergunta('📋 WHID do cliente (ex: A1B2-C3D4-E5F6-7890): ');
    const contraChave = await pergunta('🔐 Contra-Chave do cliente (ex: 1A2B3C4D): ');
    const dataExpiracao = await pergunta('📅 Data de expiração (AAAA-MM-DD, ex: 2026-03-19): ');

    console.log('\n⏳ Gerando licença...\n');

    const resultado = gerarLicenca(whid, contraChave, dataExpiracao);

    console.log('╔══════════════════════════════════════════════╗');
    console.log('║   ✅ LICENÇA GERADA COM SUCESSO!            ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log(`║  WHID:       ${resultado.whid}              `);
    console.log(`║  Expira em:  ${resultado.expiraEm}                    `);
    console.log(`║  Validade:   ${resultado.diasValidade} dias                        `);
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  LICENÇA (copie e envie ao cliente):        ║');
    console.log('╚══════════════════════════════════════════════╝');
    console.log('');
    console.log('─── INÍCIO DA LICENÇA ───');
    console.log(resultado.licenca);
    console.log('─── FIM DA LICENÇA ───');
    console.log('');
    console.log('📋 Instrua o cliente a colar esta licença no');
    console.log('   Painel Admin > Licença > campo "Chave de Licença"');
    console.log('');

  } catch (error) {
    console.error(`\n❌ ERRO: ${error.message}\n`);
  }

  rl.close();
}

// ─── MODO ARGUMENTOS ────────────────────────────────────────────

function modoArgumentos() {
  const args = process.argv.slice(2);
  const params = {};

  for (let i = 0; i < args.length; i += 2) {
    const key = args[i].replace('--', '');
    const value = args[i + 1];
    params[key] = value;
  }

  if (!params.whid || !params['contra-chave'] || !params.expira) {
    console.error('❌ Parâmetros obrigatórios: --whid, --contra-chave, --expira');
    console.error('   Exemplo: node gerar-licenca.js --whid A1B2-C3D4-E5F6-7890 --contra-chave 1A2B3C4D --expira 2026-03-19');
    process.exit(1);
  }

  try {
    const resultado = gerarLicenca(params.whid, params['contra-chave'], params.expira);
    console.log('\n✅ Licença gerada com sucesso!');
    console.log(`WHID: ${resultado.whid}`);
    console.log(`Expira: ${resultado.expiraEm}`);
    console.log(`Validade: ${resultado.diasValidade} dias`);
    console.log(`\nLICENÇA:\n${resultado.licenca}\n`);
  } catch (error) {
    console.error(`\n❌ ERRO: ${error.message}\n`);
    process.exit(1);
  }
}

// ─── EXECUÇÃO ───────────────────────────────────────────────────

if (process.argv.length > 2 && process.argv[2].startsWith('--')) {
  modoArgumentos();
} else {
  modoInterativo();
}
