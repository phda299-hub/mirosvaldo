@echo off
cd /d "%~dp0"
start cmd /k node servidor.js
timeout /t 2 > nul
start http://localhost:3001
