/**
 * ============================================================
 *  EXTRATOR DE PEDIDOS + CARRINHO (CONVERSACIONAL)
 * ============================================================
 * Analisa o histórico da conversa para:
 *   1. Manter o CARRINHO atualizado a cada turno (itens que o
 *      cliente já confirmou por escuta).
 *   2. Detectar quando o pedido foi FINALIZADO e extrair os
 *      dados estruturados para salvar no banco de dados.
 * ============================================================
 */

const { pedidos, clientes } = require('../database/db');
const { buscarProdutosNoCardapio } = require('./produtoSearch');
const { obterRespostaIA } = require('./aiEngine');

// Frase-gatilho que a Lara diz ao finalizar (definida no system prompt)
const GATILHO_FINALIZACAO = 'enviado para a cozinha';

/**
 * Sincroniza o carrinho a partir do histórico da conversa.
 * Retorna a lista de itens que o cliente JÁ confirmou até agora.
 *
 * Estratégia: usa a IA para extrair apenas os itens confirmados,
 * validando cada um contra o cardápio real (para pegar o preço).
 *
 * @param {Array} historico - Histórico completo da conversa
 * @returns {Promise<Array|null>} - [{nome, quantidade, preco}] ou null
 */
async function sincronizarCarrinho(historico) {
  if (!historico || historico.length === 0) return null;

  const promptCarrinho = `
Você é um extrator de dados. Analise a conversa e devolva APENAS os itens que o
CLIENTE JÁ CONFIRMOU explicitamente que quer (disse "sim", "isso", "quero", "pode ser" etc.).
NÃO inclua itens que a atendente apenas perguntou e o cliente ainda não confirmou.
NÃO invente itens. Se nada foi confirmado, responda exatamente: NULL

Responda somente com JSON no formato:
{"itens":[{"nome":"Nome do item","quantidade":1}]}

CONVERSA:
${historico.map(m => `${m.role === 'user' ? 'CLIENTE' : 'ATENDENTE'}: ${m.content}`).join('\n')}
`;

  try {
    const resposta = await obterRespostaIA(promptCarrinho, [], 'Você é um extrator de dados JSON preciso. Responda só com JSON ou NULL.');
    if (!resposta || resposta.toUpperCase().includes('NULL')) return [];

    const jsonMatch = resposta.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return [];

    const dados = JSON.parse(jsonMatch[0]);
    if (!dados.itens || !Array.isArray(dados.itens)) return [];

    // Validar cada item contra o cardápio real para obter preço correto
    const carrinho = [];
    for (const item of dados.itens) {
      if (!item.nome) continue;
      const matches = buscarProdutosNoCardapio(item.nome);
      const produto = matches && matches.length > 0 ? matches[0] : null;
      carrinho.push({
        nome: produto ? produto.nome : item.nome,
        quantidade: Number(item.quantidade) > 0 ? Number(item.quantidade) : 1,
        preco: produto ? produto.preco : (Number(item.preco) || 0),
      });
    }
    return carrinho;
  } catch (err) {
    console.error('[Extractor] Erro ao sincronizar carrinho:', err.message);
    return null;
  }
}

/**
 * Verifica se a última mensagem da Lara contém o gatilho de finalização
 */
function pedidoFoiFinalizado(historico) {
  const ultimaLara = [...historico].reverse().find(m => m.role === 'assistant');
  if (!ultimaLara) return false;
  const texto = ultimaLara.content.toLowerCase();
  return texto.includes(GATILHO_FINALIZACAO) || texto.includes('pedido confirmado');
}

/**
 * Tenta extrair um pedido FINALIZADO da conversa usando a IA.
 * Só roda quando a Lara já disparou o gatilho de finalização.
 *
 * @param {Array} historico - Histórico completo da conversa
 * @param {Array} carrinho - Carrinho atual da sessão (fallback)
 * @returns {Promise<Object|null>} - Dados do pedido ou null
 */
async function extrairPedidoDaConversa(historico, carrinho = []) {
  if (!pedidoFoiFinalizado(historico)) return null;

  const promptExtracao = `
Analise o histórico de conversa abaixo e extraia os dados do pedido FINALIZADO no formato JSON.
Se não houver um pedido claro e confirmado, responda apenas "NULL".

FORMATO JSON ESPERADO:
{
  "itens": [
    {"nome": "Nome do Produto", "quantidade": 1, "preco": 10.00}
  ],
  "endereco": "Endereço completo (ou 'Retirada' se não informado)",
  "forma_pagamento": "PIX, Cartão ou Dinheiro",
  "total": 0.00
}

HISTÓRICO:
${historico.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n')}
`;

  try {
    const resposta = await obterRespostaIA(promptExtracao, [], 'Você é um extrator de dados JSON preciso.');
    if (resposta && resposta.toUpperCase().includes('NULL')) {
      return montarPedidoDoCarrinho(carrinho);
    }

    const jsonMatch = resposta.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const dados = JSON.parse(jsonMatch[0]);
      if (dados.itens && dados.itens.length > 0) return dados;
    }
    // Fallback: usar o carrinho da sessão
    return montarPedidoDoCarrinho(carrinho);
  } catch (err) {
    console.error('[Extractor] Erro ao extrair pedido:', err.message);
    return montarPedidoDoCarrinho(carrinho);
  }
}

/**
 * Monta um pedido a partir do carrinho da sessão (fallback confiável)
 */
function montarPedidoDoCarrinho(carrinho) {
  if (!carrinho || carrinho.length === 0) return null;
  const total = carrinho.reduce((acc, i) => acc + (i.preco || 0) * (i.quantidade || 1), 0);
  return {
    itens: carrinho.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0 })),
    endereco: 'A combinar',
    forma_pagamento: 'A combinar',
    total,
  };
}

/**
 * Salva o pedido extraído no banco de dados
 */
async function salvarPedidoConversacional(telefone, dadosPedido, nomeCliente) {
  try {
    const cliente = clientes.criarOuAtualizar(telefone, { nome: nomeCliente });

    const total = dadosPedido.total ||
      (dadosPedido.itens || []).reduce((acc, i) => acc + (i.preco || 0) * (i.quantidade || 1), 0);

    const pedidoFinal = {
      cliente_id: cliente.id,
      telefone: telefone,
      nome_cliente: nomeCliente,
      endereco: dadosPedido.endereco || 'Retirada / A combinar',
      itens: dadosPedido.itens,
      total: total,
      subtotal: total,
      forma_pagamento: dadosPedido.forma_pagamento || 'A combinar',
      status: 'pendente'
    };

    const novoPedido = pedidos.criar(pedidoFinal);
    console.log(`✅ [${telefone}] Pedido conversacional registrado: ${novoPedido.codigo}`);
    return novoPedido;
  } catch (err) {
    console.error('[Extractor] Erro ao salvar pedido:', err.message);
    return null;
  }
}

module.exports = {
  sincronizarCarrinho,
  pedidoFoiFinalizado,
  extrairPedidoDaConversa,
  salvarPedidoConversacional
};
