/**
 * ============================================================
 *  EXTRATOR DE PEDIDOS (CONVERSACIONAL)
 * ============================================================
 * Analisa o histórico da conversa para identificar se um
 * pedido foi concluído e extrai os dados estruturados para
 * salvar no banco de dados.
 * ============================================================
 */

const { pedidos, clientes, produtos } = require('../database/db');
const { obterRespostaIA } = require('./aiEngine');

/**
 * Tenta extrair um pedido da conversa usando a própria IA
 *
 * @param {Array} historico - Histórico completo da conversa
 * @returns {Promise<Object|null>} - Dados do pedido ou null
 */
async function extrairPedidoDaConversa(historico) {
  // Só tentamos extrair se a última mensagem da Lara indicar confirmação
  const ultimaLara = [...historico].reverse().find(m => m.role === 'assistant');
  if (!ultimaLara || !ultimaLara.content.toLowerCase().includes('confirmado') && !ultimaLara.content.toLowerCase().includes('enviado para a cozinha')) {
    return null;
  }

  const promptExtracao = `
Analise o histórico de conversa abaixo e extraia os dados do pedido no formato JSON.
Se não houver um pedido claro e confirmado, responda apenas "NULL".

FORMATO JSON ESPERADO:
{
  "itens": [
    {"nome": "Nome do Produto", "quantidade": 1, "preco": 10.00}
  ],
  "endereco": "Endereço completo",
  "forma_pagamento": "PIX, Cartão ou Dinheiro",
  "total": 0.00
}

HISTÓRICO:
${historico.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n')}
`;

  try {
    const resposta = await obterRespostaIA(promptExtracao, [], "Você é um extrator de dados JSON preciso.");
    if (resposta.includes('NULL')) return null;

    const jsonMatch = resposta.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (err) {
    console.error('[Extractor] Erro ao extrair pedido:', err.message);
  }

  return null;
}

/**
 * Salva o pedido extraído no banco de dados
 */
async function salvarPedidoConversacional(telefone, dadosPedido, nomeCliente) {
  try {
    const cliente = clientes.criarOuAtualizar(telefone, { nome: nomeCliente });

    const pedidoFinal = {
      cliente_id: cliente.id,
      telefone: telefone,
      nome_cliente: nomeCliente,
      endereco: dadosPedido.endereco || 'Retirada / A combinar',
      itens: dadosPedido.itens,
      total: dadosPedido.total,
      subtotal: dadosPedido.total,
      forma_pagamento: dadosPedido.forma_pagamento || 'A combinar',
      status: 'pendente'
    };

    const novoPedido = pedidos.criar(pedidoFinal);
    console.log(`✅ [${telefone}] Pedido conversacional registrado: ${novoPedido.codigo}`);
    return novoPedido;
  } catch (err) {
    console.error('[Extractor] Erro ao salvar pedido:', err.message);
    return null;
  }
}

module.exports = {
  extrairPedidoDaConversa,
  salvarPedidoConversacional
};
