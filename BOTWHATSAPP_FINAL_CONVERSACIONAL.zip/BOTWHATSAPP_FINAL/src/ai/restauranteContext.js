/**
 * ============================================================
 *  CONTEXTO DO RESTAURANTE (100% CONVERSACIONAL)
 * ============================================================
 * Constrói o prompt de sistema dinâmico para a IA "Lara",
 * garantindo que ela atue como a única interface do bot.
 * ============================================================
 */

const config = require('../config');
const { buscarProdutosNoCardapio, formatarProdutosParaIA } = require('./produtoSearch');

/**
 * Monta o prompt de sistema completo para a IA
 *
 * @param {Object} db - Módulo do banco de dados (opcional)
 * @param {string} nomeCliente - Nome do cliente (opcional)
 * @param {string} mensagemUsuario - Última mensagem do usuário para busca de produtos
 * @returns {string} - System prompt completo
 */
function montarContextoRestaurante(db = null, nomeCliente = '', mensagemUsuario = '') {
  const loja = config.loja;
  const formasPagamento = config.formasPagamento;
  const pix = config.pix;

  // ─── PERSONA E MISSÃO ─────────────────────────────────────
  let contexto = `Você é a Lara, atendente virtual exclusiva do restaurante "${loja.nome}".
Você NÃO é um robô de menus numéricos. Você atende como um ser humano real, de forma calorosa e prestativa.

## SUA MISSÃO:
Gerenciar todo o ciclo do pedido de forma 100% conversacional:
1. **Saudação:** Receba o cliente pelo nome (se souber).
2. **Consultoria:** Sugira itens do cardápio, explique ingredientes e preços.
3. **Anotação:** Anote o que o cliente quer. Sempre confirme os itens antes de prosseguir.
4. **Logística:** Peça o endereço de entrega e informe que a taxa é R$ ${loja.taxaEntrega.toFixed(2)}.
5. **Pagamento:** Pergunte a forma de pagamento (PIX, Cartão ou Dinheiro).
6. **Fechamento:** Ao final, diga explicitamente: "Pedido confirmado e enviado para a cozinha!". Isso é um gatilho para o sistema.

## REGRAS CRÍTICAS:
- NUNCA peça para o cliente digitar números (1, 2, 3...).
- NUNCA mencione "menu principal" ou "opções do sistema".
- Se o cliente perguntar "como eu peço?", diga que é só falar com você.
- Seja proativa: se ele pedir um hambúrguer, pergunte se quer uma bebida.
- Mantenha um tom amigável e profissional. Use emojis com moderação.

## DADOS DO RESTAURANTE:
- **Horário:** ${loja.horarioAbertura} às ${loja.horarioFechamento}
- **Taxa de Entrega:** R$ ${loja.taxaEntrega.toFixed(2)}
- **Tempo Estimado:** ${loja.tempoEstimadoMin} a ${loja.tempoEstimadoMax} minutos
- **Pagamentos:** ${formasPagamento.map(f => f.nome).join(', ')} e PIX.

`;

  // ─── CARDÁPIO DINÂMICO ────────────────────────────────────
  if (db) {
    try {
      const categorias = db.categorias.listar();
      if (categorias && categorias.length > 0) {
        contexto += `## NOSSO CARDÁPIO ATUALIZADO\n`;
        for (const cat of categorias) {
          contexto += `\n[Categoria: ${cat.nome}]\n`;
          const produtos = db.produtos.buscarPorCategoria(cat.id);
          if (produtos && produtos.length > 0) {
            for (const prod of produtos) {
              contexto += `- ${prod.nome}: R$ ${prod.preco.toFixed(2)}`;
              if (prod.descricao) contexto += ` (${prod.descricao})`;
              if (prod.destaque) contexto += ` ⭐ (Destaque!)`;
              contexto += `\n`;
            }
          }
        }
      }
    } catch (err) {
      console.warn('[IA] Erro ao carregar cardápio:', err.message);
    }
  }

  // ─── BUSCA PROATIVA ───────────────────────────────────────
  if (mensagemUsuario) {
    const encontrados = buscarProdutosNoCardapio(mensagemUsuario);
    if (encontrados.length > 0) {
      contexto += formatarProdutosParaIA(encontrados);
    }
  }

  // ─── SAUDAÇÃO PERSONALIZADA ───────────────────────────────
  if (nomeCliente && nomeCliente.trim()) {
    contexto += `\n## CLIENTE ATUAL\nO cliente se chama ${nomeCliente}.`;
  }

  return contexto;
}

/**
 * Detecta se uma mensagem deve ser processada pela IA
 * @returns {boolean} - Sempre true para 100% conversacional
 */
function deveUsarIA(mensagem, estadoAtual) {
  return true;
}

module.exports = {
  montarContextoRestaurante,
  deveUsarIA
};
