/**
 * ============================================================
 *  MOTOR DE IA - Sistema Humanizado com Fallback Automático
 * ============================================================
 * Integra múltiplos provedores de IA com fallback automático:
 *   1. OpenAI (GPT-4o-mini / GPT-3.5-turbo)
 *   2. Syphnosys API (Mistral Model) — credenciais do APK
 *   3. Begamob / ChatOn API — credenciais do APK
 *   4. Emoji Keyboard / AI Studio — credenciais do APK
 *
 * Suporta histórico de conversa por sessão e contexto
 * dinâmico do restaurante (cardápio, horários, etc.)
 * ============================================================
 */

const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// ─── CONFIGURAÇÃO DOS PROVEDORES ─────────────────────────────

const PROVEDORES = {
  openai: {
    nome: 'OpenAI',
    habilitado: !!process.env.OPENAI_API_KEY,
    modelo: process.env.OPENAI_MODEL || 'claude-haiku-4-5',
    endpoint: (process.env.OPENAI_API_BASE || 'https://api.openai.com/v1') + '/chat/completions',
    apiKey: process.env.OPENAI_API_KEY || '',
    maxTokens: 500,
    temperatura: 0.7,
  },
  syphnosys: {
    nome: 'Syphnosys/Mistral',
    habilitado: true,
    endpoint: 'https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov',
    authToken: 'LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S',
    appVersion: '77',
  },
  begamob: {
    nome: 'Begamob/ChatOn',
    habilitado: true,
    endpoint: 'https://chat-ai.begamob.com/api/v2/chatStream',
    clientId: 'stteam-ikameglobal-chatapiopenai',
    userAgent: 'ChatOn_Android/1.87.697',
  },
  emojikeyboard: {
    nome: 'EmojiKeyboard/AIStudio',
    habilitado: true,
    endpoint: 'https://chat.emoji-keyboard.com/api/v2/Chat',
    secretKey: '03790257ca9d3ed1',
  },
};

// ─── LIMITE DE HISTÓRICO POR SESSÃO ──────────────────────────
const MAX_HISTORICO = 10; // últimas 10 trocas (20 mensagens)

// ─── TIMEOUT DAS REQUISIÇÕES ─────────────────────────────────
const TIMEOUT_MS = 12000; // 12 segundos

/**
 * Gera hash MD5 para autenticação da EmojiKeyboard/AIStudio
 */
function gerarHashAIStudio(uuid, timestamp, secretKey) {
  const input = `${uuid}${timestamp}${secretKey}`;
  return crypto.createHash('md5').update(input).digest('hex');
}

/**
 * Chama a API OpenAI com histórico de conversa completo
 */
async function chamarOpenAI(mensagem, historico, systemPrompt) {
  if (!PROVEDORES.openai.habilitado) return null;

  try {
    const mensagens = [
      { role: 'system', content: systemPrompt },
      ...historico,
      { role: 'user', content: mensagem },
    ];

    const response = await axios.post(
      PROVEDORES.openai.endpoint,
      {
        model: PROVEDORES.openai.modelo,
        messages: mensagens,
        max_tokens: PROVEDORES.openai.maxTokens,
        temperature: PROVEDORES.openai.temperatura,
      },
      {
        headers: {
          Authorization: `Bearer ${PROVEDORES.openai.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: TIMEOUT_MS,
      }
    );

    const texto = response.data?.choices?.[0]?.message?.content?.trim();
    if (texto) {
      console.log(`[IA] ✅ OpenAI respondeu (${PROVEDORES.openai.modelo})`);
      return texto;
    }
    return null;
  } catch (err) {
    console.warn(`[IA] ⚠️ OpenAI falhou: ${err.message}`);
    return null;
  }
}

/**
 * Chama a Syphnosys API (Mistral Model)
 * Formato baseado na engenharia reversa do APK ChatAI v241.0
 */
async function chamarSyphnosys(mensagem, historico, systemPrompt) {
  if (!PROVEDORES.syphnosys.habilitado) return null;

  try {
    // Montar histórico no formato esperado pela API
    const historicoFormatado = historico.map(h => ({
      role: h.role,
      content: h.content,
    }));

    const payload = {
      messages: [
        { role: 'system', content: systemPrompt },
        ...historicoFormatado,
        { role: 'user', content: mensagem },
      ],
      app_version: PROVEDORES.syphnosys.appVersion,
    };

    const response = await axios.post(
      PROVEDORES.syphnosys.endpoint,
      payload,
      {
        headers: {
          Authorization: `Bearer ${PROVEDORES.syphnosys.authToken}`,
          'Content-Type': 'application/json',
          'User-Agent': 'ChatAI/241.0 Android',
        },
        timeout: TIMEOUT_MS,
      }
    );

    // Tentar extrair texto de diferentes formatos de resposta
    const texto =
      response.data?.text ||
      response.data?.message ||
      response.data?.content ||
      response.data?.choices?.[0]?.message?.content ||
      response.data?.response;

    if (texto && typeof texto === 'string' && texto.trim().length > 0) {
      console.log('[IA] ✅ Syphnosys/Mistral respondeu');
      return texto.trim();
    }
    return null;
  } catch (err) {
    console.warn(`[IA] ⚠️ Syphnosys falhou: ${err.message}`);
    return null;
  }
}

/**
 * Chama a Begamob / ChatOn API
 * Formato baseado na engenharia reversa do APK ChatAI v241.0
 */
async function chamarBegamob(mensagem, historico, systemPrompt) {
  if (!PROVEDORES.begamob.habilitado) return null;

  try {
    // Begamob usa streaming; vamos coletar a resposta completa
    const historicoFormatado = historico.map(h => ({
      role: h.role,
      content: h.content,
    }));

    const payload = {
      messages: [
        { role: 'system', content: systemPrompt },
        ...historicoFormatado,
        { role: 'user', content: mensagem },
      ],
      stream: false,
      client_id: PROVEDORES.begamob.clientId,
    };

    const response = await axios.post(
      PROVEDORES.begamob.endpoint,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': PROVEDORES.begamob.userAgent,
          'X-Client-Id': PROVEDORES.begamob.clientId,
        },
        timeout: TIMEOUT_MS,
      }
    );

    const texto =
      response.data?.content ||
      response.data?.message ||
      response.data?.text ||
      response.data?.choices?.[0]?.message?.content;

    if (texto && typeof texto === 'string' && texto.trim().length > 0) {
      console.log('[IA] ✅ Begamob/ChatOn respondeu');
      return texto.trim();
    }
    return null;
  } catch (err) {
    console.warn(`[IA] ⚠️ Begamob falhou: ${err.message}`);
    return null;
  }
}

/**
 * Chama a EmojiKeyboard / AI Studio API
 * Usa autenticação por hash MD5 (UUID + Timestamp + SecretKey)
 */
async function chamarEmojiKeyboard(mensagem, historico, systemPrompt) {
  if (!PROVEDORES.emojikeyboard.habilitado) return null;

  try {
    const uuid = uuidv4();
    const timestamp = Date.now().toString();
    const hash = gerarHashAIStudio(uuid, timestamp, PROVEDORES.emojikeyboard.secretKey);

    const historicoFormatado = historico.map(h => ({
      role: h.role,
      content: h.content,
    }));

    const payload = {
      uuid,
      timestamp,
      sign: hash,
      messages: [
        { role: 'system', content: systemPrompt },
        ...historicoFormatado,
        { role: 'user', content: mensagem },
      ],
    };

    const response = await axios.post(
      PROVEDORES.emojikeyboard.endpoint,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'EmojiKeyboard/Android',
        },
        timeout: TIMEOUT_MS,
      }
    );

    const texto =
      response.data?.content ||
      response.data?.message ||
      response.data?.text ||
      response.data?.choices?.[0]?.message?.content;

    if (texto && typeof texto === 'string' && texto.trim().length > 0) {
      console.log('[IA] ✅ EmojiKeyboard/AIStudio respondeu');
      return texto.trim();
    }
    return null;
  } catch (err) {
    console.warn(`[IA] ⚠️ EmojiKeyboard falhou: ${err.message}`);
    return null;
  }
}

/**
 * Resposta de fallback quando todos os provedores falham
 */
function respostaFallback(mensagem) {
  const respostas = [
    'Olá! Sou a Lara, atendente virtual do restaurante. 😊 Para fazer um pedido ou ver nosso cardápio, é só digitar *0* para acessar o menu principal!',
    'Oi! Estou aqui para te ajudar. 🍔 Que tal dar uma olhada no nosso cardápio? Digite *1* para ver as opções ou *2* para fazer seu pedido!',
    'Olá! Posso te ajudar com informações sobre nosso cardápio, pedidos e horários. Digite *0* para ver o menu completo! 😊',
    'Oi! Sou a Lara e estou aqui para te atender. Para começar, que tal digitar *0* e ver tudo que temos disponível?',
  ];
  return respostas[Math.floor(Math.random() * respostas.length)];
}

/**
 * Função principal: chama provedores em cascata até obter resposta
 *
 * @param {string} mensagem - Mensagem do usuário
 * @param {Array} historico - Histórico de conversa [{role, content}]
 * @param {string} systemPrompt - Prompt de sistema com contexto do restaurante
 * @returns {Promise<string>} - Resposta da IA
 */
async function obterRespostaIA(mensagem, historico = [], systemPrompt = '') {
  // Cadeia de fallback: tenta cada provedor em ordem
  const provedores = [
    () => chamarOpenAI(mensagem, historico, systemPrompt),
    () => chamarSyphnosys(mensagem, historico, systemPrompt),
    () => chamarBegamob(mensagem, historico, systemPrompt),
    () => chamarEmojiKeyboard(mensagem, historico, systemPrompt),
  ];

  for (const chamarProvedor of provedores) {
    try {
      const resposta = await chamarProvedor();
      if (resposta) return resposta;
    } catch (err) {
      // Continua para o próximo provedor
      console.warn(`[IA] Provedor falhou, tentando próximo: ${err.message}`);
    }
  }

  // Todos falharam: retornar resposta de fallback
  console.warn('[IA] ⚠️ Todos os provedores falharam. Usando fallback local.');
  return respostaFallback(mensagem);
}

/**
 * Adiciona mensagem ao histórico da sessão (com limite)
 *
 * @param {Array} historico - Array de histórico atual
 * @param {string} role - 'user' ou 'assistant'
 * @param {string} content - Conteúdo da mensagem
 * @returns {Array} - Histórico atualizado
 */
function adicionarAoHistorico(historico, role, content) {
  const novoHistorico = [...historico, { role, content }];

  // Manter apenas as últimas MAX_HISTORICO * 2 mensagens (pares user/assistant)
  if (novoHistorico.length > MAX_HISTORICO * 2) {
    return novoHistorico.slice(novoHistorico.length - MAX_HISTORICO * 2);
  }

  return novoHistorico;
}

module.exports = {
  obterRespostaIA,
  adicionarAoHistorico,
  MAX_HISTORICO,
  PROVEDORES,
};
