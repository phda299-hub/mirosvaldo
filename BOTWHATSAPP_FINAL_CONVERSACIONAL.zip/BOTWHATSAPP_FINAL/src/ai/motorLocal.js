/**
 * ============================================================
 *  MOTOR CONVERSACIONAL LOCAL (SEM DEPENDÊNCIA DE IA EXTERNA)
 * ============================================================
 * Usado como cérebro do bot quando NENHUM provedor de IA
 * (OpenAI/Mistral/etc.) está disponível.
 *
 * Reproduz de forma determinística o comportamento pedido:
 *   - NUNCA oferece o cardápio nem pede para "digitar" nada.
 *   - Escuta as palavras do cliente e, se lembrarem um item do
 *     cardápio, PERGUNTA se é aquilo.
 *   - Só coloca no carrinho quando o cliente CONFIRMA.
 *   - Depois pergunta se ele quer mais alguma coisa.
 *   - Só mostra o cardápio se o cliente PEDIR explicitamente.
 * ============================================================
 */

const config = require('../config');
const { produtos, categorias } = require('../database/db');

// ─── DICIONÁRIOS DE INTENÇÃO ─────────────────────────────────
const RE_SIM = /\b(sim|isso|isso mesmo|é isso|e isso|eh isso|isso ai|isso aí|pode ser|pode|aham|ahan|claro|exato|exatamente|isso mesmo|correto|positivo|ok|okay|blz|beleza|com certeza|perfeito|quero sim|esse|essa|esse mesmo)\b/i;
const RE_NAO = /\b(n[ãa]o|nao|nops|nem|negativo|errado|esquece|deixa|outro|outra|nada disso|nenhum)\b/i;
const RE_CARDAPIO = /(card[aá]pio|cardapio|\bmenu\b|o que (voc[êe]s?\s*)?(t[eê]m|tem|servem|vende[m]?|possuem)|op[çc][õo]es|o que tem|quais (s[ãa]o|as op)|lista de pre[çc]o|tabela|manda o card)/i;
const RE_FINALIZAR = /(s[óo] isso|so isso|é s[óo]|eh so|e so|fechar( a conta| o pedido)?|fechou|finalizar|pode fechar|encerrar|mais nada|nada mais|era s[óo]|era so|pode enviar|manda(r)? o pedido|s[óo] is'?so|to satisfeito|chega)/i;
const RE_SAUDACAO = /\b(oi+|ol[áa]|ola|e a[íi]|eai|opa|bom dia|boa tarde|boa noite|tudo bem|tudo bom|fala|salve|boa)\b/i;
const RE_AGRADECE = /\b(obrigad[oa]|valeu|vlw|agrade[çc]o|grato|brigad[oa])\b/i;

// Palavras que NÃO devem disparar busca de produto
const STOPWORDS = new Set([
  'oi','ola','ola','opa','eai','salve','bom','boa','dia','tarde','noite','tudo','bem','bom',
  'sim','nao','isso','esse','essa','pode','ser','aham','claro','exato','ok','okay','blz','beleza',
  'quero','queria','gostaria','vou','var','uma','um','uns','umas','dois','duas','tres','quero',
  'de','da','do','das','dos','com','sem','por','favor','pra','para','me','ve','ver','manda','mandar',
  'que','tem','ai','aqui','entao','tipo','acho','talvez','e','ou','ta','to','estou','com','fome',
  'obrigado','obrigada','valeu','vlw','entrega','pedido','conta','fechar','isso','mesmo','the','and',
]);

function normalizar(txt) {
  return (txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function saudacaoHora() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return 'Bom dia';
  if (h >= 12 && h < 18) return 'Boa tarde';
  return 'Boa noite';
}

function extrairQuantidade(texto) {
  const m = normalizar(texto).match(/\b(\d{1,2})\b/);
  if (m) {
    const q = parseInt(m[1], 10);
    if (q >= 1 && q <= 50) return q;
  }
  const mapa = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5 };
  const norm = normalizar(texto);
  for (const [k, v] of Object.entries(mapa)) {
    if (new RegExp(`\\b${k}\\b`).test(norm)) return v;
  }
  return 1;
}

/**
 * Busca itens do cardápio por PALAVRAS INTEIRAS no NOME do produto
 * (ignora descrição para evitar falsos positivos como "ola" em "cebola").
 * Retorna lista ordenada por relevância.
 */
function procurarItens(texto) {
  const norm = normalizar(texto);
  const alvo = norm.replace(/[^a-z0-9]+/g, ' ').trim();
  const tokens = alvo.split(/\s+/).filter(t => t.length >= 3 && !STOPWORDS.has(t));
  if (tokens.length === 0) return [];

  const lista = produtos.listar();
  const nomesCategorias = (categorias.listar() || []).map(c => ({ id: c.id, nome: normalizar(c.nome) }));

  const scored = lista.map(p => {
    const pnome = normalizar(p.nome);
    const pwords = pnome.split(/[^a-z0-9]+/).filter(Boolean);
    let score = 0;

    for (const t of tokens) {
      if (pwords.includes(t)) score += 3;             // palavra inteira no nome
      else if (t.length >= 4 && pnome.includes(t)) score += 1; // parte relevante
    }
    // bônus por correspondência exata de nome
    const pnomeAlvo = pnome.replace(/[^a-z0-9]+/g, ' ').trim();
    if (pnomeAlvo === alvo) score += 10;
    // bônus por categoria citada (ex.: "pizza", "batata", "refrigerante")
    const cat = nomesCategorias.find(c => tokens.includes(c.nome) || c.nome.split(/\s+/).some(w => tokens.includes(w)));
    if (cat && p.categoria_id === cat.id) score += 1;

    return { p, score };
  }).filter(x => x.score > 0);

  scored.sort((a, b) => b.score - a.score);

  // Se há uma correspondência claramente melhor (exata), retorna só ela
  if (scored.length > 0 && scored[0].score >= 10) {
    return [scored[0].p];
  }
  return scored.slice(0, 4).map(x => x.p);
}

function resumoCarrinho(carrinho) {
  if (!carrinho || carrinho.length === 0) return '';
  let total = 0;
  const linhas = carrinho.map(i => {
    const sub = (i.preco || 0) * (i.quantidade || 1);
    total += sub;
    return `• ${i.quantidade}x ${i.nome} — R$ ${sub.toFixed(2)}`;
  });
  return `${linhas.join('\n')}\n*Total: R$ ${total.toFixed(2)}*`;
}

function montarCardapio() {
  try {
    const cats = categorias.listar();
    if (!cats || cats.length === 0) return 'No momento estou sem o cardápio à mão, mas me diz o que você tem vontade de comer que eu vejo pra você! 😊';
    let txt = 'Claro! Olha o que temos:\n';
    for (const c of cats) {
      const prods = produtos.buscarPorCategoria(c.id);
      if (!prods || prods.length === 0) continue;
      txt += `\n*${c.nome}*\n`;
      prods.forEach(p => { txt += `• ${p.nome} — R$ ${p.preco.toFixed(2)}\n`; });
    }
    txt += '\nÉ só me dizer o que você quer que eu já anoto! 😊';
    return txt.trim();
  } catch (e) {
    return 'Me diz o que você tem vontade de comer que eu confiro pra você! 😊';
  }
}

/**
 * Processa a mensagem do cliente de forma local (sem IA externa).
 *
 * @param {string} mensagem - Texto do cliente
 * @param {Object} session - Sessão do cliente (mutável)
 * @returns {{ texto: string, finalizar: boolean, dadosPedido: (Object|null) }}
 */
function responder(mensagem, session) {
  const texto = (mensagem || '').trim();
  const low = normalizar(texto);

  if (!session.carrinho) session.carrinho = [];
  if (session.aguardandoConfirmacao === undefined) session.aguardandoConfirmacao = null;
  if (session.aguardandoEscolha === undefined) session.aguardandoEscolha = null;
  if (!session.faseFinalizacao) session.faseFinalizacao = null;

  const nome = (session.nomeCliente || '').split(' ')[0];
  const trata = nome ? `, ${nome}` : '';

  // ─── FASE DE FINALIZAÇÃO (endereço → pagamento) ───────────
  if (session.faseFinalizacao === 'endereco') {
    session.pedidoAtual = session.pedidoAtual || {};
    session.pedidoAtual.endereco = texto;
    session.faseFinalizacao = 'pagamento';
    const formas = config.formasPagamento.map(f => f.nome).join(', ');
    return R(`Anotei o endereço! E como você prefere pagar? (${formas})`);
  }
  if (session.faseFinalizacao === 'pagamento') {
    session.pedidoAtual = session.pedidoAtual || {};
    session.pedidoAtual.formaPagamento = texto;
    const carrinho = session.carrinho;
    const totalItens = carrinho.reduce((a, i) => a + (i.preco || 0) * (i.quantidade || 1), 0);
    const total = totalItens + config.loja.taxaEntrega;
    const dadosPedido = {
      itens: carrinho.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0 })),
      endereco: session.pedidoAtual.endereco || 'A combinar',
      forma_pagamento: texto,
      total,
    };
    session.faseFinalizacao = null;
    session.aguardandoConfirmacao = null;
    session.aguardandoEscolha = null;
    return {
      texto: `Perfeito${trata}! Seu pedido ficou assim:\n\n${resumoCarrinho(carrinho)}\n_(+ taxa de entrega R$ ${config.loja.taxaEntrega.toFixed(2)})_\n\nPedido confirmado e enviado para a cozinha! 🍳 Chega em torno de ${config.loja.tempoEstimadoMin}-${config.loja.tempoEstimadoMax} min. Obrigado! 🙏`,
      finalizar: true,
      dadosPedido,
    };
  }

  // ─── AGUARDANDO CONFIRMAÇÃO DE UM ITEM (sim/não) ──────────
  if (session.aguardandoConfirmacao) {
    const item = session.aguardandoConfirmacao;
    if (RE_SIM.test(low) && !RE_NAO.test(low)) {
      const qtd = item.quantidade || extrairQuantidade(low);
      session.carrinho.push({ nome: item.nome, quantidade: qtd, preco: item.preco });
      session.aguardandoConfirmacao = null;
      return R(`Anotado, ${qtd}x ${item.nome}! 😊 Mais alguma coisa?`);
    }
    if (RE_NAO.test(low)) {
      session.aguardandoConfirmacao = null;
      const outros = procurarItens(texto);
      if (outros.length === 0) return R(`Sem problema! Me diz o que você gostaria então. 😊`);
      // se ele já citou outro item, cai no fluxo de busca abaixo
    } else if (!RE_SIM.test(low)) {
      const outros = procurarItens(texto);
      if (outros.length === 0) {
        return R(`Só pra confirmar: você quer o *${item.nome}* (R$ ${item.preco.toFixed(2)})? 😊`);
      }
      session.aguardandoConfirmacao = null; // ele citou outra coisa
    }
  }

  // ─── AGUARDANDO ESCOLHA ENTRE VÁRIAS OPÇÕES ───────────────
  if (session.aguardandoEscolha && session.aguardandoEscolha.length > 0) {
    const escolhido = session.aguardandoEscolha.find(p => {
      const pn = normalizar(p.nome);
      const pwords = pn.split(/[^a-z0-9]+/).filter(w => w.length >= 3);
      return low.includes(pn) || pwords.some(w => new RegExp(`\\b${w}\\b`).test(low));
    });
    if (escolhido) {
      const qtd = extrairQuantidade(low);
      session.carrinho.push({ nome: escolhido.nome, quantidade: qtd, preco: escolhido.preco });
      session.aguardandoEscolha = null;
      session.aguardandoConfirmacao = null;
      return R(`Anotado, ${qtd}x ${escolhido.nome}! 😊 Mais alguma coisa?`);
    }
    // Se disse "sim" genérico, assume a primeira opção
    if (RE_SIM.test(low)) {
      const p = session.aguardandoEscolha[0];
      const qtd = extrairQuantidade(low);
      session.carrinho.push({ nome: p.nome, quantidade: qtd, preco: p.preco });
      session.aguardandoEscolha = null;
      return R(`Anotado, ${qtd}x ${p.nome}! 😊 Mais alguma coisa?`);
    }
    session.aguardandoEscolha = null; // não identificou; segue fluxo normal
  }

  // ─── CLIENTE PEDIU O CARDÁPIO EXPLICITAMENTE ──────────────
  if (RE_CARDAPIO.test(low)) {
    return R(montarCardapio());
  }

  // ─── CLIENTE QUER FECHAR O PEDIDO ─────────────────────────
  if (RE_FINALIZAR.test(low)) {
    if (session.carrinho.length === 0) {
      return R(`Você ainda não escolheu nada${trata}. Me diz o que você gostaria? 😊`);
    }
    session.faseFinalizacao = 'endereco';
    return R(`Show! Seu pedido até agora:\n\n${resumoCarrinho(session.carrinho)}\n\nPra onde eu mando a entrega? (me passa o endereço) 🛵`);
  }

  // ─── BUSCA POR ITENS NO QUE O CLIENTE FALOU ───────────────
  const encontrados = procurarItens(texto);

  if (encontrados.length === 1) {
    const p = encontrados[0];
    const qtd = extrairQuantidade(low);
    session.aguardandoConfirmacao = { nome: p.nome, preco: p.preco, quantidade: qtd };
    const qtdTxt = qtd > 1 ? `${qtd}x ` : '';
    return R(`Você quer dizer o *${qtdTxt}${p.nome}* (R$ ${p.preco.toFixed(2)})? 😊`);
  }
  if (encontrados.length > 1) {
    session.aguardandoEscolha = encontrados;
    const nomes = encontrados.slice(0, 4).map(p => `*${p.nome}* (R$ ${p.preco.toFixed(2)})`).join(' ou ');
    return R(`Você quer dizer ${nomes}? Qual deles? 😊`);
  }

  // ─── NENHUM ITEM RECONHECIDO: CONVERSA NATURAL ────────────
  if (RE_AGRADECE.test(low)) return R(`Imagina${trata}! Precisando é só chamar. 😊`);
  if (RE_SAUDACAO.test(low)) return R(`${saudacaoHora()}${trata}! Como posso te ajudar? 😊`);

  // Fallback final: passivo, sem oferecer cardápio nem mandar digitar
  return R(`Pode me dizer o que você tem vontade de pedir que eu vejo pra você${trata}. 😊`);
}

// helper para resposta simples
function R(texto) {
  return { texto, finalizar: false, dadosPedido: null };
}

module.exports = { responder, procurarItens };
