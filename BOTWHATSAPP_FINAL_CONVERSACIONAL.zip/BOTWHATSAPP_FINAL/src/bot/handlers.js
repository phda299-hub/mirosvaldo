/**
 * ============================================================
 *  HANDLERS DE MENSAGENS (100% CONVERSACIONAL)
 * ============================================================
 * Gerencia o fluxo de mensagens roteando tudo para a IA Lara.
 * O menu estruturado foi removido para uma experiência humana.
 * ============================================================
 */

const dayjs = require('dayjs');
const sessionManager = require('./session');
const { obterRespostaIA } = require('../ai/aiEngine');
const { montarContextoRestaurante } = require('../ai/restauranteContext');
const { categorias, produtos, clientes, pedidos } = require('../database/db');
const EventEmitter = require('events');

const botEvents = new EventEmitter();

/**
 * Processador principal de mensagens
 */
async function processarMensagem(telefone, msg, pushName) {
  const session = sessionManager.get(telefone);
  const msgLower = msg.toLowerCase().trim();

  // ─── COMANDO GLOBAL DE RESET (Útil para testes) ──────────────
  if (msgLower === 'reset' || msgLower === 'reiniciar') {
    sessionManager.reset(telefone);
    sessionManager.limparHistoricoIA(telefone);
    return '🔄 Conversa reiniciada! Como posso te ajudar?';
  }

  // ─── ROTA ÚNICA: 100% IA CONVERSACIONAL ─────────────────────
  // A IA Lara gerencia todo o atendimento, desde dúvidas até pedidos.
  return await processarComIA(telefone, msg, session, pushName);
}

/**
 * Processa mensagem com IA, mantendo histórico de conversa
 */
async function processarComIA(telefone, mensagem, session, pushName) {
  try {
    // Obter histórico de conversa da sessão
    const historico = sessionManager.obterHistoricoIA(telefone);

    // Montar contexto dinâmico do restaurante
    const nomeCliente = session.nomeCliente || pushName || '';
    const db = { categorias, produtos };
    const systemPrompt = montarContextoRestaurante(db, nomeCliente, mensagem);

    // Adicionar mensagem do usuário ao histórico
    sessionManager.adicionarHistoricoIA(telefone, 'user', mensagem);

    // Chamar motor de IA com fallback automático
    const resposta = await obterRespostaIA(mensagem, historico, systemPrompt);

    // Adicionar resposta da IA ao histórico
    sessionManager.adicionarHistoricoIA(telefone, 'assistant', resposta);

    // Tentar extrair pedido em segundo plano se a conversa parecer finalizada
    // O extrator analisa se a Lara confirmou o pedido no histórico
    const { extrairPedidoDaConversa, salvarPedidoConversacional } = require('../ai/orderExtractor');
    
    // Execução assíncrona para não travar a resposta ao cliente
    extrairPedidoDaConversa(sessionManager.obterHistoricoIA(telefone))
      .then(async (dados) => {
        if (dados) {
          const novoPedido = await salvarPedidoConversacional(telefone, dados, nomeCliente);
          if (novoPedido) {
            botEvents.emit('novoPedido', novoPedido);
            console.log(`[IA] Pedido #${novoPedido.codigo} registrado via conversa.`);
          }
        }
      })
      .catch(e => console.error('[IA] Erro na extração de pedido:', e.message));

    return resposta;
  } catch (err) {
    console.error('[IA] Erro ao processar com IA:', err.message);
    sessionManager.reset(telefone);
    return "Desculpe, tive um probleminha técnico. Poderia repetir o que você deseja?";
  }
}

/**
 * Utilitário de saudação
 */
function getSaudacao() {
  const hora = dayjs().hour();
  if (hora >= 5 && hora < 12) return 'Bom dia';
  if (hora >= 12 && hora < 18) return 'Boa tarde';
  return 'Boa noite';
}

module.exports = {
  processarMensagem,
  botEvents
};
