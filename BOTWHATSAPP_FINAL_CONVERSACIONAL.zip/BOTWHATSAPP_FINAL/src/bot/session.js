/**
 * ============================================
 *  GERENCIADOR DE SESSÕES DE CONVERSA
 *  (Otimizado para performance + Histórico IA)
 * ============================================
 * Controla o estado da conversa de cada cliente
 * com limite de memória e expiração eficiente.
 *
 * Inclui histórico de conversa para a IA manter
 * contexto entre mensagens do mesmo cliente.
 */

const MAX_HISTORICO_IA = 20; // máximo de mensagens no histórico (10 pares)

class SessionManager {
  constructor() {
    this.sessions = new Map();
    this.TIMEOUT = 30 * 60 * 1000;     // 30 minutos de inatividade
    this.MAX_SESSIONS = 5000;            // Limite máximo de sessões em memória
    this._cleanupCounter = 0;
    this._CLEANUP_INTERVAL = 100;        // Limpar a cada 100 acessos
  }

  /**
   * Obter ou criar sessão do cliente
   */
  get(telefone) {
    // Limpeza periódica leve (a cada N acessos)
    if (++this._cleanupCounter >= this._CLEANUP_INTERVAL) {
      this._cleanupCounter = 0;
      this._limparSeNecessario();
    }

    let session = this.sessions.get(telefone);
    if (!session) {
      session = this._criarSessao(telefone);
      this.sessions.set(telefone, session);
    }
    session.ultimaInteracao = Date.now();
    return session;
  }

  /**
   * Resetar sessão do cliente (volta ao menu principal)
   * Preserva o histórico de IA para manter contexto
   */
  reset(telefone) {
    const sessionAnterior = this.sessions.get(telefone);
    const session = this._criarSessao(telefone);

    // Preservar histórico de IA ao resetar (o cliente ainda é o mesmo)
    if (sessionAnterior && sessionAnterior.historicoIA) {
      session.historicoIA = sessionAnterior.historicoIA;
    }
    // Preservar nome do cliente
    if (sessionAnterior && sessionAnterior.nomeCliente) {
      session.nomeCliente = sessionAnterior.nomeCliente;
    }
    // Preservar carrinho conversacional (mesmo cliente, mesma conversa)
    if (sessionAnterior && sessionAnterior.carrinho) {
      session.carrinho = sessionAnterior.carrinho;
    }

    this.sessions.set(telefone, session);
    return session;
  }

  /**
   * Atualizar estado da sessão
   */
  update(telefone, dados) {
    const session = this.get(telefone);
    Object.assign(session, dados);
    return session;
  }

  /**
   * Adicionar mensagem ao histórico de IA da sessão
   *
   * @param {string} telefone - Número do cliente
   * @param {string} role - 'user' ou 'assistant'
   * @param {string} content - Conteúdo da mensagem
   */
  adicionarHistoricoIA(telefone, role, content) {
    const session = this.get(telefone);
    if (!session.historicoIA) session.historicoIA = [];

    session.historicoIA.push({ role, content });

    // Manter apenas as últimas MAX_HISTORICO_IA mensagens
    if (session.historicoIA.length > MAX_HISTORICO_IA) {
      session.historicoIA = session.historicoIA.slice(
        session.historicoIA.length - MAX_HISTORICO_IA
      );
    }
  }

  /**
   * Obter histórico de IA da sessão
   *
   * @param {string} telefone - Número do cliente
   * @returns {Array} - Array de mensagens [{role, content}]
   */
  obterHistoricoIA(telefone) {
    const session = this.get(telefone);
    return session.historicoIA || [];
  }

  /**
   * Limpar histórico de IA da sessão
   *
   * @param {string} telefone - Número do cliente
   */
  limparHistoricoIA(telefone) {
    const session = this.get(telefone);
    session.historicoIA = [];
  }

  /**
   * Obter carrinho conversacional (itens já confirmados pelo cliente)
   *
   * @param {string} telefone - Número do cliente
   * @returns {Array} - [{nome, quantidade, preco}]
   */
  obterCarrinho(telefone) {
    const session = this.get(telefone);
    return session.carrinho || [];
  }

  /**
   * Substituir o carrinho da sessão pelo estado mais recente
   *
   * @param {string} telefone - Número do cliente
   * @param {Array} itens - Lista de itens confirmados
   */
  definirCarrinho(telefone, itens) {
    const session = this.get(telefone);
    session.carrinho = Array.isArray(itens) ? itens : [];
    return session.carrinho;
  }

  /**
   * Limpar o carrinho da sessão (ex.: após o pedido ser enviado)
   *
   * @param {string} telefone - Número do cliente
   */
  limparCarrinho(telefone) {
    const session = this.get(telefone);
    session.carrinho = [];
  }

  /**
   * Criar sessão padrão (objeto leve)
   */
  _criarSessao(telefone) {
    return {
      telefone,
      estado: 'menu_principal',
      subEstado: null,
      pedidoAtual: {
        itens: [],
        observacao: '',
        endereco: '',
        complemento: '',
        referencia: '',
        formaPagamento: '',
        trocoPara: 0,
        nomeCliente: '',
      },
      categoriaAtual: null,
      produtoSelecionado: null,
      quantidadeSelecionada: 1,
      aguardandoResposta: false,
      ultimaInteracao: Date.now(),
      primeiroContato: true,
      historicoIA: [],           // Histórico de conversa para a IA
      carrinho: [],              // Itens confirmados pelo cliente (carrinho conversacional)
      nomeCliente: '',           // Nome do cliente para personalização
    };
  }

  /**
   * Limpeza condicional: só executa se necessário
   */
  _limparSeNecessario() {
    if (this.sessions.size <= this.MAX_SESSIONS * 0.8) return;
    this.limparExpiradas();
  }

  /**
   * Limpar sessões expiradas
   */
  limparExpiradas() {
    const agora = Date.now();
    const limite = agora - this.TIMEOUT;

    for (const [telefone, session] of this.sessions) {
      if (session.ultimaInteracao < limite) {
        this.sessions.delete(telefone);
      }
    }

    // Se ainda acima do limite, remover as mais antigas
    if (this.sessions.size > this.MAX_SESSIONS) {
      const entries = [...this.sessions.entries()]
        .sort((a, b) => a[1].ultimaInteracao - b[1].ultimaInteracao);
      const toRemove = entries.slice(0, this.sessions.size - this.MAX_SESSIONS);
      for (const [telefone] of toRemove) {
        this.sessions.delete(telefone);
      }
    }
  }

  /**
   * Obter contagem de sessões ativas (para monitoramento)
   */
  get count() {
    return this.sessions.size;
  }
}

module.exports = new SessionManager();
