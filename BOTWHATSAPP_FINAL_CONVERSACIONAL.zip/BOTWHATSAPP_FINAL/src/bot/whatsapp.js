/**
 * ============================================
 *  CONEXÃO WHATSAPP - Baileys
 *  (Otimizado para performance)
 * ============================================
 */

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const path = require('path');
const fs = require('fs');
const { processarMensagem, botEvents } = require('./handlers');
const { processarAudio } = require('./audioHandler');

const AUTH_DIR = path.join(__dirname, '..', '..', 'data', 'auth');

let sock = null;
let qrCode = null;
let connectionStatus = 'disconnected';
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;

// Logger silencioso para produção
const logger = pino({ level: 'silent' });

// ─── FILA DE MENSAGENS (evita processamento concorrente por usuário) ──

const processingQueue = new Map();

async function enfileirarMensagem(telefone, texto, pushName, remoteJid) {
  // Se já está processando para este telefone, aguardar
  const pendente = processingQueue.get(telefone);
  if (pendente) {
    await pendente;
  }

  const promise = (async () => {
    try {
      const resposta = await processarMensagem(telefone, texto, pushName);
      if (resposta && sock && connectionStatus === 'connected') {
        await sock.sendMessage(remoteJid, { text: resposta });
        console.log(`📤 [${telefone}] Bot: ${resposta.substring(0, 80)}...`);
      }
    } catch (error) {
      console.error(`❌ Erro ao processar [${telefone}]:`, error.message);
    } finally {
      processingQueue.delete(telefone);
    }
  })();

  processingQueue.set(telefone, promise);
  return promise;
}

/**
 * Iniciar conexão com WhatsApp
 */
async function iniciarWhatsApp(io) {
  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, logger),
      },
      printQRInTerminal: true,
      logger,
      browser: ['FastFood Bot', 'Chrome', '22.0'],
      generateHighQualityLinkPreview: false,
      syncFullHistory: false,
      markOnlineOnConnect: true,
    });

    // ─── EVENTOS DE CONEXÃO ─────────────────────

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        qrCode = qr;
        connectionStatus = 'qr_ready';
        console.log('\n📱 QR Code gerado! Escaneie com seu WhatsApp.');
        console.log('🌐 Ou acesse o painel admin para escanear.\n');
        if (io) {
          io.emit('qr', qr);
          io.emit('status', { status: 'qr_ready', message: 'QR Code pronto para escanear' });
        }
      }

      if (connection === 'close') {
        const statusCode = (lastDisconnect?.error)?.output?.statusCode;

        connectionStatus = 'disconnected';
        if (io) io.emit('status', { status: 'disconnected', message: 'Desconectado' });

        console.log(`❌ Conexão fechada. Código: ${statusCode}`);

        if (statusCode === DisconnectReason.loggedOut) {
          console.log('🔒 Sessão encerrada. Removendo credenciais...');
          if (fs.existsSync(AUTH_DIR)) {
            fs.rmSync(AUTH_DIR, { recursive: true, force: true });
          }
          reconnectAttempts = 0;
          setTimeout(() => iniciarWhatsApp(io), 3000);
        } else if (reconnectAttempts < MAX_RECONNECT) {
          reconnectAttempts++;
          const delay = Math.min(reconnectAttempts * 2000, 30000);
          console.log(`🔄 Reconectando em ${delay / 1000}s... (tentativa ${reconnectAttempts}/${MAX_RECONNECT})`);
          setTimeout(() => iniciarWhatsApp(io), delay);
        } else {
          console.log('❌ Máximo de tentativas de reconexão atingido.');
          if (io) io.emit('status', { status: 'error', message: 'Falha na reconexão. Reinicie o sistema.' });
        }
      }

      if (connection === 'open') {
        connectionStatus = 'connected';
        reconnectAttempts = 0;
        qrCode = null;
        console.log('✅ WhatsApp conectado com sucesso!');
        if (io) io.emit('status', { status: 'connected', message: 'WhatsApp conectado!' });
      }
    });

    sock.ev.on('creds.update', saveCreds);

    // ─── RECEBER MENSAGENS ──────────────────────

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;

      for (const msg of messages) {
        // Ignorar mensagens próprias, de grupo e de status
        if (msg.key.fromMe) continue;
        const remoteJid = msg.key.remoteJid;
        if (!remoteJid || remoteJid.endsWith('@g.us') || remoteJid === 'status@broadcast') continue;

        // Extrair texto da mensagem (ou áudio)
        let texto = extrairTexto(msg);
        
        // Se for áudio, tentar transcrever
        if (!texto && msg.message?.audioMessage) {
          console.log(`🎙️ [${remoteJid}] Recebido áudio, transcrevendo...`);
          texto = await processarAudio(msg);
        }

        if (!texto) continue;

        const telefone = remoteJid.replace('@s.whatsapp.net', '');
        const pushName = msg.pushName || '';

        console.log(`📩 [${telefone}] ${pushName}: ${texto}`);

        // Processar via fila (evita condição de corrida)
        enfileirarMensagem(telefone, texto, pushName, remoteJid);
      }
    });

    return sock;
  } catch (error) {
    console.error('❌ Erro ao iniciar WhatsApp:', error);
    if (reconnectAttempts < MAX_RECONNECT) {
      reconnectAttempts++;
      setTimeout(() => iniciarWhatsApp(io), 5000);
    }
  }
}

/**
 * Extrair texto de diferentes tipos de mensagem
 */
function extrairTexto(msg) {
  const message = msg.message;
  if (!message) return null;

  return message.conversation
    || message.extendedTextMessage?.text
    || message.buttonsResponseMessage?.selectedButtonId
    || message.listResponseMessage?.singleSelectReply?.selectedRowId
    || message.templateButtonReplyMessage?.selectedId
    || null;
}

/**
 * Enviar mensagem para um número
 */
async function enviarMensagem(telefone, texto) {
  if (!sock || connectionStatus !== 'connected') {
    throw new Error('WhatsApp não está conectado');
  }
  const jid = telefone.includes('@') ? telefone : `${telefone}@s.whatsapp.net`;
  await sock.sendMessage(jid, { text: texto });
}

/**
 * Obter status da conexão
 */
function getStatus() {
  return {
    status: connectionStatus,
    qrCode,
  };
}

/**
 * Desconectar
 */
async function desconectar() {
  if (sock) {
    await sock.logout();
    sock = null;
  }
  connectionStatus = 'disconnected';
}

module.exports = {
  iniciarWhatsApp,
  enviarMensagem,
  getStatus,
  desconectar,
  botEvents,
};
