/**
 * ============================================
 *  CONFIGURAÇÕES DO BOT - FAST FOOD WHATSAPP
 *  (Com IA Humanizada "Lara" Integrada)
 * ============================================
 * Edite este arquivo para personalizar seu bot
 */

const os = require('os');

/**
 * Detecta automaticamente a interface da impressora
 * com base no sistema operacional.
 *
 * WINDOWS - Duas opções (em ordem de prioridade):
 *
 *   Opção 1 (Recomendada - sem instalação extra):
 *     Compartilhe a impressora no Windows e use o caminho de rede:
 *     '//localhost/NOME_DO_COMPARTILHAMENTO'
 *
 *     Como compartilhar:
 *     1. Painel de Controle > Dispositivos e Impressoras
 *     2. Clique direito na impressora > Propriedades de impressora
 *     3. Aba "Compartilhamento" > Marcar "Compartilhar esta impressora"
 *     4. Anote o nome do compartilhamento (ex: "MP-4200 TH")
 *     5. Use aqui: '//localhost/MP-4200 TH'
 *
 *   Opção 2 (Alternativa - envia RAW direto pela porta USB):
 *     Usa child_process para enviar dados diretamente para a porta USB.
 *     Configure: 'raw:USB001' (ou a porta da sua impressora)
 *     Verifique a porta em: Propriedades da impressora > Portas
 *
 * LINUX:
 *     '/dev/usb/lp0' (padrão para USB)
 *
 * REDE (qualquer SO):
 *     'tcp://192.168.1.100:9100'
 */
function detectarInterfaceImpressora() {
  if (os.platform() === 'win32') {
    return '//localhost/MP-4200 TH';
  }
  return '/dev/usb/lp0';
}

const config = {
  // ─── DADOS DA LOJA ───────────────────────────
  loja: {
    nome: '🍔 Fast Food Delivery',
    endereco: 'Rua Exemplo, 123 - Centro',
    telefone: '(00) 00000-0000',
    horarioAbertura: '10:00',
    horarioFechamento: '23:00',
    taxaEntrega: 5.00,
    tempoEstimadoMin: 30,
    tempoEstimadoMax: 50,
    pedidoMinimo: 15.00,
  },

  // ─── FORMAS DE PAGAMENTO ─────────────────────
  formasPagamento: [
    { id: 1, nome: 'Dinheiro', emoji: '💵', aceitaTroco: true },
    { id: 2, nome: 'PIX', emoji: '📱', aceitaTroco: false },
    { id: 3, nome: 'Cartão de Débito', emoji: '💳', aceitaTroco: false },
    { id: 4, nome: 'Cartão de Crédito', emoji: '💳', aceitaTroco: false },
  ],

  // ─── PIX ─────────────────────────────────────
  pix: {
    chave: '00.000.000/0001-00',
    tipo: 'CNPJ',
    titular: 'Fast Food Delivery LTDA',
  },

  // ─── IMPRESSORA TÉRMICA ──────────────────────
  impressora: {
    tipo: 'epson',
    interface: detectarInterfaceImpressora(),
    largura: 48,
    habilitada: true,
  },

  // ─── SERVIDOR WEB (PAINEL ADMIN) ─────────────
  servidor: {
    porta: 3000,
    senhaAdmin: '2394',
  },

  // ─── CONFIGURAÇÕES DE IA ─────────────────────
  // A IA "Lara" responde perguntas conversacionais de forma humanizada.
  // Provedores são tentados em cascata (fallback automático):
  //   1. OpenAI → 2. Syphnosys/Mistral → 3. Begamob/ChatOn → 4. EmojiKeyboard/AIStudio
  ai: {
    // Habilitar/desabilitar todo o sistema de IA
    habilitado: true,

    // Nome e persona da atendente virtual
    persona: {
      nome: 'Lara',
      descricao: 'Atendente virtual simpática e prestativa',
    },

    // ── Provedor 1: OpenAI (recomendado) ──────────────────────
    // Configure OPENAI_API_KEY no arquivo .env para usar este provedor
    openai: {
      habilitado: true, // Será desabilitado automaticamente se OPENAI_API_KEY não estiver definida
      modelo: 'claude-haiku-4-5',   // Modelos disponíveis: claude-haiku-4-5, gpt-4.1-mini, gemini-2.5-flash, gpt-4o-mini
      maxTokens: 500,
      temperatura: 0.7,
    },

    // ── Provedor 2: Syphnosys/Mistral (credenciais do APK ChatAI) ──
    syphnosys: {
      habilitado: true,
      endpoint: 'https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov',
      authToken: 'LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S',
      appVersion: '77',
    },

    // ── Provedor 3: Begamob/ChatOn (credenciais do APK ChatAI) ────
    begamob: {
      habilitado: true,
      endpoint: 'https://chat-ai.begamob.com/api/v2/chatStream',
      clientId: 'stteam-ikameglobal-chatapiopenai',
      userAgent: 'ChatOn_Android/1.87.697',
    },

    // ── Provedor 4: EmojiKeyboard/AI Studio (credenciais do APK) ──
    emojikeyboard: {
      habilitado: true,
      endpoint: 'https://chat.emoji-keyboard.com/api/v2/Chat',
      secretKey: '03790257ca9d3ed1',
    },
  },

  // ─── MENSAGENS PERSONALIZÁVEIS ───────────────
  mensagens: {
    boasVindas: `🍔 *Olá! Bem-vindo(a) ao {NOME_LOJA}!* 🍔

Estamos prontos para atender você! 😊

📋 *MENU PRINCIPAL:*
━━━━━━━━━━━━━━━━━━━━
*1* - 📖 Ver Cardápio
*2* - 🛒 Fazer Pedido
*3* - 📦 Acompanhar Pedido
*4* - 💰 Formas de Pagamento
*5* - 📍 Nosso Endereço
*6* - ⏰ Horário de Funcionamento
*7* - 📞 Falar com Atendente
━━━━━━━━━━━━━━━━━━━━

_Ou simplesmente me diga o que você precisa! 😊_`,

    lojaFechada: `⚠️ *Ops! Estamos fechados no momento.*

🕐 Nosso horário de funcionamento:
📅 *{HORARIO_ABERTURA} às {HORARIO_FECHAMENTO}*

Volte no nosso horário! 😊`,

    pedidoConfirmado: `✅ *PEDIDO CONFIRMADO!*

📋 Pedido: *#{NUMERO_PEDIDO}*
⏰ Previsão de entrega: *{TEMPO_ESTIMADO}*

Seu pedido está sendo preparado! 🍳
Avisaremos quando sair para entrega! 🏍️`,

    pedidoSaiuEntrega: `🏍️ *SEU PEDIDO SAIU PARA ENTREGA!*

📋 Pedido: *#{NUMERO_PEDIDO}*
⏰ Previsão de chegada: *{TEMPO_ESTIMADO}*

Aguarde em seu endereço! 😊`,

    pedidoEntregue: `✅ *PEDIDO ENTREGUE!*

📋 Pedido: *#{NUMERO_PEDIDO}*

Obrigado pela preferência! 🙏
Esperamos que goste! 😋

⭐ Avalie nosso atendimento de 1 a 5!`,
  },
};

module.exports = config;
