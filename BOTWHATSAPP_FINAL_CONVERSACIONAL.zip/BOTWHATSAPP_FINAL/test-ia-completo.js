/**
 * ============================================================
 *  TESTE COMPLETO DO SISTEMA DE IA HUMANIZADA
 * ============================================================
 * Testa todos os componentes do sistema:
 *  - Detecção de intenção (IA vs Menu Estruturado)
 *  - Motor de IA com fallback
 *  - Histórico de conversa por sessão
 *  - Contexto dinâmico do restaurante
 * ============================================================
 */

const { deveUsarIA, montarContextoRestaurante } = require('./src/ai/restauranteContext');
const { obterRespostaIA, PROVEDORES } = require('./src/ai/aiEngine');
const sessionManager = require('./src/bot/session');

// ─── CORES PARA OUTPUT ───────────────────────────────────────
const VERDE = '\x1b[32m';
const VERMELHO = '\x1b[31m';
const AMARELO = '\x1b[33m';
const AZUL = '\x1b[34m';
const RESET = '\x1b[0m';
const NEGRITO = '\x1b[1m';

let passados = 0;
let falhos = 0;

function testar(descricao, resultado, esperado) {
  if (resultado === esperado) {
    console.log(`${VERDE}✅ PASSOU${RESET} — ${descricao}`);
    passados++;
  } else {
    console.log(`${VERMELHO}❌ FALHOU${RESET} — ${descricao}`);
    console.log(`   Esperado: ${NEGRITO}${esperado}${RESET}`);
    console.log(`   Obtido:   ${NEGRITO}${resultado}${RESET}`);
    falhos++;
  }
}

// ─── TESTES DE DETECÇÃO DE INTENÇÃO ──────────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 1: DETECÇÃO DE INTENÇÃO (IA vs Menu)${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

// Mensagens que DEVEM ir para a IA
const casosIA = [
  ['Oi! Qual o hambúrguer mais vendido?', 'menu_principal'],
  ['Vocês têm hambúrguer vegetariano?', 'menu_principal'],
  ['Qual o horário de vocês?', 'menu_principal'],
  ['Aceita PIX?', 'menu_principal'],
  ['Boa tarde!', 'menu_principal'],
  ['Olá, tudo bem?', 'menu_principal'],
  ['Quanto custa o X-Burguer?', 'menu_principal'],
  ['Tem promoção hoje?', 'menu_principal'],
  ['Qual o hambúrguer mais barato?', 'menu_principal'],
  ['Vocês entregam no bairro Jardim?', 'menu_principal'],
  ['Qual a taxa de entrega?', 'menu_principal'],
  ['Tem opção sem glúten?', 'menu_principal'],
  ['Quero um x-bacon por favor', 'menu_principal'],
  ['Vocês tem coca cola?', 'menu_principal'],
];

// Mensagens que NÃO devem ir para a IA (menu estruturado)
const casosMenu = [
  ['1', 'menu_principal'],
  ['2', 'menu_principal'],
  ['0', 'menu_principal'],
  ['menu', 'menu_principal'],
  ['voltar', 'menu_principal'],
  ['cancelar', 'menu_principal'],
  ['v', 'ver_categoria'],
  ['f', 'fazer_pedido'],
  ['1', 'ver_cardapio'],
  ['2', 'selecionar_produto'],
  ['sim', 'confirmar_item'],
  ['n', 'observacao'],
];

console.log('Mensagens conversacionais (devem ir para IA):');
for (const [msg, estado] of casosIA) {
  testar(`"${msg}" (estado: ${estado})`, deveUsarIA(msg, estado), true);
}

console.log('\nComandos estruturados (NÃO devem ir para IA):');
for (const [msg, estado] of casosMenu) {
  testar(`"${msg}" (estado: ${estado})`, deveUsarIA(msg, estado), false);
}

// ─── TESTE DO HISTÓRICO DE SESSÃO ────────────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 2: HISTÓRICO DE CONVERSA POR SESSÃO${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

const telefoneTest = '5511999999999';

// Limpar sessão de teste
sessionManager.limparHistoricoIA(telefoneTest);

// Adicionar mensagens ao histórico
sessionManager.adicionarHistoricoIA(telefoneTest, 'user', 'Qual o hambúrguer mais vendido?');
sessionManager.adicionarHistoricoIA(telefoneTest, 'assistant', 'O X-Burguer Especial é o mais pedido!');
sessionManager.adicionarHistoricoIA(telefoneTest, 'user', 'Quanto custa?');
sessionManager.adicionarHistoricoIA(telefoneTest, 'assistant', 'Custa R$ 18,90.');

const historico = sessionManager.obterHistoricoIA(telefoneTest);

testar('Histórico tem 4 mensagens', historico.length, 4);
testar('Primeira mensagem é do usuário', historico[0].role, 'user');
testar('Segunda mensagem é do assistente', historico[1].role, 'assistant');
testar('Conteúdo da primeira mensagem', historico[0].content, 'Qual o hambúrguer mais vendido?');

// Testar preservação do histórico após reset
sessionManager.reset(telefoneTest);
const historicoAposReset = sessionManager.obterHistoricoIA(telefoneTest);
testar('Histórico preservado após reset', historicoAposReset.length, 4);

// Testar limite de histórico (MAX = 20 mensagens)
sessionManager.limparHistoricoIA(telefoneTest);
for (let i = 0; i < 25; i++) {
  sessionManager.adicionarHistoricoIA(telefoneTest, i % 2 === 0 ? 'user' : 'assistant', `Mensagem ${i}`);
}
const historicoLimitado = sessionManager.obterHistoricoIA(telefoneTest);
testar('Histórico limitado a 20 mensagens', historicoLimitado.length <= 20, true);

// ─── TESTE DO CONTEXTO DO RESTAURANTE ────────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 3: CONTEXTO DINÂMICO DO RESTAURANTE${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

const contexto = montarContextoRestaurante(null, 'João');

testar('Contexto contém nome da persona (Lara)', contexto.includes('Lara'), true);
testar('Contexto contém nome do cliente', contexto.includes('João'), true);
testar('Contexto contém horário de funcionamento', contexto.includes('10:00'), true);
testar('Contexto contém taxa de entrega', contexto.includes('5,00') || contexto.includes('5.00'), true);
testar('Contexto contém formas de pagamento', contexto.includes('PIX'), true);
testar('Contexto contém regras de atendimento', contexto.includes('REGRAS DE ATENDIMENTO'), true);
testar('Contexto menciona menu principal', contexto.includes('menu principal'), true);

// ─── TESTE DE BUSCA PROATIVA DE PRODUTOS ─────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 3.1: BUSCA PROATIVA DE PRODUTOS     ${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

const { buscarProdutosNoCardapio } = require('./src/ai/produtoSearch');
const encontrados = buscarProdutosNoCardapio('x-bacon');
testar('Busca encontrou X-Bacon', encontrados.some(p => p.nome.includes('X-Bacon')), true);

const contextoComBusca = montarContextoRestaurante(null, 'João', 'quero um x-bacon');
testar('Contexto contém produtos encontrados', contextoComBusca.includes('PRODUTOS ENCONTRADOS'), true);
testar('Contexto contém o produto específico', contextoComBusca.includes('X-Bacon'), true);

// ─── TESTE DOS PROVEDORES DE IA ───────────────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 4: PROVEDORES DE IA CONFIGURADOS   ${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

testar('Syphnosys configurado', !!PROVEDORES.syphnosys.endpoint, true);
testar('Begamob configurado', !!PROVEDORES.begamob.endpoint, true);
testar('EmojiKeyboard configurado', !!PROVEDORES.emojikeyboard.endpoint, true);
testar('Syphnosys token presente', PROVEDORES.syphnosys.authToken.startsWith('LIVE-'), true);
testar('Begamob clientId presente', !!PROVEDORES.begamob.clientId, true);
testar('EmojiKeyboard secretKey presente', PROVEDORES.emojikeyboard.secretKey.length === 16, true);

// ─── TESTE DE CHAMADA REAL À IA ──────────────────────────────

console.log(`\n${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}`);
console.log(`${AZUL}${NEGRITO}  TESTE 5: CHAMADA REAL AO MOTOR DE IA     ${RESET}`);
console.log(`${AZUL}${NEGRITO}═══════════════════════════════════════════${RESET}\n`);

console.log(`${AMARELO}⏳ Testando chamada real à IA (aguarde até 30s)...${RESET}\n`);

async function testarChamadaIA() {
  const systemPrompt = montarContextoRestaurante(null, 'Cliente Teste');
  const mensagemTeste = 'Qual o horário de funcionamento de vocês?';

  console.log(`📤 Enviando: "${mensagemTeste}"`);

  try {
    const resposta = await obterRespostaIA(mensagemTeste, [], systemPrompt);

    if (resposta && resposta.length > 10) {
      console.log(`${VERDE}✅ IA respondeu com sucesso!${RESET}`);
      console.log(`📥 Resposta: "${resposta.substring(0, 150)}${resposta.length > 150 ? '...' : ''}"`);
      passados++;
    } else {
      console.log(`${VERMELHO}❌ IA retornou resposta vazia ou muito curta${RESET}`);
      falhos++;
    }
  } catch (err) {
    console.log(`${VERMELHO}❌ Erro na chamada à IA: ${err.message}${RESET}`);
    falhos++;
  }

  // ─── RESUMO FINAL ─────────────────────────────────────────
  console.log(`\n${NEGRITO}═══════════════════════════════════════════${RESET}`);
  console.log(`${NEGRITO}  RESUMO DOS TESTES${RESET}`);
  console.log(`${NEGRITO}═══════════════════════════════════════════${RESET}`);
  console.log(`${VERDE}✅ Passados: ${passados}${RESET}`);
  console.log(`${VERMELHO}❌ Falhos:   ${falhos}${RESET}`);
  console.log(`📊 Total:    ${passados + falhos}`);

  const percentual = Math.round((passados / (passados + falhos)) * 100);
  console.log(`\n${percentual >= 80 ? VERDE : VERMELHO}${NEGRITO}Taxa de sucesso: ${percentual}%${RESET}\n`);

  if (percentual === 100) {
    console.log(`${VERDE}${NEGRITO}🎉 TODOS OS TESTES PASSARAM! Sistema pronto para uso.${RESET}\n`);
  } else if (percentual >= 80) {
    console.log(`${AMARELO}${NEGRITO}⚠️  A maioria dos testes passou. Verifique os falhos acima.${RESET}\n`);
  } else {
    console.log(`${VERMELHO}${NEGRITO}🚨 Muitos testes falharam. Verifique a configuração.${RESET}\n`);
  }
}

testarChamadaIA().catch(console.error);
