# 🍔 Fast Food WhatsApp Bot v1.0.0

## Sistema Profissional de Atendimento e Pedidos para WhatsApp

Este é um sistema completo e robusto, desenvolvido para automatizar o atendimento e a gestão de pedidos da sua loja de fast food diretamente pelo WhatsApp. Ele foi projetado para ser profissional, eficiente e fácil de usar, permitindo que você economize tempo e ofereça um serviço de alta qualidade aos seus clientes.

---

### ✨ Funcionalidades Principais

| Funcionalidade | Descrição |
| :--- | :--- |
| **Atendimento Automático 24/7** | O bot responde aos clientes instantaneamente, a qualquer hora do dia. |
| **Cardápio Digital Interativo** | Os clientes podem navegar pelas categorias e ver os produtos diretamente no WhatsApp. |
| **Sistema de Pedidos Completo** | O bot guia o cliente por todo o processo: seleção de itens, endereço, pagamento e observações. |
| **Painel Administrativo Web** | Uma interface gráfica completa para gerenciar pedidos, cardápio, clientes e configurações em tempo real. |
| **Impressão Automática** | Novos pedidos são enviados automaticamente para sua impressora térmica, sem necessidade de intervenção manual. |
| **Notificação Sonora** | Um alerta sonoro é emitido no seu computador sempre que um novo pedido chega, garantindo que você não perca nada. |
| **Gestão de Status** | Atualize o status do pedido (Confirmado, Em Preparo, Saiu para Entrega) e o cliente é notificado automaticamente. |
| **Base de Dados de Clientes** | O sistema salva o nome e o endereço dos clientes para agilizar pedidos futuros. |
| **Configuração Flexível** | Personalize facilmente o nome da loja, horário, taxa de entrega, formas de pagamento e muito mais. |
| **Sem Dependência de Celular** | Após escanear o QR Code, o bot funciona de forma independente, sem precisar que seu celular esteja online. |

---

### 🚀 Como Iniciar (Guia Rápido)

Siga estes 3 passos para colocar seu bot para funcionar:

#### Passo 1: Configuração Inicial

1.  **Abra o arquivo de configuração**: Navegue até a pasta `src` e abra o arquivo `config.js` em um editor de texto.
2.  **Edite os dados da sua loja**: Preencha as informações da sua loja, como nome, endereço, horário, taxa de entrega, etc.
3.  **Configure o pagamento PIX**: Se você aceita PIX, insira sua chave e os dados do titular.
4.  **Ajuste a impressora**: Configure o tipo da sua impressora (`epson`, `daruma`, etc.) e a interface de conexão (ex: `/dev/usb/lp0` no Linux ou o IP da sua impressora de rede).
5.  **Crie uma senha segura**: No mesmo arquivo, altere a `senhaAdmin` para uma senha forte de sua preferência. **Esta será a senha para acessar o painel administrativo.**

#### Passo 2: Executar o Sistema

1.  **Abra o terminal**: Navegue até a pasta principal do projeto (`fastfood-whatsapp-bot`).
2.  **Execute o comando de início**: Digite `npm start` e pressione Enter.
3.  O sistema será iniciado. O terminal exibirá uma mensagem de boas-vindas e começará o processo de conexão com o WhatsApp.

#### Passo 3: Conectar o WhatsApp e Acessar o Painel

1.  **Escaneie o QR Code**: Um QR Code será exibido no terminal. Abra o WhatsApp no seu celular, vá em `Aparelhos conectados` e escaneie o código.
2.  **Acesse o Painel Admin**: Abra seu navegador de internet (Chrome, Firefox, etc.) e acesse o endereço: **http://localhost:3000**
3.  **Faça o login**: Use a `senhaAdmin` que você definiu no arquivo de configuração para entrar.
4.  **Pronto!** Seu bot está online e o painel administrativo está pronto para ser usado. Você pode gerenciar tudo pelo navegador, inclusive ver o QR Code novamente se precisar.

---

### 📋 Manual de Uso do Painel Administrativo

O painel foi projetado para ser intuitivo. Aqui está um resumo de cada seção:

*   **Dashboard**: Visão geral do seu dia, com estatísticas de faturamento, total de pedidos e status dos pedidos em andamento.
*   **Pedidos**: A tela principal para gestão. Aqui você pode ver os pedidos chegando em tempo real, confirmar, cancelar e atualizar o status de cada um.
*   **Cardápio**: Adicione, edite, remova e organize suas categorias e produtos. Você pode marcar um produto como "indisponível" com um único clique.
*   **Clientes**: Veja a lista de clientes que já fizeram pedidos, com seus dados de contato e endereço salvos.
*   **WhatsApp**: Verifique o status da conexão com o WhatsApp e veja o QR Code para conectar, caso necessário.
*   **Configurações**: Altere as configurações da sua loja diretamente pelo painel, sem precisar editar o arquivo `config.js` novamente.

---

### 🔧 Requisitos Técnicos

*   **Node.js**: O ambiente de execução do sistema. (Versão 18 ou superior recomendada).
*   **Impressora Térmica**: Compatível com o padrão ESC/POS (a maioria das impressoras de recibo do mercado, como Epson, Daruma, Bematech, etc.).
*   **Computador**: Um computador (Windows, macOS ou Linux) para rodar o sistema e conectar a impressora.

Obrigado por utilizar o Fast Food WhatsApp Bot!
