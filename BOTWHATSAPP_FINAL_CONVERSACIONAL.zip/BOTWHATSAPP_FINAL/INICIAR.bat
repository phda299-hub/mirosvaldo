@echo off
title FastFood WhatsApp Bot
color 0E

if not exist node_modules (
    echo Dependencias nao instaladas!
    echo.
    echo Execute primeiro o INSTALAR.bat
    echo.
    pause
    exit /b 1
)

if not exist "node_modules\better-sqlite3\build\Release\better_sqlite3.node" (
    echo Modulo better-sqlite3 nao compilado. Recompilando...
    echo.
    call npm rebuild better-sqlite3
    echo.
)

:: Encerrar qualquer processo anterior usando a porta 3000
echo Verificando se a porta 3000 esta em uso...
netstat -aon | findstr ":3000" | findstr "LISTENING" > "%TEMP%\porta3000.tmp" 2>nul
for /f "tokens=5" %%a in (%TEMP%\porta3000.tmp) do (
    echo Encerrando processo anterior na porta 3000 (PID: %%a^)...
    taskkill /PID %%a /F >nul 2>&1
)
del "%TEMP%\porta3000.tmp" >nul 2>&1
echo.

echo Iniciando FastFood WhatsApp Bot...
echo.
echo Abrindo painel administrativo no navegador...
echo.

:: Aguardar 2 segundos para o servidor iniciar e abrir o navegador
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:3000/"

node index.js
pause
