# Documentação: Sistema de IA Humanizada ("Lara") no Bot WhatsApp

Esta documentação descreve a implementação completa do sistema de Inteligência Artificial humanizada no projeto Bot WhatsApp de Fast Food. O sistema foi projetado para atuar em conjunto com o fluxo estruturado existente, oferecendo uma experiência de atendimento mais natural e inteligente.

---

## 1. Visão Geral da Arquitetura

O sistema utiliza uma **arquitetura 100% Conversacional**:
1. **Interface Única:** Não existem mais menus numéricos (1, 2, 3...). O cliente interage apenas por texto ou áudio natural.
2. **IA Lara como Gestora:** A IA é responsável por entender o desejo do cliente, sugerir produtos, coletar endereço e confirmar o pedido.
3. **Extração Inteligente:** Um motor de análise processa a conversa em tempo real e registra o pedido no banco de dados assim que a Lara confirma a finalização.

### 1.1 Componentes Principais

- **Motor de IA (`src/ai/aiEngine.js`):** Gerencia a comunicação com múltiplos provedores de IA, implementando uma cadeia de *fallback* automático.
- **Contexto Dinâmico (`src/ai/restauranteContext.js`):** Constrói o *system prompt* em tempo real, injetando dados do banco de dados (cardápio, horários, taxas) para que a IA sempre tenha informações atualizadas.
- **Detecção de Intenção:** Lógica inteligente que decide se uma mensagem deve ser tratada pelo menu estruturado ou encaminhada para a IA.
- **Gerenciador de Sessão (`src/bot/session.js`):** Modificado para armazenar o histórico de conversas (últimas 20 mensagens) de cada cliente, permitindo que a IA mantenha o contexto do diálogo.

---

## 2. Provedores de IA e Fallback

O sistema foi configurado para tentar múltiplos provedores de IA em sequência. Se um falhar (por instabilidade ou token expirado), o próximo é acionado automaticamente.

| Prioridade | Provedor | Modelo | Origem das Credenciais |
| :---: | :--- | :--- | :--- |
| **1ª** | **OpenAI** | `claude-haiku-4-5` (ou configurado via `.env`) | Arquivo `.env` local |
| **2ª** | **Syphnosys** | `Mistral` | Extraído do APK ChatAI v241.0 |
| **3ª** | **Begamob** | `ChatOn` | Extraído do APK ChatAI v241.0 |
| **4ª** | **EmojiKeyboard**| `AI Studio` | Extraído do APK ChatAI v241.0 |

> **Nota de Segurança:** As credenciais dos provedores 2, 3 e 4 foram obtidas via engenharia reversa do APK analisado. Elas estão hardcoded em `src/config.js` para garantir o funcionamento imediato como *fallback*, mas recomenda-se substituí-las por chaves próprias em ambiente de produção.

---

## 3. Como a IA ("Lara") Funciona

A IA foi configurada com a persona "Lara", uma atendente virtual simpática e prestativa.

### 3.1 O que a IA sabe responder?
Graças à injeção dinâmica de contexto e à **Busca Proativa**, a IA pode responder perguntas sobre:
- **Ciclo Completo de Pedido:** A Lara anota os itens, pergunta o endereço, confirma o pagamento e finaliza a venda sem necessidade de menus.
- **Sugestões Inteligentes:** Se o cliente pedir "um lanche com bacon", ela sugere o X-Bacon e pergunta se quer batata ou bebida.
- **Transcrição de Áudio:** O bot ouve mensagens de voz, transcreve e a Lara responde naturalmente.
- **Horários e Logística:** Responde sobre taxas de entrega, horários e formas de pagamento.
- **Registro Automático:** Assim que a Lara diz "Pedido confirmado e enviado para a cozinha", o sistema extrai os dados da conversa e cria o pedido no painel administrativo.

### 3.2 Busca Proativa de Produtos
Implementamos o módulo `src/ai/produtoSearch.js` que realiza uma busca no banco de dados baseada na mensagem do cliente. Os resultados são injetados no prompt da IA, permitindo que ela diga:
> "Vi que você quer um X-Bacon! Temos ele por R$ 22,90. Gostaria de pedir este ou ver outras opções?"

### 3.2 Histórico de Conversa
O `SessionManager` agora mantém um array `historicoIA` para cada número de telefone. Isso permite diálogos como:
- *Cliente:* "Qual o hambúrguer mais vendido?"
- *Lara:* "O nosso destaque é o X-Burguer Especial, que custa R$ 18,90!"
- *Cliente:* "Vem com bacon?"
- *Lara:* "Sim, o X-Burguer Especial acompanha fatias de bacon crocante." *(A IA entende que o cliente está falando do hambúrguer mencionado na mensagem anterior).*

O histórico é limitado a 20 mensagens (10 interações) para otimizar o uso de tokens e memória.

---

## 4. Como Configurar e Iniciar

### 4.1 Configuração Inicial
1. Copie o arquivo `.env.example` para `.env`:
   ```bash
   cp .env.example .env
   ```
2. Edite o arquivo `.env` e insira sua chave da OpenAI (opcional, mas recomendado para maior estabilidade):
   ```env
   OPENAI_API_KEY=sk-sua-chave-aqui
   OPENAI_MODEL=claude-haiku-4-5
   ```
3. Edite o arquivo `src/config.js` para personalizar os dados da loja, mensagens e ativar/desativar provedores específicos.

### 4.2 Instalação e Execução
Instale as dependências e inicie o bot:
```bash
npm install
npm start
```

### 4.3 Testes Automatizados
O projeto inclui um script de teste completo que verifica a detecção de intenção, o histórico de sessão, a montagem do contexto e realiza uma chamada real à IA.
Para rodar os testes:
```bash
node test-ia-completo.js
```

---

## 5. Modificações Realizadas no Código Original

1. **`src/ai/aiEngine.js` (NOVO):** Motor de integração com os 4 provedores de IA.
2. **`src/ai/restauranteContext.js` (MODIFICADO):** Injeção proativa de produtos encontrados na busca.
3. **`src/ai/produtoSearch.js` (NOVO):** Utilitário de busca de produtos por similaridade de texto.
4. **`src/bot/audioHandler.js` (NOVO):** Processador e transcritor de mensagens de áudio.
5. **`src/bot/whatsapp.js` (MODIFICADO):** Captura de mensagens de áudio e integração com o transcritor.
6. **`src/bot/handlers.js` (MODIFICADO):** Interceptação inteligente de mensagens conversacionais.
7. **`src/bot/session.js` (MODIFICADO):** Histórico de conversa por sessão.
8. **`src/config.js` (MODIFICADO):** Configurações de IA e provedores.
9. **`package.json` (MODIFICADO):** Adicionadas bibliotecas `axios` e `uuid`.

---
*Documentação gerada automaticamente pela análise e implementação do sistema de IA.*
