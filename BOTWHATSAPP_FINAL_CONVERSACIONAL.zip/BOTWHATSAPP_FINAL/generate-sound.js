/**
 * Gerar arquivo de som de notificação (WAV simples)
 * Este script cria um beep de notificação em formato WAV
 */

const fs = require('fs');
const path = require('path');

function generateBeepWav(filename, frequency = 880, duration = 0.3, sampleRate = 44100) {
  const numSamples = Math.floor(sampleRate * duration);
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * bitsPerSample / 8;
  const blockAlign = numChannels * bitsPerSample / 8;
  const dataSize = numSamples * blockAlign;

  const buffer = Buffer.alloc(44 + dataSize);
  let offset = 0;

  // RIFF header
  buffer.write('RIFF', offset); offset += 4;
  buffer.writeUInt32LE(36 + dataSize, offset); offset += 4;
  buffer.write('WAVE', offset); offset += 4;

  // fmt chunk
  buffer.write('fmt ', offset); offset += 4;
  buffer.writeUInt32LE(16, offset); offset += 4;
  buffer.writeUInt16LE(1, offset); offset += 2; // PCM
  buffer.writeUInt16LE(numChannels, offset); offset += 2;
  buffer.writeUInt32LE(sampleRate, offset); offset += 4;
  buffer.writeUInt32LE(byteRate, offset); offset += 4;
  buffer.writeUInt16LE(blockAlign, offset); offset += 2;
  buffer.writeUInt16LE(bitsPerSample, offset); offset += 2;

  // data chunk
  buffer.write('data', offset); offset += 4;
  buffer.writeUInt32LE(dataSize, offset); offset += 4;

  // Generate 3 beeps
  const beepDuration = Math.floor(numSamples / 5);
  for (let i = 0; i < numSamples; i++) {
    const beepIndex = Math.floor(i / beepDuration);
    const inBeep = (beepIndex % 2 === 0) && beepIndex < 5;
    
    let sample = 0;
    if (inBeep) {
      const t = i / sampleRate;
      const envelope = Math.min(1, Math.min((i % beepDuration) / 500, (beepDuration - (i % beepDuration)) / 500));
      sample = Math.sin(2 * Math.PI * frequency * t) * 0.5 * envelope;
    }
    
    const intSample = Math.max(-32768, Math.min(32767, Math.floor(sample * 32767)));
    buffer.writeInt16LE(intSample, offset);
    offset += 2;
  }

  fs.writeFileSync(filename, buffer);
  console.log(`✅ Arquivo de som gerado: ${filename}`);
}

// Gerar som de notificação
const soundPath = path.join(__dirname, 'src', 'public', 'sounds', 'notification.mp3');
// Na verdade vamos gerar WAV e renomear (browsers aceitam)
const wavPath = path.join(__dirname, 'src', 'public', 'sounds', 'notification.wav');
generateBeepWav(wavPath, 880, 1.5);

// Copiar como mp3 (browsers modernos tocam wav mesmo com extensão mp3)
fs.copyFileSync(wavPath, soundPath);
console.log('✅ Som de notificação criado!');
