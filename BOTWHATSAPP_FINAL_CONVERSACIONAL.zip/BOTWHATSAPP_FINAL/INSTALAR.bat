@echo off
title FastFood WhatsApp Bot - Instalador
color 0A

echo.
echo ================================================
echo    FAST FOOD WHATSAPP BOT - INSTALADOR
echo ================================================
echo    Este script vai instalar todas as
echo    dependencias do projeto automaticamente.
echo ================================================
echo.

where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERRO: Node.js nao encontrado!
    echo.
    echo Baixe e instale o Node.js em: https://nodejs.org
    echo Recomendado: versao LTS v18 ou superior
    echo.
    pause
    exit /b 1
)

echo Node.js encontrado:
node -v
echo.

if exist node_modules (
    echo Removendo node_modules antigo...
    rmdir /s /q node_modules
    echo Removido.
    echo.
)

echo Instalando dependencias (pode levar alguns minutos)...
echo.
call npm install

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ================================================
    echo   ERRO NA INSTALACAO!
    echo ================================================
    echo.
    echo Possiveis solucoes:
    echo.
    echo   1. Instale o Visual Studio Build Tools:
    echo      https://visualstudio.microsoft.com/visual-cpp-build-tools/
    echo      Selecione "Desenvolvimento para desktop com C++"
    echo.
    echo   2. Ou execute como Administrador:
    echo      npm install -g windows-build-tools
    echo.
    echo   3. Depois tente rodar este script novamente.
    echo.
    pause
    exit /b 1
)

echo.
echo Recompilando modulo nativo better-sqlite3...
call npm rebuild better-sqlite3

echo.
echo ================================================
echo   INSTALACAO CONCLUIDA COM SUCESSO!
echo ================================================
echo.
echo   IMPORTANTE - CONFIGURAR IMPRESSORA:
echo.
echo   Para a impressora funcionar no Windows,
echo   voce precisa COMPARTILHAR a impressora:
echo.
echo   1. Painel de Controle ^> Dispositivos e Impressoras
echo   2. Clique direito na impressora ^> Propriedades
echo   3. Aba "Compartilhamento"
echo   4. Marque "Compartilhar esta impressora"
echo   5. Anote o nome do compartilhamento
echo   6. Edite src\config.js e ajuste o nome se necessario
echo.
echo   Para iniciar o bot, execute:
echo     npm start
echo.
echo   Ou clique duas vezes em INICIAR.bat
echo.
echo ================================================
echo.
pause
