const axios = require('axios');

async function testOpenAISandbox() {
  const baseUrl = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
  const apiKey = process.env.OPENAI_API_KEY;

  console.log('OPENAI_API_BASE:', baseUrl);
  console.log('OPENAI_API_KEY presente:', apiKey ? 'SIM' : 'NÃO');

  if (!apiKey) {
    console.log('Sem API key configurada no ambiente');
    return;
  }

  // Modelos disponíveis no proxy do sandbox
  const modelos = ['claude-haiku-4-5', 'gpt-4.1-mini', 'gemini-2.5-flash'];

  for (const modelo of modelos) {
    try {
      const r = await axios.post(baseUrl + '/chat/completions', {
        model: modelo,
        messages: [
          { role: 'system', content: 'Você é um assistente de restaurante chamado Lara.' },
          { role: 'user', content: 'Qual o horário de funcionamento de vocês?' }
        ],
        max_tokens: 100
      }, {
        headers: {
          'Authorization': 'Bearer ' + apiKey,
          'Content-Type': 'application/json'
        },
        timeout: 15000
      });

      const resposta = r.data.choices && r.data.choices[0]
        ? r.data.choices[0].message.content
        : JSON.stringify(r.data).substring(0, 200);

      console.log('Modelo ' + modelo + ': OK');
      console.log('Resposta:', resposta.substring(0, 150));
      break; // Parar no primeiro que funcionar
    } catch (e) {
      const msg = e.response ? JSON.stringify(e.response.data).substring(0, 100) : e.message;
      console.log('Modelo ' + modelo + ': ERRO -', msg);
    }
  }
}

testOpenAISandbox().catch(console.error);
