@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo  GERANDO EXE COM CONSOLE DEBUG - Manus API Pro
echo ============================================================
echo.

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if exist build_debug rmdir /s /q build_debug
if exist dist_debug rmdir /s /q dist_debug

python -m PyInstaller ^
 --onefile ^
 --console ^
 --clean ^
 --name "ManusApiPro_DEBUG" ^
 --distpath dist_debug ^
 --workpath build_debug ^
 --hidden-import=requests ^
 --hidden-import=urllib3 ^
 --hidden-import=charset_normalizer ^
 --hidden-import=idna ^
 --hidden-import=certifi ^
 --hidden-import=tkinter ^
 --hidden-import=tkinter.ttk ^
 --hidden-import=tkinter.scrolledtext ^
 --hidden-import=tkinter.filedialog ^
 --hidden-import=tkinter.messagebox ^
 --hidden-import=PIL ^
 --hidden-import=PIL.Image ^
 --hidden-import=PIL.ImageGrab ^
 "manus_api_gui_tkinter_full_profissional_checkpoint_chave_credito.py"

if errorlevel 1 (
    echo.
    echo ERRO ao gerar EXE DEBUG.
    pause
    exit /b 1
)

echo.
echo EXE DEBUG GERADO:
echo dist_debug\ManusApiPro_DEBUG.exe
echo.
pause
endlocal
