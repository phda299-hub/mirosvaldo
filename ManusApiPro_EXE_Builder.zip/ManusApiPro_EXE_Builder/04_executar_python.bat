@echo off
chcp 65001 >nul
cd /d "%~dp0"
python "manus_api_gui_tkinter_full_profissional_checkpoint_chave_credito.py"
pause
