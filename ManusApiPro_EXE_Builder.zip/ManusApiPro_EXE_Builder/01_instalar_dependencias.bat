@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo  INSTALANDO DEPENDENCIAS - Manus API Pro
echo ============================================================
echo.

python --version
if errorlevel 1 (
    echo ERRO: Python nao encontrado no PATH.
    echo Instale o Python ou marque a opcao "Add Python to PATH".
    pause
    exit /b 1
)

echo.
echo Atualizando pip...
python -m pip install --upgrade pip

echo.
echo Instalando requirements...
python -m pip install -r requirements.txt

if errorlevel 1 (
    echo.
    echo ERRO ao instalar dependencias.
    pause
    exit /b 1
)

echo.
echo Dependencias instaladas com sucesso.
pause
endlocal
