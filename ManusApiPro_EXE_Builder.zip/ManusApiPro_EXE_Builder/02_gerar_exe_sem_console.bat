@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo  GERANDO EXE SEM CONSOLE - Manus API Pro
echo ============================================================
echo.

python --version
if errorlevel 1 (
    echo ERRO: Python nao encontrado no PATH.
    pause
    exit /b 1
)

echo.
echo Instalando/atualizando PyInstaller e dependencias...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Limpando builds antigos...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist ManusApiPro.spec del /q ManusApiPro.spec

echo.
echo Compilando em um unico arquivo .exe...
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name "ManusApiPro" ^
 --hidden-import=requests ^
 --hidden-import=urllib3 ^
 --hidden-import=charset_normalizer ^
 --hidden-import=idna ^
 --hidden-import=certifi ^
 --hidden-import=tkinter ^
 --hidden-import=tkinter.ttk ^
 --hidden-import=tkinter.scrolledtext ^
 --hidden-import=tkinter.filedialog ^
 --hidden-import=tkinter.messagebox ^
 --hidden-import=PIL ^
 --hidden-import=PIL.Image ^
 --hidden-import=PIL.ImageGrab ^
 "manus_api_gui_tkinter_full_profissional_checkpoint_chave_credito.py"

if errorlevel 1 (
    echo.
    echo ERRO: Falha ao gerar EXE.
    echo Tente executar o arquivo 03_gerar_exe_com_console_debug.bat para ver o erro completo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo EXE GERADO COM SUCESSO:
echo dist\ManusApiPro.exe
echo ============================================================
echo.
echo Copie o arquivo abaixo para onde quiser:
echo %CD%\dist\ManusApiPro.exe
echo.
pause
endlocal
