@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist build_debug rmdir /s /q build_debug
if exist dist_debug rmdir /s /q dist_debug
if exist __pycache__ rmdir /s /q __pycache__
if exist ManusApiPro.spec del /q ManusApiPro.spec
if exist ManusApiPro_DEBUG.spec del /q ManusApiPro_DEBUG.spec

echo Limpeza concluida.
pause
