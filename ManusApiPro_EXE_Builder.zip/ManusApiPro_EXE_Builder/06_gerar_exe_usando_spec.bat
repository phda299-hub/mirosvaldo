@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

python -m PyInstaller --clean ManusApiPro_sem_console.spec

if errorlevel 1 (
    echo ERRO ao gerar usando spec.
    pause
    exit /b 1
)

echo EXE GERADO:
echo dist\ManusApiPro.exe
pause
endlocal
